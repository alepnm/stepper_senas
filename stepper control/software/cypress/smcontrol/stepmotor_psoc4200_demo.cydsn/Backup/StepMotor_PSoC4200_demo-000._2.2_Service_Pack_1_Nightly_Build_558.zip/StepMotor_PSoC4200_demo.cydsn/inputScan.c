/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#include <inputScan.h>

void inputScan()
{
    if (STEP_INPUT_SOURCE_Read() == 0){
        previousStepPulse  = stepPulse;
        stepPulse = STEP_INPUT_Read(); // rising edge, reserved for potential glith
    }
    else{
        previousStepPulse = stepPulse;
        stepPulse = INTERNAL_STEP_OUT_Read();
    }
    if (DIR_INPUT_SOURCE_Read()== 0){
        dirReg = DIR_INPUT_Read();
        
    }
    else{
        dirReg = 0;
    }
}