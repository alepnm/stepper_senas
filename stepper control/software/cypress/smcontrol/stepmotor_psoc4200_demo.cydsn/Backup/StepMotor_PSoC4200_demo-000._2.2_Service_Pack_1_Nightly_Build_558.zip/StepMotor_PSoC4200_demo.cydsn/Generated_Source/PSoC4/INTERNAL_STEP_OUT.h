/*******************************************************************************
* File Name: INTERNAL_STEP_OUT.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_INTERNAL_STEP_OUT_H) /* Pins INTERNAL_STEP_OUT_H */
#define CY_PINS_INTERNAL_STEP_OUT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "INTERNAL_STEP_OUT_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    INTERNAL_STEP_OUT_Write(uint8 value) ;
void    INTERNAL_STEP_OUT_SetDriveMode(uint8 mode) ;
uint8   INTERNAL_STEP_OUT_ReadDataReg(void) ;
uint8   INTERNAL_STEP_OUT_Read(void) ;
uint8   INTERNAL_STEP_OUT_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define INTERNAL_STEP_OUT_DRIVE_MODE_BITS        (3)
#define INTERNAL_STEP_OUT_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - INTERNAL_STEP_OUT_DRIVE_MODE_BITS))
#define INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT       (0x00u)
#define INTERNAL_STEP_OUT_DRIVE_MODE_MASK        (0x07u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)

#define INTERNAL_STEP_OUT_DM_ALG_HIZ         (0x00u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_DIG_HIZ         (0x01u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_RES_UP          (0x02u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_RES_DWN         (0x03u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_OD_LO           (0x04u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_OD_HI           (0x05u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_STRONG          (0x06u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)
#define INTERNAL_STEP_OUT_DM_RES_UPDWN       (0x07u << INTERNAL_STEP_OUT_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define INTERNAL_STEP_OUT_MASK               INTERNAL_STEP_OUT__MASK
#define INTERNAL_STEP_OUT_SHIFT              INTERNAL_STEP_OUT__SHIFT
#define INTERNAL_STEP_OUT_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define INTERNAL_STEP_OUT_PS                     (* (reg32 *) INTERNAL_STEP_OUT__PS)
/* Port Configuration */
#define INTERNAL_STEP_OUT_PC                     (* (reg32 *) INTERNAL_STEP_OUT__PC)
/* Data Register */
#define INTERNAL_STEP_OUT_DR                     (* (reg32 *) INTERNAL_STEP_OUT__DR)
/* Input Buffer Disable Override */
#define INTERNAL_STEP_OUT_INP_DIS                (* (reg32 *) INTERNAL_STEP_OUT__PC2)


#if defined(INTERNAL_STEP_OUT__INTSTAT)  /* Interrupt Registers */

    #define INTERNAL_STEP_OUT_INTSTAT                (* (reg32 *) INTERNAL_STEP_OUT__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins INTERNAL_STEP_OUT_H */


/* [] END OF FILE */
