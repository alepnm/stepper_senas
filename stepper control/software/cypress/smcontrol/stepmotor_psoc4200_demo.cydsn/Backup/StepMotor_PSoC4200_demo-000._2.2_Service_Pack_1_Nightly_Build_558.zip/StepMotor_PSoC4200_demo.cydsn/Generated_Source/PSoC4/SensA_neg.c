/*******************************************************************************
* File Name: SensA_neg.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "SensA_neg.h"

#define SetP4PinDriveMode(shift, mode)  \
    do { \
        SensA_neg_PC =   (SensA_neg_PC & \
                                (uint32)(~(uint32)(SensA_neg_DRIVE_MODE_IND_MASK << (SensA_neg_DRIVE_MODE_BITS * (shift))))) | \
                                (uint32)((uint32)(mode) << (SensA_neg_DRIVE_MODE_BITS * (shift))); \
    } while (0)


/*******************************************************************************
* Function Name: SensA_neg_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void SensA_neg_Write(uint8 value) 
{
    uint8 drVal = (uint8)(SensA_neg_DR & (uint8)(~SensA_neg_MASK));
    drVal = (drVal | ((uint8)(value << SensA_neg_SHIFT) & SensA_neg_MASK));
    SensA_neg_DR = (uint32)drVal;
}


/*******************************************************************************
* Function Name: SensA_neg_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*
* Return: 
*  None
*
*******************************************************************************/
void SensA_neg_SetDriveMode(uint8 mode) 
{
	SetP4PinDriveMode(SensA_neg__0__SHIFT, mode);
}


/*******************************************************************************
* Function Name: SensA_neg_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro SensA_neg_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 SensA_neg_Read(void) 
{
    return (uint8)((SensA_neg_PS & SensA_neg_MASK) >> SensA_neg_SHIFT);
}


/*******************************************************************************
* Function Name: SensA_neg_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 SensA_neg_ReadDataReg(void) 
{
    return (uint8)((SensA_neg_DR & SensA_neg_MASK) >> SensA_neg_SHIFT);
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(SensA_neg_INTSTAT) 

    /*******************************************************************************
    * Function Name: SensA_neg_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 SensA_neg_ClearInterrupt(void) 
    {
		uint8 maskedStatus = (uint8)(SensA_neg_INTSTAT & SensA_neg_MASK);
		SensA_neg_INTSTAT = maskedStatus;
        return maskedStatus >> SensA_neg_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
