/*******************************************************************************
* File Name: PWM_OUT_A.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PWM_OUT_A_H) /* Pins PWM_OUT_A_H */
#define CY_PINS_PWM_OUT_A_H

#include "cytypes.h"
#include "cyfitter.h"
#include "PWM_OUT_A_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    PWM_OUT_A_Write(uint8 value) ;
void    PWM_OUT_A_SetDriveMode(uint8 mode) ;
uint8   PWM_OUT_A_ReadDataReg(void) ;
uint8   PWM_OUT_A_Read(void) ;
uint8   PWM_OUT_A_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PWM_OUT_A_DRIVE_MODE_BITS        (3)
#define PWM_OUT_A_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - PWM_OUT_A_DRIVE_MODE_BITS))
#define PWM_OUT_A_DRIVE_MODE_SHIFT       (0x00u)
#define PWM_OUT_A_DRIVE_MODE_MASK        (0x07u << PWM_OUT_A_DRIVE_MODE_SHIFT)

#define PWM_OUT_A_DM_ALG_HIZ         (0x00u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_DIG_HIZ         (0x01u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_RES_UP          (0x02u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_RES_DWN         (0x03u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_OD_LO           (0x04u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_OD_HI           (0x05u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_STRONG          (0x06u << PWM_OUT_A_DRIVE_MODE_SHIFT)
#define PWM_OUT_A_DM_RES_UPDWN       (0x07u << PWM_OUT_A_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define PWM_OUT_A_MASK               PWM_OUT_A__MASK
#define PWM_OUT_A_SHIFT              PWM_OUT_A__SHIFT
#define PWM_OUT_A_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PWM_OUT_A_PS                     (* (reg32 *) PWM_OUT_A__PS)
/* Port Configuration */
#define PWM_OUT_A_PC                     (* (reg32 *) PWM_OUT_A__PC)
/* Data Register */
#define PWM_OUT_A_DR                     (* (reg32 *) PWM_OUT_A__DR)
/* Input Buffer Disable Override */
#define PWM_OUT_A_INP_DIS                (* (reg32 *) PWM_OUT_A__PC2)


#if defined(PWM_OUT_A__INTSTAT)  /* Interrupt Registers */

    #define PWM_OUT_A_INTSTAT                (* (reg32 *) PWM_OUT_A__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins PWM_OUT_A_H */


/* [] END OF FILE */
