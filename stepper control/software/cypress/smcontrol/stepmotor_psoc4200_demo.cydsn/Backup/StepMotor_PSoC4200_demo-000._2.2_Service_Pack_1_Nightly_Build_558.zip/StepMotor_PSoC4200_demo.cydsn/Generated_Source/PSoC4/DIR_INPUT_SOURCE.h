/*******************************************************************************
* File Name: DIR_INPUT_SOURCE.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DIR_INPUT_SOURCE_H) /* Pins DIR_INPUT_SOURCE_H */
#define CY_PINS_DIR_INPUT_SOURCE_H

#include "cytypes.h"
#include "cyfitter.h"
#include "DIR_INPUT_SOURCE_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DIR_INPUT_SOURCE_Write(uint8 value) ;
void    DIR_INPUT_SOURCE_SetDriveMode(uint8 mode) ;
uint8   DIR_INPUT_SOURCE_ReadDataReg(void) ;
uint8   DIR_INPUT_SOURCE_Read(void) ;
uint8   DIR_INPUT_SOURCE_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DIR_INPUT_SOURCE_DRIVE_MODE_BITS        (3)
#define DIR_INPUT_SOURCE_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - DIR_INPUT_SOURCE_DRIVE_MODE_BITS))
#define DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT       (0x00u)
#define DIR_INPUT_SOURCE_DRIVE_MODE_MASK        (0x07u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)

#define DIR_INPUT_SOURCE_DM_ALG_HIZ         (0x00u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_DIG_HIZ         (0x01u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_RES_UP          (0x02u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_RES_DWN         (0x03u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_OD_LO           (0x04u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_OD_HI           (0x05u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_STRONG          (0x06u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)
#define DIR_INPUT_SOURCE_DM_RES_UPDWN       (0x07u << DIR_INPUT_SOURCE_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define DIR_INPUT_SOURCE_MASK               DIR_INPUT_SOURCE__MASK
#define DIR_INPUT_SOURCE_SHIFT              DIR_INPUT_SOURCE__SHIFT
#define DIR_INPUT_SOURCE_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DIR_INPUT_SOURCE_PS                     (* (reg32 *) DIR_INPUT_SOURCE__PS)
/* Port Configuration */
#define DIR_INPUT_SOURCE_PC                     (* (reg32 *) DIR_INPUT_SOURCE__PC)
/* Data Register */
#define DIR_INPUT_SOURCE_DR                     (* (reg32 *) DIR_INPUT_SOURCE__DR)
/* Input Buffer Disable Override */
#define DIR_INPUT_SOURCE_INP_DIS                (* (reg32 *) DIR_INPUT_SOURCE__PC2)


#if defined(DIR_INPUT_SOURCE__INTSTAT)  /* Interrupt Registers */

    #define DIR_INPUT_SOURCE_INTSTAT                (* (reg32 *) DIR_INPUT_SOURCE__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins DIR_INPUT_SOURCE_H */


/* [] END OF FILE */
