/*******************************************************************************
* File Name: STEP_INPUT.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_STEP_INPUT_H) /* Pins STEP_INPUT_H */
#define CY_PINS_STEP_INPUT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "STEP_INPUT_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    STEP_INPUT_Write(uint8 value) ;
void    STEP_INPUT_SetDriveMode(uint8 mode) ;
uint8   STEP_INPUT_ReadDataReg(void) ;
uint8   STEP_INPUT_Read(void) ;
uint8   STEP_INPUT_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define STEP_INPUT_DRIVE_MODE_BITS        (3)
#define STEP_INPUT_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - STEP_INPUT_DRIVE_MODE_BITS))
#define STEP_INPUT_DRIVE_MODE_SHIFT       (0x00u)
#define STEP_INPUT_DRIVE_MODE_MASK        (0x07u << STEP_INPUT_DRIVE_MODE_SHIFT)

#define STEP_INPUT_DM_ALG_HIZ         (0x00u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_DIG_HIZ         (0x01u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_RES_UP          (0x02u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_RES_DWN         (0x03u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_OD_LO           (0x04u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_OD_HI           (0x05u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_STRONG          (0x06u << STEP_INPUT_DRIVE_MODE_SHIFT)
#define STEP_INPUT_DM_RES_UPDWN       (0x07u << STEP_INPUT_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define STEP_INPUT_MASK               STEP_INPUT__MASK
#define STEP_INPUT_SHIFT              STEP_INPUT__SHIFT
#define STEP_INPUT_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define STEP_INPUT_PS                     (* (reg32 *) STEP_INPUT__PS)
/* Port Configuration */
#define STEP_INPUT_PC                     (* (reg32 *) STEP_INPUT__PC)
/* Data Register */
#define STEP_INPUT_DR                     (* (reg32 *) STEP_INPUT__DR)
/* Input Buffer Disable Override */
#define STEP_INPUT_INP_DIS                (* (reg32 *) STEP_INPUT__PC2)


#if defined(STEP_INPUT__INTSTAT)  /* Interrupt Registers */

    #define STEP_INPUT_INTSTAT                (* (reg32 *) STEP_INPUT__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins STEP_INPUT_H */


/* [] END OF FILE */
