/*******************************************************************************
* File Name: IBO.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IBO_ALIASES_H) /* Pins IBO_ALIASES_H */
#define CY_PINS_IBO_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define IBO_0			(IBO__0__PC)
#define IBO_0_PS		(IBO__0__PS)
#define IBO_0_PC		(IBO__0__PC)
#define IBO_0_DR		(IBO__0__DR)
#define IBO_0_SHIFT	(IBO__0__SHIFT)
#define IBO_0_INTR	((uint16)((uint16)0x0003u << (IBO__0__SHIFT*2u)))

#define IBO_INTR_ALL	 ((uint16)(IBO_0_INTR))


#endif /* End Pins IBO_ALIASES_H */


/* [] END OF FILE */
