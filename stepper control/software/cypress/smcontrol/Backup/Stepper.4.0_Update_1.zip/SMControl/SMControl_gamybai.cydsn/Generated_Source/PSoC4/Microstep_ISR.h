/*******************************************************************************
* File Name: Microstep_ISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Microstep_ISR_H)
#define CY_ISR_Microstep_ISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Microstep_ISR_Start(void);
void Microstep_ISR_StartEx(cyisraddress address);
void Microstep_ISR_Stop(void);

CY_ISR_PROTO(Microstep_ISR_Interrupt);

void Microstep_ISR_SetVector(cyisraddress address);
cyisraddress Microstep_ISR_GetVector(void);

void Microstep_ISR_SetPriority(uint8 priority);
uint8 Microstep_ISR_GetPriority(void);

void Microstep_ISR_Enable(void);
uint8 Microstep_ISR_GetState(void);
void Microstep_ISR_Disable(void);

void Microstep_ISR_SetPending(void);
void Microstep_ISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Microstep_ISR ISR. */
#define Microstep_ISR_INTC_VECTOR            ((reg32 *) Microstep_ISR__INTC_VECT)

/* Address of the Microstep_ISR ISR priority. */
#define Microstep_ISR_INTC_PRIOR             ((reg32 *) Microstep_ISR__INTC_PRIOR_REG)

/* Priority of the Microstep_ISR interrupt. */
#define Microstep_ISR_INTC_PRIOR_NUMBER      Microstep_ISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Microstep_ISR interrupt. */
#define Microstep_ISR_INTC_SET_EN            ((reg32 *) Microstep_ISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Microstep_ISR interrupt. */
#define Microstep_ISR_INTC_CLR_EN            ((reg32 *) Microstep_ISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Microstep_ISR interrupt state to pending. */
#define Microstep_ISR_INTC_SET_PD            ((reg32 *) Microstep_ISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Microstep_ISR interrupt. */
#define Microstep_ISR_INTC_CLR_PD            ((reg32 *) Microstep_ISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_Microstep_ISR_H */


/* [] END OF FILE */
