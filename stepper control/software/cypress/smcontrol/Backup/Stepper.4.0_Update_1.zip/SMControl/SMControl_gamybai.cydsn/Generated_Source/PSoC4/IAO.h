/*******************************************************************************
* File Name: IAO.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IAO_H) /* Pins IAO_H */
#define CY_PINS_IAO_H

#include "cytypes.h"
#include "cyfitter.h"
#include "IAO_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} IAO_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   IAO_Read(void);
void    IAO_Write(uint8 value);
uint8   IAO_ReadDataReg(void);
#if defined(IAO__PC) || (CY_PSOC4_4200L) 
    void    IAO_SetDriveMode(uint8 mode);
#endif
void    IAO_SetInterruptMode(uint16 position, uint16 mode);
uint8   IAO_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void IAO_Sleep(void); 
void IAO_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(IAO__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define IAO_DRIVE_MODE_BITS        (3)
    #define IAO_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - IAO_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the IAO_SetDriveMode() function.
         *  @{
         */
        #define IAO_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define IAO_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define IAO_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define IAO_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define IAO_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define IAO_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define IAO_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define IAO_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define IAO_MASK               IAO__MASK
#define IAO_SHIFT              IAO__SHIFT
#define IAO_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in IAO_SetInterruptMode() function.
     *  @{
     */
        #define IAO_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define IAO_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define IAO_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define IAO_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(IAO__SIO)
    #define IAO_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(IAO__PC) && (CY_PSOC4_4200L)
    #define IAO_USBIO_ENABLE               ((uint32)0x80000000u)
    #define IAO_USBIO_DISABLE              ((uint32)(~IAO_USBIO_ENABLE))
    #define IAO_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define IAO_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define IAO_USBIO_ENTER_SLEEP          ((uint32)((1u << IAO_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << IAO_USBIO_SUSPEND_DEL_SHIFT)))
    #define IAO_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << IAO_USBIO_SUSPEND_SHIFT)))
    #define IAO_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << IAO_USBIO_SUSPEND_DEL_SHIFT)))
    #define IAO_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(IAO__PC)
    /* Port Configuration */
    #define IAO_PC                 (* (reg32 *) IAO__PC)
#endif
/* Pin State */
#define IAO_PS                     (* (reg32 *) IAO__PS)
/* Data Register */
#define IAO_DR                     (* (reg32 *) IAO__DR)
/* Input Buffer Disable Override */
#define IAO_INP_DIS                (* (reg32 *) IAO__PC2)

/* Interrupt configuration Registers */
#define IAO_INTCFG                 (* (reg32 *) IAO__INTCFG)
#define IAO_INTSTAT                (* (reg32 *) IAO__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define IAO_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(IAO__SIO)
    #define IAO_SIO_REG            (* (reg32 *) IAO__SIO)
#endif /* (IAO__SIO_CFG) */

/* USBIO registers */
#if !defined(IAO__PC) && (CY_PSOC4_4200L)
    #define IAO_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define IAO_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define IAO_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define IAO_DRIVE_MODE_SHIFT       (0x00u)
#define IAO_DRIVE_MODE_MASK        (0x07u << IAO_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins IAO_H */


/* [] END OF FILE */
