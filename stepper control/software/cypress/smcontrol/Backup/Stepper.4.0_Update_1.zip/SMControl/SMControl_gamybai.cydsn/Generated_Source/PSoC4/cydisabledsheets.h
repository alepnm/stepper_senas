#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define PWM_Commutation__DISABLED 1u /* PWM&Commutation */
#define PWM_Commutation_1__DISABLED 1u /* PWM&Commutation_1 */
#define Page_1__DISABLED 1u /* Page 1 */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
