/*******************************************************************************
* File Name: uStepTimer_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "uStepTimer.h"

static uStepTimer_backupStruct uStepTimer_backup;


/*******************************************************************************
* Function Name: uStepTimer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  uStepTimer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void uStepTimer_SaveConfig(void) 
{
    #if (!uStepTimer_UsingFixedFunction)
        uStepTimer_backup.TimerUdb = uStepTimer_ReadCounter();
        uStepTimer_backup.InterruptMaskValue = uStepTimer_STATUS_MASK;
        #if (uStepTimer_UsingHWCaptureCounter)
            uStepTimer_backup.TimerCaptureCounter = uStepTimer_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!uStepTimer_UDB_CONTROL_REG_REMOVED)
            uStepTimer_backup.TimerControlRegister = uStepTimer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: uStepTimer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  uStepTimer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void uStepTimer_RestoreConfig(void) 
{   
    #if (!uStepTimer_UsingFixedFunction)

        uStepTimer_WriteCounter(uStepTimer_backup.TimerUdb);
        uStepTimer_STATUS_MASK =uStepTimer_backup.InterruptMaskValue;
        #if (uStepTimer_UsingHWCaptureCounter)
            uStepTimer_SetCaptureCount(uStepTimer_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!uStepTimer_UDB_CONTROL_REG_REMOVED)
            uStepTimer_WriteControlRegister(uStepTimer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: uStepTimer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  uStepTimer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void uStepTimer_Sleep(void) 
{
    #if(!uStepTimer_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(uStepTimer_CTRL_ENABLE == (uStepTimer_CONTROL & uStepTimer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            uStepTimer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            uStepTimer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    uStepTimer_Stop();
    uStepTimer_SaveConfig();
}


/*******************************************************************************
* Function Name: uStepTimer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  uStepTimer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void uStepTimer_Wakeup(void) 
{
    uStepTimer_RestoreConfig();
    #if(!uStepTimer_UDB_CONTROL_REG_REMOVED)
        if(uStepTimer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                uStepTimer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
