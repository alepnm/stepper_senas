/*******************************************************************************
* File Name: uStepTimer.h
* Version 2.70
*
*  Description:
*     Contains the function prototypes and constants available to the timer
*     user module.
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_Timer_v2_60_uStepTimer_H)
#define CY_Timer_v2_60_uStepTimer_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 uStepTimer_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Timer_v2_70 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */


/**************************************
*           Parameter Defaults
**************************************/

#define uStepTimer_Resolution                 32u
#define uStepTimer_UsingFixedFunction         0u
#define uStepTimer_UsingHWCaptureCounter      0u
#define uStepTimer_SoftwareCaptureMode        0u
#define uStepTimer_SoftwareTriggerMode        0u
#define uStepTimer_UsingHWEnable              0u
#define uStepTimer_EnableTriggerMode          0u
#define uStepTimer_InterruptOnCaptureCount    0u
#define uStepTimer_RunModeUsed                0u
#define uStepTimer_ControlRegRemoved          0u

#if defined(uStepTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG)
    #define uStepTimer_UDB_CONTROL_REG_REMOVED            (0u)
#elif  (uStepTimer_UsingFixedFunction)
    #define uStepTimer_UDB_CONTROL_REG_REMOVED            (0u)
#else 
    #define uStepTimer_UDB_CONTROL_REG_REMOVED            (1u)
#endif /* End uStepTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG */


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for Timer Component
 *************************************************************************/
typedef struct
{
    uint8 TimerEnableState;
    #if(!uStepTimer_UsingFixedFunction)

        uint32 TimerUdb;
        uint8 InterruptMaskValue;
        #if (uStepTimer_UsingHWCaptureCounter)
            uint8 TimerCaptureCounter;
        #endif /* variable declarations for backing up non retention registers in CY_UDB_V1 */

        #if (!uStepTimer_UDB_CONTROL_REG_REMOVED)
            uint8 TimerControlRegister;
        #endif /* variable declaration for backing up enable state of the Timer */
    #endif /* define backup variables only for UDB implementation. Fixed function registers are all retention */

}uStepTimer_backupStruct;


/***************************************
*       Function Prototypes
***************************************/

void    uStepTimer_Start(void) ;
void    uStepTimer_Stop(void) ;

void    uStepTimer_SetInterruptMode(uint8 interruptMode) ;
uint8   uStepTimer_ReadStatusRegister(void) ;
/* Deprecated function. Do not use this in future. Retained for backward compatibility */
#define uStepTimer_GetInterruptSource() uStepTimer_ReadStatusRegister()

#if(!uStepTimer_UDB_CONTROL_REG_REMOVED)
    uint8   uStepTimer_ReadControlRegister(void) ;
    void    uStepTimer_WriteControlRegister(uint8 control) ;
#endif /* (!uStepTimer_UDB_CONTROL_REG_REMOVED) */

uint32  uStepTimer_ReadPeriod(void) ;
void    uStepTimer_WritePeriod(uint32 period) ;
uint32  uStepTimer_ReadCounter(void) ;
void    uStepTimer_WriteCounter(uint32 counter) ;
uint32  uStepTimer_ReadCapture(void) ;
void    uStepTimer_SoftwareCapture(void) ;

#if(!uStepTimer_UsingFixedFunction) /* UDB Prototypes */
    #if (uStepTimer_SoftwareCaptureMode)
        void    uStepTimer_SetCaptureMode(uint8 captureMode) ;
    #endif /* (!uStepTimer_UsingFixedFunction) */

    #if (uStepTimer_SoftwareTriggerMode)
        void    uStepTimer_SetTriggerMode(uint8 triggerMode) ;
    #endif /* (uStepTimer_SoftwareTriggerMode) */

    #if (uStepTimer_EnableTriggerMode)
        void    uStepTimer_EnableTrigger(void) ;
        void    uStepTimer_DisableTrigger(void) ;
    #endif /* (uStepTimer_EnableTriggerMode) */


    #if(uStepTimer_InterruptOnCaptureCount)
        void    uStepTimer_SetInterruptCount(uint8 interruptCount) ;
    #endif /* (uStepTimer_InterruptOnCaptureCount) */

    #if (uStepTimer_UsingHWCaptureCounter)
        void    uStepTimer_SetCaptureCount(uint8 captureCount) ;
        uint8   uStepTimer_ReadCaptureCount(void) ;
    #endif /* (uStepTimer_UsingHWCaptureCounter) */

    void uStepTimer_ClearFIFO(void) ;
#endif /* UDB Prototypes */

/* Sleep Retention APIs */
void uStepTimer_Init(void)          ;
void uStepTimer_Enable(void)        ;
void uStepTimer_SaveConfig(void)    ;
void uStepTimer_RestoreConfig(void) ;
void uStepTimer_Sleep(void)         ;
void uStepTimer_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Timer__CaptureModes, Used in Capture Mode */
#define uStepTimer__B_TIMER__CM_NONE 0
#define uStepTimer__B_TIMER__CM_RISINGEDGE 1
#define uStepTimer__B_TIMER__CM_FALLINGEDGE 2
#define uStepTimer__B_TIMER__CM_EITHEREDGE 3
#define uStepTimer__B_TIMER__CM_SOFTWARE 4



/* Enumerated Type B_Timer__TriggerModes, Used in Trigger Mode */
#define uStepTimer__B_TIMER__TM_NONE 0x00u
#define uStepTimer__B_TIMER__TM_RISINGEDGE 0x04u
#define uStepTimer__B_TIMER__TM_FALLINGEDGE 0x08u
#define uStepTimer__B_TIMER__TM_EITHEREDGE 0x0Cu
#define uStepTimer__B_TIMER__TM_SOFTWARE 0x10u


/***************************************
*    Initialial Parameter Constants
***************************************/

#define uStepTimer_INIT_PERIOD             6143u
#define uStepTimer_INIT_CAPTURE_MODE       ((uint8)((uint8)0u << uStepTimer_CTRL_CAP_MODE_SHIFT))
#define uStepTimer_INIT_TRIGGER_MODE       ((uint8)((uint8)0u << uStepTimer_CTRL_TRIG_MODE_SHIFT))
#if (uStepTimer_UsingFixedFunction)
    #define uStepTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)1u << uStepTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                  ((uint8)((uint8)0 << uStepTimer_STATUS_CAPTURE_INT_MASK_SHIFT)))
#else
    #define uStepTimer_INIT_INTERRUPT_MODE (((uint8)((uint8)1u << uStepTimer_STATUS_TC_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << uStepTimer_STATUS_CAPTURE_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << uStepTimer_STATUS_FIFOFULL_INT_MASK_SHIFT)))
#endif /* (uStepTimer_UsingFixedFunction) */
#define uStepTimer_INIT_CAPTURE_COUNT      (2u)
#define uStepTimer_INIT_INT_CAPTURE_COUNT  ((uint8)((uint8)(1u - 1u) << uStepTimer_CTRL_INTCNT_SHIFT))


/***************************************
*           Registers
***************************************/

#if (uStepTimer_UsingFixedFunction) /* Implementation Specific Registers and Register Constants */


    /***************************************
    *    Fixed Function Registers
    ***************************************/

    #define uStepTimer_STATUS         (*(reg8 *) uStepTimer_TimerHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define uStepTimer_STATUS_MASK    (*(reg8 *) uStepTimer_TimerHW__SR0 )
    #define uStepTimer_CONTROL        (*(reg8 *) uStepTimer_TimerHW__CFG0)
    #define uStepTimer_CONTROL2       (*(reg8 *) uStepTimer_TimerHW__CFG1)
    #define uStepTimer_CONTROL2_PTR   ( (reg8 *) uStepTimer_TimerHW__CFG1)
    #define uStepTimer_RT1            (*(reg8 *) uStepTimer_TimerHW__RT1)
    #define uStepTimer_RT1_PTR        ( (reg8 *) uStepTimer_TimerHW__RT1)

    #if (CY_PSOC3 || CY_PSOC5LP)
        #define uStepTimer_CONTROL3       (*(reg8 *) uStepTimer_TimerHW__CFG2)
        #define uStepTimer_CONTROL3_PTR   ( (reg8 *) uStepTimer_TimerHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define uStepTimer_GLOBAL_ENABLE  (*(reg8 *) uStepTimer_TimerHW__PM_ACT_CFG)
    #define uStepTimer_GLOBAL_STBY_ENABLE  (*(reg8 *) uStepTimer_TimerHW__PM_STBY_CFG)

    #define uStepTimer_CAPTURE_LSB         (* (reg16 *) uStepTimer_TimerHW__CAP0 )
    #define uStepTimer_CAPTURE_LSB_PTR       ((reg16 *) uStepTimer_TimerHW__CAP0 )
    #define uStepTimer_PERIOD_LSB          (* (reg16 *) uStepTimer_TimerHW__PER0 )
    #define uStepTimer_PERIOD_LSB_PTR        ((reg16 *) uStepTimer_TimerHW__PER0 )
    #define uStepTimer_COUNTER_LSB         (* (reg16 *) uStepTimer_TimerHW__CNT_CMP0 )
    #define uStepTimer_COUNTER_LSB_PTR       ((reg16 *) uStepTimer_TimerHW__CNT_CMP0 )


    /***************************************
    *    Register Constants
    ***************************************/

    /* Fixed Function Block Chosen */
    #define uStepTimer_BLOCK_EN_MASK                     uStepTimer_TimerHW__PM_ACT_MSK
    #define uStepTimer_BLOCK_STBY_EN_MASK                uStepTimer_TimerHW__PM_STBY_MSK

    /* Control Register Bit Locations */
    /* Interrupt Count - Not valid for Fixed Function Block */
    #define uStepTimer_CTRL_INTCNT_SHIFT                  0x00u
    /* Trigger Polarity - Not valid for Fixed Function Block */
    #define uStepTimer_CTRL_TRIG_MODE_SHIFT               0x00u
    /* Trigger Enable - Not valid for Fixed Function Block */
    #define uStepTimer_CTRL_TRIG_EN_SHIFT                 0x00u
    /* Capture Polarity - Not valid for Fixed Function Block */
    #define uStepTimer_CTRL_CAP_MODE_SHIFT                0x00u
    /* Timer Enable - As defined in Register Map, part of TMRX_CFG0 register */
    #define uStepTimer_CTRL_ENABLE_SHIFT                  0x00u

    /* Control Register Bit Masks */
    #define uStepTimer_CTRL_ENABLE                        ((uint8)((uint8)0x01u << uStepTimer_CTRL_ENABLE_SHIFT))

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define uStepTimer_CTRL2_IRQ_SEL_SHIFT                 0x00u
    #define uStepTimer_CTRL2_IRQ_SEL                      ((uint8)((uint8)0x01u << uStepTimer_CTRL2_IRQ_SEL_SHIFT))

    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        /* As defined by Verilog Implementation */
        #define uStepTimer_CTRL_MODE_SHIFT                 0x01u
        #define uStepTimer_CTRL_MODE_MASK                 ((uint8)((uint8)0x07u << uStepTimer_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Control3 Register Bit Locations */
        #define uStepTimer_CTRL_RCOD_SHIFT        0x02u
        #define uStepTimer_CTRL_ENBL_SHIFT        0x00u
        #define uStepTimer_CTRL_MODE_SHIFT        0x00u

        /* Control3 Register Bit Masks */
        #define uStepTimer_CTRL_RCOD_MASK  ((uint8)((uint8)0x03u << uStepTimer_CTRL_RCOD_SHIFT)) /* ROD and COD bit masks */
        #define uStepTimer_CTRL_ENBL_MASK  ((uint8)((uint8)0x80u << uStepTimer_CTRL_ENBL_SHIFT)) /* HW_EN bit mask */
        #define uStepTimer_CTRL_MODE_MASK  ((uint8)((uint8)0x03u << uStepTimer_CTRL_MODE_SHIFT)) /* Run mode bit mask */

        #define uStepTimer_CTRL_RCOD       ((uint8)((uint8)0x03u << uStepTimer_CTRL_RCOD_SHIFT))
        #define uStepTimer_CTRL_ENBL       ((uint8)((uint8)0x80u << uStepTimer_CTRL_ENBL_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define uStepTimer_RT1_SHIFT                       0x04u
    /* Sync TC and CMP bit masks */
    #define uStepTimer_RT1_MASK                        ((uint8)((uint8)0x03u << uStepTimer_RT1_SHIFT))
    #define uStepTimer_SYNC                            ((uint8)((uint8)0x03u << uStepTimer_RT1_SHIFT))
    #define uStepTimer_SYNCDSI_SHIFT                   0x00u
    /* Sync all DSI inputs with Mask  */
    #define uStepTimer_SYNCDSI_MASK                    ((uint8)((uint8)0x0Fu << uStepTimer_SYNCDSI_SHIFT))
    /* Sync all DSI inputs */
    #define uStepTimer_SYNCDSI_EN                      ((uint8)((uint8)0x0Fu << uStepTimer_SYNCDSI_SHIFT))

    #define uStepTimer_CTRL_MODE_PULSEWIDTH            ((uint8)((uint8)0x01u << uStepTimer_CTRL_MODE_SHIFT))
    #define uStepTimer_CTRL_MODE_PERIOD                ((uint8)((uint8)0x02u << uStepTimer_CTRL_MODE_SHIFT))
    #define uStepTimer_CTRL_MODE_CONTINUOUS            ((uint8)((uint8)0x00u << uStepTimer_CTRL_MODE_SHIFT))

    /* Status Register Bit Locations */
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define uStepTimer_STATUS_TC_SHIFT                 0x07u
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define uStepTimer_STATUS_CAPTURE_SHIFT            0x06u
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define uStepTimer_STATUS_TC_INT_MASK_SHIFT        (uStepTimer_STATUS_TC_SHIFT - 0x04u)
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define uStepTimer_STATUS_CAPTURE_INT_MASK_SHIFT   (uStepTimer_STATUS_CAPTURE_SHIFT - 0x04u)

    /* Status Register Bit Masks */
    #define uStepTimer_STATUS_TC                       ((uint8)((uint8)0x01u << uStepTimer_STATUS_TC_SHIFT))
    #define uStepTimer_STATUS_CAPTURE                  ((uint8)((uint8)0x01u << uStepTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on TC */
    #define uStepTimer_STATUS_TC_INT_MASK              ((uint8)((uint8)0x01u << uStepTimer_STATUS_TC_INT_MASK_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on Capture */
    #define uStepTimer_STATUS_CAPTURE_INT_MASK         ((uint8)((uint8)0x01u << uStepTimer_STATUS_CAPTURE_INT_MASK_SHIFT))

#else   /* UDB Registers and Register Constants */


    /***************************************
    *           UDB Registers
    ***************************************/

    #define uStepTimer_STATUS              (* (reg8 *) uStepTimer_TimerUDB_rstSts_stsreg__STATUS_REG )
    #define uStepTimer_STATUS_MASK         (* (reg8 *) uStepTimer_TimerUDB_rstSts_stsreg__MASK_REG)
    #define uStepTimer_STATUS_AUX_CTRL     (* (reg8 *) uStepTimer_TimerUDB_rstSts_stsreg__STATUS_AUX_CTL_REG)
    #define uStepTimer_CONTROL             (* (reg8 *) uStepTimer_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG )
    
    #if(uStepTimer_Resolution <= 8u) /* 8-bit Timer */
        #define uStepTimer_CAPTURE_LSB         (* (reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
        #define uStepTimer_CAPTURE_LSB_PTR       ((reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
        #define uStepTimer_PERIOD_LSB          (* (reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
        #define uStepTimer_PERIOD_LSB_PTR        ((reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
        #define uStepTimer_COUNTER_LSB         (* (reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
        #define uStepTimer_COUNTER_LSB_PTR       ((reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
    #elif(uStepTimer_Resolution <= 16u) /* 8-bit Timer */
        #if(CY_PSOC3) /* 8-bit addres space */
            #define uStepTimer_CAPTURE_LSB         (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
            #define uStepTimer_CAPTURE_LSB_PTR       ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
            #define uStepTimer_PERIOD_LSB          (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
            #define uStepTimer_PERIOD_LSB_PTR        ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
            #define uStepTimer_COUNTER_LSB         (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
            #define uStepTimer_COUNTER_LSB_PTR       ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define uStepTimer_CAPTURE_LSB         (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_F0_REG )
            #define uStepTimer_CAPTURE_LSB_PTR       ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_F0_REG )
            #define uStepTimer_PERIOD_LSB          (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_D0_REG )
            #define uStepTimer_PERIOD_LSB_PTR        ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_D0_REG )
            #define uStepTimer_COUNTER_LSB         (* (reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_A0_REG )
            #define uStepTimer_COUNTER_LSB_PTR       ((reg16 *) uStepTimer_TimerUDB_sT32_timerdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */
    #elif(uStepTimer_Resolution <= 24u)/* 24-bit Timer */
        #define uStepTimer_CAPTURE_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
        #define uStepTimer_CAPTURE_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
        #define uStepTimer_PERIOD_LSB          (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
        #define uStepTimer_PERIOD_LSB_PTR        ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
        #define uStepTimer_COUNTER_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
        #define uStepTimer_COUNTER_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
    #else /* 32-bit Timer */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define uStepTimer_CAPTURE_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
            #define uStepTimer_CAPTURE_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__F0_REG )
            #define uStepTimer_PERIOD_LSB          (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
            #define uStepTimer_PERIOD_LSB_PTR        ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__D0_REG )
            #define uStepTimer_COUNTER_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
            #define uStepTimer_COUNTER_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define uStepTimer_CAPTURE_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_F0_REG )
            #define uStepTimer_CAPTURE_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_F0_REG )
            #define uStepTimer_PERIOD_LSB          (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_D0_REG )
            #define uStepTimer_PERIOD_LSB_PTR        ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_D0_REG )
            #define uStepTimer_COUNTER_LSB         (* (reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_A0_REG )
            #define uStepTimer_COUNTER_LSB_PTR       ((reg32 *) uStepTimer_TimerUDB_sT32_timerdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */ 
    #endif

    #define uStepTimer_COUNTER_LSB_PTR_8BIT       ((reg8 *) uStepTimer_TimerUDB_sT32_timerdp_u0__A0_REG )
    
    #if (uStepTimer_UsingHWCaptureCounter)
        #define uStepTimer_CAP_COUNT              (*(reg8 *) uStepTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define uStepTimer_CAP_COUNT_PTR          ( (reg8 *) uStepTimer_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define uStepTimer_CAPTURE_COUNT_CTRL     (*(reg8 *) uStepTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
        #define uStepTimer_CAPTURE_COUNT_CTRL_PTR ( (reg8 *) uStepTimer_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
    #endif /* (uStepTimer_UsingHWCaptureCounter) */


    /***************************************
    *       Register Constants
    ***************************************/

    /* Control Register Bit Locations */
    #define uStepTimer_CTRL_INTCNT_SHIFT              0x00u       /* As defined by Verilog Implementation */
    #define uStepTimer_CTRL_TRIG_MODE_SHIFT           0x02u       /* As defined by Verilog Implementation */
    #define uStepTimer_CTRL_TRIG_EN_SHIFT             0x04u       /* As defined by Verilog Implementation */
    #define uStepTimer_CTRL_CAP_MODE_SHIFT            0x05u       /* As defined by Verilog Implementation */
    #define uStepTimer_CTRL_ENABLE_SHIFT              0x07u       /* As defined by Verilog Implementation */

    /* Control Register Bit Masks */
    #define uStepTimer_CTRL_INTCNT_MASK               ((uint8)((uint8)0x03u << uStepTimer_CTRL_INTCNT_SHIFT))
    #define uStepTimer_CTRL_TRIG_MODE_MASK            ((uint8)((uint8)0x03u << uStepTimer_CTRL_TRIG_MODE_SHIFT))
    #define uStepTimer_CTRL_TRIG_EN                   ((uint8)((uint8)0x01u << uStepTimer_CTRL_TRIG_EN_SHIFT))
    #define uStepTimer_CTRL_CAP_MODE_MASK             ((uint8)((uint8)0x03u << uStepTimer_CTRL_CAP_MODE_SHIFT))
    #define uStepTimer_CTRL_ENABLE                    ((uint8)((uint8)0x01u << uStepTimer_CTRL_ENABLE_SHIFT))

    /* Bit Counter (7-bit) Control Register Bit Definitions */
    /* As defined by the Register map for the AUX Control Register */
    #define uStepTimer_CNTR_ENABLE                    0x20u

    /* Status Register Bit Locations */
    #define uStepTimer_STATUS_TC_SHIFT                0x00u  /* As defined by Verilog Implementation */
    #define uStepTimer_STATUS_CAPTURE_SHIFT           0x01u  /* As defined by Verilog Implementation */
    #define uStepTimer_STATUS_TC_INT_MASK_SHIFT       uStepTimer_STATUS_TC_SHIFT
    #define uStepTimer_STATUS_CAPTURE_INT_MASK_SHIFT  uStepTimer_STATUS_CAPTURE_SHIFT
    #define uStepTimer_STATUS_FIFOFULL_SHIFT          0x02u  /* As defined by Verilog Implementation */
    #define uStepTimer_STATUS_FIFONEMP_SHIFT          0x03u  /* As defined by Verilog Implementation */
    #define uStepTimer_STATUS_FIFOFULL_INT_MASK_SHIFT uStepTimer_STATUS_FIFOFULL_SHIFT

    /* Status Register Bit Masks */
    /* Sticky TC Event Bit-Mask */
    #define uStepTimer_STATUS_TC                      ((uint8)((uint8)0x01u << uStepTimer_STATUS_TC_SHIFT))
    /* Sticky Capture Event Bit-Mask */
    #define uStepTimer_STATUS_CAPTURE                 ((uint8)((uint8)0x01u << uStepTimer_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define uStepTimer_STATUS_TC_INT_MASK             ((uint8)((uint8)0x01u << uStepTimer_STATUS_TC_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define uStepTimer_STATUS_CAPTURE_INT_MASK        ((uint8)((uint8)0x01u << uStepTimer_STATUS_CAPTURE_SHIFT))
    /* NOT-Sticky FIFO Full Bit-Mask */
    #define uStepTimer_STATUS_FIFOFULL                ((uint8)((uint8)0x01u << uStepTimer_STATUS_FIFOFULL_SHIFT))
    /* NOT-Sticky FIFO Not Empty Bit-Mask */
    #define uStepTimer_STATUS_FIFONEMP                ((uint8)((uint8)0x01u << uStepTimer_STATUS_FIFONEMP_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define uStepTimer_STATUS_FIFOFULL_INT_MASK       ((uint8)((uint8)0x01u << uStepTimer_STATUS_FIFOFULL_SHIFT))

    #define uStepTimer_STATUS_ACTL_INT_EN             0x10u   /* As defined for the ACTL Register */

    /* Datapath Auxillary Control Register definitions */
    #define uStepTimer_AUX_CTRL_FIFO0_CLR             0x01u   /* As defined by Register map */
    #define uStepTimer_AUX_CTRL_FIFO1_CLR             0x02u   /* As defined by Register map */
    #define uStepTimer_AUX_CTRL_FIFO0_LVL             0x04u   /* As defined by Register map */
    #define uStepTimer_AUX_CTRL_FIFO1_LVL             0x08u   /* As defined by Register map */
    #define uStepTimer_STATUS_ACTL_INT_EN_MASK        0x10u   /* As defined for the ACTL Register */

#endif /* Implementation Specific Registers and Register Constants */

#endif  /* CY_Timer_v2_30_uStepTimer_H */


/* [] END OF FILE */
