/*******************************************************************************
* File Name: DE.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DE_ALIASES_H) /* Pins DE_ALIASES_H */
#define CY_PINS_DE_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define DE_0			(DE__0__PC)
#define DE_0_PS		(DE__0__PS)
#define DE_0_PC		(DE__0__PC)
#define DE_0_DR		(DE__0__DR)
#define DE_0_SHIFT	(DE__0__SHIFT)
#define DE_0_INTR	((uint16)((uint16)0x0003u << (DE__0__SHIFT*2u)))

#define DE_INTR_ALL	 ((uint16)(DE_0_INTR))


#endif /* End Pins DE_ALIASES_H */


/* [] END OF FILE */
