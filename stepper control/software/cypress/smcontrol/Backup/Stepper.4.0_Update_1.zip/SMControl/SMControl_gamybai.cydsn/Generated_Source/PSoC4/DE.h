/*******************************************************************************
* File Name: DE.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DE_H) /* Pins DE_H */
#define CY_PINS_DE_H

#include "cytypes.h"
#include "cyfitter.h"
#include "DE_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} DE_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   DE_Read(void);
void    DE_Write(uint8 value);
uint8   DE_ReadDataReg(void);
#if defined(DE__PC) || (CY_PSOC4_4200L) 
    void    DE_SetDriveMode(uint8 mode);
#endif
void    DE_SetInterruptMode(uint16 position, uint16 mode);
uint8   DE_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void DE_Sleep(void); 
void DE_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(DE__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define DE_DRIVE_MODE_BITS        (3)
    #define DE_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - DE_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the DE_SetDriveMode() function.
         *  @{
         */
        #define DE_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define DE_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define DE_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define DE_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define DE_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define DE_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define DE_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define DE_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define DE_MASK               DE__MASK
#define DE_SHIFT              DE__SHIFT
#define DE_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DE_SetInterruptMode() function.
     *  @{
     */
        #define DE_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define DE_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define DE_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define DE_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(DE__SIO)
    #define DE_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(DE__PC) && (CY_PSOC4_4200L)
    #define DE_USBIO_ENABLE               ((uint32)0x80000000u)
    #define DE_USBIO_DISABLE              ((uint32)(~DE_USBIO_ENABLE))
    #define DE_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define DE_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define DE_USBIO_ENTER_SLEEP          ((uint32)((1u << DE_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << DE_USBIO_SUSPEND_DEL_SHIFT)))
    #define DE_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << DE_USBIO_SUSPEND_SHIFT)))
    #define DE_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << DE_USBIO_SUSPEND_DEL_SHIFT)))
    #define DE_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(DE__PC)
    /* Port Configuration */
    #define DE_PC                 (* (reg32 *) DE__PC)
#endif
/* Pin State */
#define DE_PS                     (* (reg32 *) DE__PS)
/* Data Register */
#define DE_DR                     (* (reg32 *) DE__DR)
/* Input Buffer Disable Override */
#define DE_INP_DIS                (* (reg32 *) DE__PC2)

/* Interrupt configuration Registers */
#define DE_INTCFG                 (* (reg32 *) DE__INTCFG)
#define DE_INTSTAT                (* (reg32 *) DE__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define DE_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(DE__SIO)
    #define DE_SIO_REG            (* (reg32 *) DE__SIO)
#endif /* (DE__SIO_CFG) */

/* USBIO registers */
#if !defined(DE__PC) && (CY_PSOC4_4200L)
    #define DE_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define DE_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define DE_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define DE_DRIVE_MODE_SHIFT       (0x00u)
#define DE_DRIVE_MODE_MASK        (0x07u << DE_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins DE_H */


/* [] END OF FILE */
