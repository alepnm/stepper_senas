/*******************************************************************************
* File Name: mbPortTimerISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_mbPortTimerISR_H)
#define CY_ISR_mbPortTimerISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void mbPortTimerISR_Start(void);
void mbPortTimerISR_StartEx(cyisraddress address);
void mbPortTimerISR_Stop(void);

CY_ISR_PROTO(mbPortTimerISR_Interrupt);

void mbPortTimerISR_SetVector(cyisraddress address);
cyisraddress mbPortTimerISR_GetVector(void);

void mbPortTimerISR_SetPriority(uint8 priority);
uint8 mbPortTimerISR_GetPriority(void);

void mbPortTimerISR_Enable(void);
uint8 mbPortTimerISR_GetState(void);
void mbPortTimerISR_Disable(void);

void mbPortTimerISR_SetPending(void);
void mbPortTimerISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the mbPortTimerISR ISR. */
#define mbPortTimerISR_INTC_VECTOR            ((reg32 *) mbPortTimerISR__INTC_VECT)

/* Address of the mbPortTimerISR ISR priority. */
#define mbPortTimerISR_INTC_PRIOR             ((reg32 *) mbPortTimerISR__INTC_PRIOR_REG)

/* Priority of the mbPortTimerISR interrupt. */
#define mbPortTimerISR_INTC_PRIOR_NUMBER      mbPortTimerISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable mbPortTimerISR interrupt. */
#define mbPortTimerISR_INTC_SET_EN            ((reg32 *) mbPortTimerISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the mbPortTimerISR interrupt. */
#define mbPortTimerISR_INTC_CLR_EN            ((reg32 *) mbPortTimerISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the mbPortTimerISR interrupt state to pending. */
#define mbPortTimerISR_INTC_SET_PD            ((reg32 *) mbPortTimerISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the mbPortTimerISR interrupt. */
#define mbPortTimerISR_INTC_CLR_PD            ((reg32 *) mbPortTimerISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_mbPortTimerISR_H */


/* [] END OF FILE */
