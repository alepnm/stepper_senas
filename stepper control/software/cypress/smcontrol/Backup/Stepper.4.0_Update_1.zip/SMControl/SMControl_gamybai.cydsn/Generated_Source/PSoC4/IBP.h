/*******************************************************************************
* File Name: IBP.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IBP_H) /* Pins IBP_H */
#define CY_PINS_IBP_H

#include "cytypes.h"
#include "cyfitter.h"
#include "IBP_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} IBP_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   IBP_Read(void);
void    IBP_Write(uint8 value);
uint8   IBP_ReadDataReg(void);
#if defined(IBP__PC) || (CY_PSOC4_4200L) 
    void    IBP_SetDriveMode(uint8 mode);
#endif
void    IBP_SetInterruptMode(uint16 position, uint16 mode);
uint8   IBP_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void IBP_Sleep(void); 
void IBP_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(IBP__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define IBP_DRIVE_MODE_BITS        (3)
    #define IBP_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - IBP_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the IBP_SetDriveMode() function.
         *  @{
         */
        #define IBP_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define IBP_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define IBP_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define IBP_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define IBP_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define IBP_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define IBP_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define IBP_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define IBP_MASK               IBP__MASK
#define IBP_SHIFT              IBP__SHIFT
#define IBP_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in IBP_SetInterruptMode() function.
     *  @{
     */
        #define IBP_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define IBP_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define IBP_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define IBP_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(IBP__SIO)
    #define IBP_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(IBP__PC) && (CY_PSOC4_4200L)
    #define IBP_USBIO_ENABLE               ((uint32)0x80000000u)
    #define IBP_USBIO_DISABLE              ((uint32)(~IBP_USBIO_ENABLE))
    #define IBP_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define IBP_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define IBP_USBIO_ENTER_SLEEP          ((uint32)((1u << IBP_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << IBP_USBIO_SUSPEND_DEL_SHIFT)))
    #define IBP_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << IBP_USBIO_SUSPEND_SHIFT)))
    #define IBP_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << IBP_USBIO_SUSPEND_DEL_SHIFT)))
    #define IBP_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(IBP__PC)
    /* Port Configuration */
    #define IBP_PC                 (* (reg32 *) IBP__PC)
#endif
/* Pin State */
#define IBP_PS                     (* (reg32 *) IBP__PS)
/* Data Register */
#define IBP_DR                     (* (reg32 *) IBP__DR)
/* Input Buffer Disable Override */
#define IBP_INP_DIS                (* (reg32 *) IBP__PC2)

/* Interrupt configuration Registers */
#define IBP_INTCFG                 (* (reg32 *) IBP__INTCFG)
#define IBP_INTSTAT                (* (reg32 *) IBP__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define IBP_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(IBP__SIO)
    #define IBP_SIO_REG            (* (reg32 *) IBP__SIO)
#endif /* (IBP__SIO_CFG) */

/* USBIO registers */
#if !defined(IBP__PC) && (CY_PSOC4_4200L)
    #define IBP_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define IBP_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define IBP_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define IBP_DRIVE_MODE_SHIFT       (0x00u)
#define IBP_DRIVE_MODE_MASK        (0x07u << IBP_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins IBP_H */


/* [] END OF FILE */
