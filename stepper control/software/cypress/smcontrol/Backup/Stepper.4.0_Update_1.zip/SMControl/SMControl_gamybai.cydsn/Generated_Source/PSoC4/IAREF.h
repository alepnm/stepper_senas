/*******************************************************************************
* File Name: IAREF.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IAREF_H) /* Pins IAREF_H */
#define CY_PINS_IAREF_H

#include "cytypes.h"
#include "cyfitter.h"
#include "IAREF_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} IAREF_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   IAREF_Read(void);
void    IAREF_Write(uint8 value);
uint8   IAREF_ReadDataReg(void);
#if defined(IAREF__PC) || (CY_PSOC4_4200L) 
    void    IAREF_SetDriveMode(uint8 mode);
#endif
void    IAREF_SetInterruptMode(uint16 position, uint16 mode);
uint8   IAREF_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void IAREF_Sleep(void); 
void IAREF_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(IAREF__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define IAREF_DRIVE_MODE_BITS        (3)
    #define IAREF_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - IAREF_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the IAREF_SetDriveMode() function.
         *  @{
         */
        #define IAREF_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define IAREF_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define IAREF_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define IAREF_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define IAREF_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define IAREF_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define IAREF_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define IAREF_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define IAREF_MASK               IAREF__MASK
#define IAREF_SHIFT              IAREF__SHIFT
#define IAREF_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in IAREF_SetInterruptMode() function.
     *  @{
     */
        #define IAREF_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define IAREF_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define IAREF_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define IAREF_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(IAREF__SIO)
    #define IAREF_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(IAREF__PC) && (CY_PSOC4_4200L)
    #define IAREF_USBIO_ENABLE               ((uint32)0x80000000u)
    #define IAREF_USBIO_DISABLE              ((uint32)(~IAREF_USBIO_ENABLE))
    #define IAREF_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define IAREF_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define IAREF_USBIO_ENTER_SLEEP          ((uint32)((1u << IAREF_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << IAREF_USBIO_SUSPEND_DEL_SHIFT)))
    #define IAREF_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << IAREF_USBIO_SUSPEND_SHIFT)))
    #define IAREF_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << IAREF_USBIO_SUSPEND_DEL_SHIFT)))
    #define IAREF_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(IAREF__PC)
    /* Port Configuration */
    #define IAREF_PC                 (* (reg32 *) IAREF__PC)
#endif
/* Pin State */
#define IAREF_PS                     (* (reg32 *) IAREF__PS)
/* Data Register */
#define IAREF_DR                     (* (reg32 *) IAREF__DR)
/* Input Buffer Disable Override */
#define IAREF_INP_DIS                (* (reg32 *) IAREF__PC2)

/* Interrupt configuration Registers */
#define IAREF_INTCFG                 (* (reg32 *) IAREF__INTCFG)
#define IAREF_INTSTAT                (* (reg32 *) IAREF__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define IAREF_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(IAREF__SIO)
    #define IAREF_SIO_REG            (* (reg32 *) IAREF__SIO)
#endif /* (IAREF__SIO_CFG) */

/* USBIO registers */
#if !defined(IAREF__PC) && (CY_PSOC4_4200L)
    #define IAREF_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define IAREF_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define IAREF_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define IAREF_DRIVE_MODE_SHIFT       (0x00u)
#define IAREF_DRIVE_MODE_MASK        (0x07u << IAREF_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins IAREF_H */


/* [] END OF FILE */
