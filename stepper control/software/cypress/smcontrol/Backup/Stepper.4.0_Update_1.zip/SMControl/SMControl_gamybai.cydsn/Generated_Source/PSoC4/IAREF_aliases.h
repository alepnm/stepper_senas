/*******************************************************************************
* File Name: IAREF.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IAREF_ALIASES_H) /* Pins IAREF_ALIASES_H */
#define CY_PINS_IAREF_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define IAREF_0			(IAREF__0__PC)
#define IAREF_0_PS		(IAREF__0__PS)
#define IAREF_0_PC		(IAREF__0__PC)
#define IAREF_0_DR		(IAREF__0__DR)
#define IAREF_0_SHIFT	(IAREF__0__SHIFT)
#define IAREF_0_INTR	((uint16)((uint16)0x0003u << (IAREF__0__SHIFT*2u)))

#define IAREF_INTR_ALL	 ((uint16)(IAREF_0_INTR))


#endif /* End Pins IAREF_ALIASES_H */


/* [] END OF FILE */
