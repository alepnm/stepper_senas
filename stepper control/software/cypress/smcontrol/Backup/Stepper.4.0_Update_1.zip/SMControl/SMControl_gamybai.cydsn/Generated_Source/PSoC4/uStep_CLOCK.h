/*******************************************************************************
* File Name: uStep_CLOCK.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_uStep_CLOCK_H)
#define CY_CLOCK_uStep_CLOCK_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void uStep_CLOCK_StartEx(uint32 alignClkDiv);
#define uStep_CLOCK_Start() \
    uStep_CLOCK_StartEx(uStep_CLOCK__PA_DIV_ID)

#else

void uStep_CLOCK_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void uStep_CLOCK_Stop(void);

void uStep_CLOCK_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 uStep_CLOCK_GetDividerRegister(void);
uint8  uStep_CLOCK_GetFractionalDividerRegister(void);

#define uStep_CLOCK_Enable()                         uStep_CLOCK_Start()
#define uStep_CLOCK_Disable()                        uStep_CLOCK_Stop()
#define uStep_CLOCK_SetDividerRegister(clkDivider, reset)  \
    uStep_CLOCK_SetFractionalDividerRegister((clkDivider), 0u)
#define uStep_CLOCK_SetDivider(clkDivider)           uStep_CLOCK_SetDividerRegister((clkDivider), 1u)
#define uStep_CLOCK_SetDividerValue(clkDivider)      uStep_CLOCK_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define uStep_CLOCK_DIV_ID     uStep_CLOCK__DIV_ID

#define uStep_CLOCK_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define uStep_CLOCK_CTRL_REG   (*(reg32 *)uStep_CLOCK__CTRL_REGISTER)
#define uStep_CLOCK_DIV_REG    (*(reg32 *)uStep_CLOCK__DIV_REGISTER)

#define uStep_CLOCK_CMD_DIV_SHIFT          (0u)
#define uStep_CLOCK_CMD_PA_DIV_SHIFT       (8u)
#define uStep_CLOCK_CMD_DISABLE_SHIFT      (30u)
#define uStep_CLOCK_CMD_ENABLE_SHIFT       (31u)

#define uStep_CLOCK_CMD_DISABLE_MASK       ((uint32)((uint32)1u << uStep_CLOCK_CMD_DISABLE_SHIFT))
#define uStep_CLOCK_CMD_ENABLE_MASK        ((uint32)((uint32)1u << uStep_CLOCK_CMD_ENABLE_SHIFT))

#define uStep_CLOCK_DIV_FRAC_MASK  (0x000000F8u)
#define uStep_CLOCK_DIV_FRAC_SHIFT (3u)
#define uStep_CLOCK_DIV_INT_MASK   (0xFFFFFF00u)
#define uStep_CLOCK_DIV_INT_SHIFT  (8u)

#else 

#define uStep_CLOCK_DIV_REG        (*(reg32 *)uStep_CLOCK__REGISTER)
#define uStep_CLOCK_ENABLE_REG     uStep_CLOCK_DIV_REG
#define uStep_CLOCK_DIV_FRAC_MASK  uStep_CLOCK__FRAC_MASK
#define uStep_CLOCK_DIV_FRAC_SHIFT (16u)
#define uStep_CLOCK_DIV_INT_MASK   uStep_CLOCK__DIVIDER_MASK
#define uStep_CLOCK_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_uStep_CLOCK_H) */

/* [] END OF FILE */
