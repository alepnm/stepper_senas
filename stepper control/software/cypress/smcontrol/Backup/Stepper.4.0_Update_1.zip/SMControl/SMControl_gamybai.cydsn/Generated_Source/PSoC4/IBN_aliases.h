/*******************************************************************************
* File Name: IBN.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IBN_ALIASES_H) /* Pins IBN_ALIASES_H */
#define CY_PINS_IBN_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define IBN_0			(IBN__0__PC)
#define IBN_0_PS		(IBN__0__PS)
#define IBN_0_PC		(IBN__0__PC)
#define IBN_0_DR		(IBN__0__DR)
#define IBN_0_SHIFT	(IBN__0__SHIFT)
#define IBN_0_INTR	((uint16)((uint16)0x0003u << (IBN__0__SHIFT*2u)))

#define IBN_INTR_ALL	 ((uint16)(IBN_0_INTR))


#endif /* End Pins IBN_ALIASES_H */


/* [] END OF FILE */
