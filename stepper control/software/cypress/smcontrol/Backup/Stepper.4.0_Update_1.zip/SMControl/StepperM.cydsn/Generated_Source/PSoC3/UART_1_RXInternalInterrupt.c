/*******************************************************************************
* File Name: UART_1_RXInternalInterrupt_intc.c  
* Version 1.0
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/


#include <CYDEVICE.H>
#include <UART_1_RXInternalInterrupt.H>


/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START UART_1_RXInternalInterrupt_intc` */

/* `#END` */


/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_Start
********************************************************************************
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   void.
*
*
* Return:
*   void.
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_Start(void)
{
    /* For all we know the interrupt is active. */
    UART_1_RXInternalInterrupt_Disable();

    /* Set the ISR to point to the UART_1_RXInternalInterrupt Interrupt. */
    UART_1_RXInternalInterrupt_SetVector(UART_1_RXInternalInterrupt_Interrupt);

    /* Set the priority. */
    UART_1_RXInternalInterrupt_SetPriority(UART_1_RXInternalInterrupt_INTC_PRIOR_NUMBER);

    /* Enable it. */
    UART_1_RXInternalInterrupt_Enable();
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_Stop
********************************************************************************
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*
*
* Return:
*   void.
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_Stop(void)
{
    /* Disable this interrupt. */
    UART_1_RXInternalInterrupt_Disable();

    /* Set the ISR to point to the passive one. */
//    UART_1_RXInternalInterrupt_SetVector(CyDefaultInterrupt);
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_Interrupt
********************************************************************************
* Summary:
*   The default Interrupt Service Routine for UART_1_RXInternalInterrupt.
*
*   Add custom code between the coments to keep the next version of this file
*   from over writting your code.
*
*
*
* Parameters:  
*
*
* Return:
*   void.
*
*******************************************************************************/
CY_ISR(UART_1_RXInternalInterrupt_Interrupt)
{
    /*  Place your Interrupt code here. */
    /* `#START UART_1_RXInternalInterrupt_Interrupt` */

    /* `#END` */
}


/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_SetVector
********************************************************************************
* Summary:
*   Change the ISR vector for the Interrupt.
*
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_SetVector(cyisraddress address)
{
    CY_SET_REG16(UART_1_RXInternalInterrupt_INTC_VECTOR, (uint16) address);
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_GetVector
********************************************************************************
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*
*******************************************************************************/
cyisraddress UART_1_RXInternalInterrupt_GetVector(void)
{
    return (cyisraddress) CY_GET_REG16(UART_1_RXInternalInterrupt_INTC_VECTOR);
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_SetPriority
********************************************************************************
* Summary:
*   Sets the Priority of the Interrupt.
*
*
* Parameters:
*   priority: Priority of the interrupt. 0 - 7, 0 being the highest.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_SetPriority(uint8 priority)
{
    *UART_1_RXInternalInterrupt_INTC_PRIOR = priority << 5;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_GetPriority
********************************************************************************
* Summary:
*   Gets the Priority of the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   Priority of the interrupt. 0 - 7, 0 being the highest.
*
*
*******************************************************************************/
uint8 UART_1_RXInternalInterrupt_GetPriority(void)
{
    uint8 priority;


    priority = *UART_1_RXInternalInterrupt_INTC_PRIOR >> 5;

    return priority;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_Enable
********************************************************************************
* Summary:
*   Enables the interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_Enable(void)
{
    /* Enable the general interrupt. */
    *UART_1_RXInternalInterrupt_INTC_SET_EN = UART_1_RXInternalInterrupt__INTC_MASK;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_GetState
********************************************************************************
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   1 if enabled, 0 if disabled.
*
*
*******************************************************************************/
uint8 UART_1_RXInternalInterrupt_GetState(void)
{
    /* Get the state of the general interrupt. */
    return (*UART_1_RXInternalInterrupt_INTC_SET_EN & UART_1_RXInternalInterrupt__INTC_MASK) ? 1:0;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_Disable
********************************************************************************
* Summary:
*   Disables the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_Disable(void)
{
    /* Disable the general interrupt. */
    *UART_1_RXInternalInterrupt_INTC_CLR_EN = UART_1_RXInternalInterrupt__INTC_MASK;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_SetPending
********************************************************************************
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_SetPending(void)
{
    *UART_1_RXInternalInterrupt_INTC_SET_PD = UART_1_RXInternalInterrupt__INTC_MASK;
}

/*******************************************************************************
* Function Name: UART_1_RXInternalInterrupt_ClearPending
********************************************************************************
* Summary:
*   Clears a pending interrupt.
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void UART_1_RXInternalInterrupt_ClearPending(void)
{
    *UART_1_RXInternalInterrupt_INTC_CLR_PD = UART_1_RXInternalInterrupt__INTC_MASK;
}


















































