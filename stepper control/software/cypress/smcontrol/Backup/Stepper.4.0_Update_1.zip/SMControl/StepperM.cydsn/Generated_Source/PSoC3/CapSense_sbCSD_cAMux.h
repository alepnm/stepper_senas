/*******************************************************************************
* File Name: CapSense_sbCSD_cAMux.h
* Version 1.30
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module Amux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"

#if !defined(CY_AMUX_CapSense_sbCSD_cAMux_H)
#define CY_AMUX_CapSense_sbCSD_cAMux_H


/***************************************
*        Function Prototypes
***************************************/

void    CapSense_sbCSD_cAMux_Start(void);
void    CapSense_sbCSD_cAMux_Stop(void);
void    CapSense_sbCSD_cAMux_Select(uint8 channel);
void    CapSense_sbCSD_cAMux_FastSelect(uint8 channel);
void    CapSense_sbCSD_cAMux_DisconnectAll(void);



/***************************************
*           Parameter Defaults
***************************************/
#define CapSense_sbCSD_cAMux_CHANNELS  (4+2+1)
#define CapSense_sbCSD_cAMux_MUXTYPE   1

/***************************************
*              Constants
***************************************/


#define CapSense_sbCSD_cAMux_NULL_CHANNEL  0xFF
#define CapSense_sbCSD_cAMux_MUX_SINGLE   1
#define CapSense_sbCSD_cAMux_MUX_DIFF     2

/***************************************
*              Registers
***************************************/


/***************************************
*                Misc
***************************************/

#if(CapSense_sbCSD_cAMux_MUXTYPE == CapSense_sbCSD_cAMux_MUX_SINGLE)
#define CapSense_sbCSD_cAMux_Connect(channel) CapSense_sbCSD_cAMux_Set(channel)
#define CapSense_sbCSD_cAMux_Disconnect(channel) CapSense_sbCSD_cAMux_Unset(channel)
#else
void    CapSense_sbCSD_cAMux_Connect(uint8 channel);
void    CapSense_sbCSD_cAMux_Disconnect(uint8 channel);
#endif

#endif /* CY_AMUX_CapSense_sbCSD_cAMux_H */


/* [] END OF FILE */
