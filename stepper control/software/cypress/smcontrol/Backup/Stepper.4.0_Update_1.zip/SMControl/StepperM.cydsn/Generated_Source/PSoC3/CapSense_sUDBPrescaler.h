/*******************************************************************************
* File Name: CapSense_sUDBPrescaler.h  
* Version 1.0
*
* Description:
*  Contains the prototypes and constants for the functions available to the 
*  PWM user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "cyfitter.h"

#if !defined(CY_PWM_CapSense_sUDBPrescaler_H)
#define CY_PWM_CapSense_sUDBPrescaler_H

#define CapSense_sUDBPrescaler_Resolution 8
#define CapSense_sUDBPrescaler_UsingFixedFunction 0
#define CapSense_sUDBPrescaler_DeadBandMode 0
#define CapSense_sUDBPrescaler_KillModeMinTime 0
#define CapSense_sUDBPrescaler_KillMode 0
#define CapSense_sUDBPrescaler_PWMMode 0
#define CapSense_sUDBPrescaler_PWMModeIsCenterAligned 0
#define CapSense_sUDBPrescaler_DeadBandUsed 0
#define CapSense_sUDBPrescaler_DeadBand2_4 0
#if !defined(CapSense_sUDBPrescaler_PWMUDB_sSTSReg_stsreg__REMOVED)
    #define CapSense_sUDBPrescaler_UseStatus 1
#else
    #define CapSense_sUDBPrescaler_UseStatus 0
#endif
#if !defined(CapSense_sUDBPrescaler_PWMUDB_sCTRLReg_ctrlreg__REMOVED)
    #define CapSense_sUDBPrescaler_UseControl 1
#else
    #define CapSense_sUDBPrescaler_UseControl 0
#endif
#define CapSense_sUDBPrescaler_UseOneCompareMode 1
#define CapSense_sUDBPrescaler_MinimumKillTime 1
#define CapSense_sUDBPrescaler_EnableMode 0

/* Use Kill Mode Enumerated Types */
#define CapSense_sUDBPrescaler__B_PWM__DISABLED 0
#define CapSense_sUDBPrescaler__B_PWM__ASYNCHRONOUS 1
#define CapSense_sUDBPrescaler__B_PWM__SINGLECYCLE 2
#define CapSense_sUDBPrescaler__B_PWM__LATCHED 3
#define CapSense_sUDBPrescaler__B_PWM__MINTIME 4


/* Use Dead Band Mode Enumerated Types */
#define CapSense_sUDBPrescaler__B_PWM__DBMDISABLED 0
#define CapSense_sUDBPrescaler__B_PWM__DBM_2_4_CLOCKS 1
#define CapSense_sUDBPrescaler__B_PWM__DBM_256_CLOCKS 2


/* Used PWM Mode Enumerated Types */
#define CapSense_sUDBPrescaler__B_PWM__ONE_OUTPUT 0
#define CapSense_sUDBPrescaler__B_PWM__TWO_OUTPUTS 1
#define CapSense_sUDBPrescaler__B_PWM__DUAL_EDGE 2
#define CapSense_sUDBPrescaler__B_PWM__CENTER_ALIGN 3
#define CapSense_sUDBPrescaler__B_PWM__DITHER 5
#define CapSense_sUDBPrescaler__B_PWM__HARDWARESELECT 4


/* Used PWM Compare Mode Enumerated Types */
#define CapSense_sUDBPrescaler__B_PWM__LESS_THAN 1
#define CapSense_sUDBPrescaler__B_PWM__LESS_THAN_OR_EQUAL 2
#define CapSense_sUDBPrescaler__B_PWM__GREATER_THAN 3
#define CapSense_sUDBPrescaler__B_PWM__GREATER_THAN_OR_EQUAL_TO 4
#define CapSense_sUDBPrescaler__B_PWM__EQUAL 0
#define CapSense_sUDBPrescaler__B_PWM__FIRMWARE 5


/***************************************
 *   Function Prototypes
 **************************************/
void    CapSense_sUDBPrescaler_Start(void);
void    CapSense_sUDBPrescaler_Stop(void);
void    CapSense_sUDBPrescaler_SetInterruptMode(uint8 interruptMode);
uint8   CapSense_sUDBPrescaler_GetInterruptSource();
#if (CapSense_sUDBPrescaler_UseStatus || CapSense_sUDBPrescaler_UsingFixedFunction)
	uint8   CapSense_sUDBPrescaler_ReadStatusRegister(void);
#endif
#if (CapSense_sUDBPrescaler_UseControl)
	uint8   CapSense_sUDBPrescaler_ReadControlRegister(void);
	void    CapSense_sUDBPrescaler_WriteControlRegister(uint8 control);
#endif
#if CapSense_sUDBPrescaler_UseOneCompareMode
	void    CapSense_sUDBPrescaler_SetCompareMode(uint8 comparemode);
#else
	void    CapSense_sUDBPrescaler_SetCompareMode1(uint8 comparemode);
	void    CapSense_sUDBPrescaler_SetCompareMode2(uint8 comparemode);
#endif

#if (!CapSense_sUDBPrescaler_UsingFixedFunction)
uint8   CapSense_sUDBPrescaler_ReadCounter(void);
uint8  CapSense_sUDBPrescaler_ReadCapture(void);
#if (CapSense_sUDBPrescaler_UseStatus)
void CapSense_sUDBPrescaler_ClearFIFO(void);
#endif
#endif

void    CapSense_sUDBPrescaler_WriteCounter(uint8 counter);
void    CapSense_sUDBPrescaler_WritePeriod(uint8 period);
uint8   CapSense_sUDBPrescaler_ReadPeriod(void);
#if CapSense_sUDBPrescaler_UseOneCompareMode
    void    CapSense_sUDBPrescaler_WriteCompare(uint8 compare);
    uint8   CapSense_sUDBPrescaler_ReadCompare(void);
#else
    void    CapSense_sUDBPrescaler_WriteCompare1(uint8 compare);
    uint8   CapSense_sUDBPrescaler_ReadCompare1(void);
    void    CapSense_sUDBPrescaler_WriteCompare2(uint8 compare);
    uint8   CapSense_sUDBPrescaler_ReadCompare2(void);
#endif


#if (CapSense_sUDBPrescaler_DeadBandUsed)
	void    CapSense_sUDBPrescaler_WriteDeadTime(uint8 deadtime);
	uint8   CapSense_sUDBPrescaler_ReadDeadTime();
#endif

#if ( CapSense_sUDBPrescaler_KillModeMinTime)
	void CapSense_sUDBPrescaler_WriteKillTime(uint8 killtime);
	uint8 CapSense_sUDBPrescaler_ReadKillTime();
#endif

/***************************************
 *    Initialization Values
 **************************************/
#define CapSense_sUDBPrescaler_INIT_PERIOD_VALUE        255
#define CapSense_sUDBPrescaler_INIT_COMPARE_VALUE1      127
#define CapSense_sUDBPrescaler_INIT_COMPARE_VALUE2      63
#define CapSense_sUDBPrescaler_INIT_INTERRUPTS_MODE     ((0 << CapSense_sUDBPrescaler_STATUS_TC_INT_EN_MASK_SHIFT) | (0 << CapSense_sUDBPrescaler_STATUS_CMP2_INT_EN_MASK_SHIFT) | (0 << CapSense_sUDBPrescaler_STATUS_CMP1_INT_EN_MASK_SHIFT ) | (0 << CapSense_sUDBPrescaler_STATUS_KILL_INT_EN_MASK_SHIFT ))
#define CapSense_sUDBPrescaler_DEFAULT_COMPARE2_MODE    (1 << CapSense_sUDBPrescaler_CTRL_CMPMODE2_SHIFT)
#define CapSense_sUDBPrescaler_DEFAULT_COMPARE1_MODE    (1 << CapSense_sUDBPrescaler_CTRL_CMPMODE1_SHIFT)
#define CapSense_sUDBPrescaler_INIT_DEAD_TIME           1

/********************************
 ******     Registers       *****
 ******************************** */

#if (CapSense_sUDBPrescaler_UsingFixedFunction)
   #define CapSense_sUDBPrescaler_PERIOD_LSB      (*(reg16 *) CapSense_sUDBPrescaler_PWMHW__PER0)
   #define CapSense_sUDBPrescaler_PERIOD_LSB_PTR   ((reg16 *) CapSense_sUDBPrescaler_PWMHW__PER0)
   #define CapSense_sUDBPrescaler_COMPARE1_LSB    (*(reg16 *) CapSense_sUDBPrescaler_PWMHW__CNT_CMP0)
   #define CapSense_sUDBPrescaler_COMPARE1_LSB_PTR ((reg16 *) CapSense_sUDBPrescaler_PWMHW__CNT_CMP0)
   #define CapSense_sUDBPrescaler_COMPARE2_LSB     0x00u
   #define CapSense_sUDBPrescaler_COMPARE2_LSB_PTR 0x00u
   #define CapSense_sUDBPrescaler_COUNTER_LSB     (*(reg16 *) CapSense_sUDBPrescaler_PWMHW__CNT_CMP0)
   #define CapSense_sUDBPrescaler_COUNTER_LSB_PTR  ((reg16 *) CapSense_sUDBPrescaler_PWMHW__CNT_CMP0)
   #define CapSense_sUDBPrescaler_CAPTURE_LSB     (*(reg16 *) CapSense_sUDBPrescaler_PWMHW__CAP0)
   #define CapSense_sUDBPrescaler_CAPTURE_LSB_PTR  ((reg16 *) CapSense_sUDBPrescaler_PWMHW__CAP0)
   
#else
   #if(CapSense_sUDBPrescaler_PWMModeIsCenterAligned)
       #define CapSense_sUDBPrescaler_PERIOD_LSB      (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D1_REG)
       #define CapSense_sUDBPrescaler_PERIOD_LSB_PTR   ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D1_REG)
   #else
       #define CapSense_sUDBPrescaler_PERIOD_LSB      (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__F0_REG)
       #define CapSense_sUDBPrescaler_PERIOD_LSB_PTR   ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__F0_REG)
   #endif
   #define CapSense_sUDBPrescaler_COMPARE1_LSB    (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D0_REG)
   #define CapSense_sUDBPrescaler_COMPARE1_LSB_PTR ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D0_REG)
   #define CapSense_sUDBPrescaler_COMPARE2_LSB    (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D1_REG)
   #define CapSense_sUDBPrescaler_COMPARE2_LSB_PTR ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__D1_REG)
   #define CapSense_sUDBPrescaler_COUNTER_LSB     (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__A0_REG)
   #define CapSense_sUDBPrescaler_COUNTER_LSB_PTR  ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__A0_REG)
   #define CapSense_sUDBPrescaler_CAPTURE_LSB     (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__F1_REG)
   #define CapSense_sUDBPrescaler_CAPTURE_LSB_PTR  ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__F1_REG)
   #define CapSense_sUDBPrescaler_AUX_CONTROLDP0      (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__DP_AUX_CTL_REG)
   #define CapSense_sUDBPrescaler_AUX_CONTROLDP0_PTR  ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u0__DP_AUX_CTL_REG)
   #if (CapSense_sUDBPrescaler_Resolution == 16)
       #define CapSense_sUDBPrescaler_AUX_CONTROLDP1    (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u1__DP_AUX_CTL_REG)
       #define CapSense_sUDBPrescaler_AUX_CONTROLDP1_PTR  ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sP8_pwmdp_u1__DP_AUX_CTL_REG)
   #endif
#endif
   
#if(CapSense_sUDBPrescaler_KillModeMinTime )
    #define CapSense_sUDBPrescaler_KILLMODEMINTIME      (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    #define CapSense_sUDBPrescaler_KILLMODEMINTIME_PTR   ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    /* Fixed Function Block has no Kill Mode parameters because it is Asynchronous only */
#endif

#if(CapSense_sUDBPrescaler_DeadBandMode == CapSense_sUDBPrescaler__B_PWM__DBM_256_CLOCKS)
    #define CapSense_sUDBPrescaler_DEADBAND_COUNT        (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define CapSense_sUDBPrescaler_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
#elif(CapSense_sUDBPrescaler_DeadBandMode == CapSense_sUDBPrescaler__B_PWM__DBM_2_4_CLOCKS)
    /* In Fixed Function Block these bits are in the control blocks control register */
    #if (CapSense_sUDBPrescaler_UsingFixedFunction)
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT        (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__CFG0) 
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sUDBPrescaler_PWMHW__CFG0)
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_MASK    (0x03u << CapSense_sUDBPrescaler_DEADBAND_COUNT_SHIFT) 
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_SHIFT   0x06u /* As defined by the Register Map as DEADBAND_PERIOD[1:0] in CFG0 */ 
    #else
        /* Lower two bits of the added control register define the count 1-3 */
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT        (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sDB3_dbctrlreg__CONTROL_REG)
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sUDBPrescaler_PWMUDB_sDB3_dbctrlreg__CONTROL_REG)
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_MASK    (0x03u << CapSense_sUDBPrescaler_DEADBAND_COUNT_SHIFT) 
        #define CapSense_sUDBPrescaler_DEADBAND_COUNT_SHIFT   0x00u /* As defined by the verilog implementation of the Control Register */
    #endif
#endif



#if (CapSense_sUDBPrescaler_UsingFixedFunction)
    #define CapSense_sUDBPrescaler_STATUS                (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__SR0)
    #define CapSense_sUDBPrescaler_STATUS_MASK           (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__SR0)
    #define CapSense_sUDBPrescaler_CONTROL               (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__CFG0)
    #define CapSense_sUDBPrescaler_CONTROL2              (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__CFG1)
    #define CapSense_sUDBPrescaler_GLOBAL_ENABLE         (*(reg8 *) CapSense_sUDBPrescaler_PWMHW__PM_ACT_CFG)

    /***********************************
    *     Constants
    ***********************************/
    /* Fixed Function Block Chosen */
    #define CapSense_sUDBPrescaler_BLOCK_EN_MASK          CapSense_sUDBPrescaler_PWMHW__PM_ACT_MSK
    /* Control Register definitions */
    #define CapSense_sUDBPrescaler_CTRL_ENABLE_SHIFT      0x00u
    #define CapSense_sUDBPrescaler_CTRL_RESET_SHIFT       0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE2_SHIFT    0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE1_SHIFT    0x01u   /* As defined by Register map as MODE_CFG bits in CFG1*/
    #define CapSense_sUDBPrescaler_CTRL_DEAD_TIME_SHIFT   0x06u   /* As defined by Register map */
    /* Fixed Function Block Only CFG register bit definitions */
    #define CapSense_sUDBPrescaler_CFG0_MODE              0x03u   /* Enable the block to run and set to compare mode */
    #define CapSense_sUDBPrescaler_CFG0_DB                0x20u   /* As defined by Register map as DB bit in CFG0 */

    /* Control Register Bit Masks */
    #define CapSense_sUDBPrescaler_CTRL_ENABLE            (0x01u << CapSense_sUDBPrescaler_CTRL_ENABLE_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_RESET             (0x01u << CapSense_sUDBPrescaler_CTRL_RESET_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE2_MASK     (0x07u << CapSense_sUDBPrescaler_CTRL_CMPMODE2_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE1_MASK     (0x07u << CapSense_sUDBPrescaler_CTRL_CMPMODE1_SHIFT)
    
    /* Control2 Register Bit Masks */
    #define CapSense_sUDBPrescaler_CTRL2_IRQ_SEL_SHIFT    0x00u       /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define CapSense_sUDBPrescaler_CTRL2_IRQ_SEL          (0x01u << CapSense_sUDBPrescaler_CTRL2_IRQ_SEL_SHIFT)  
    
    /* Status Register Bit Locations */
    #define CapSense_sUDBPrescaler_STATUS_KILL_SHIFT          0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_SHIFT    0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_SHIFT      0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_TC_SHIFT            0x07u   /* As defined by Register map as TC in SR0 */
    #define CapSense_sUDBPrescaler_STATUS_CMP2_SHIFT          0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT          0x06u   /* As defined by the Register map as CAP_CMP in SR0 */
    /* Status Register Interrupt Enable Bit Locations */
    #define CapSense_sUDBPrescaler_STATUS_KILL_INT_EN_MASK_SHIFT          (0x00u)    /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_TC_INT_EN_MASK_SHIFT            (CapSense_sUDBPrescaler_STATUS_TC_SHIFT - 4)
    #define CapSense_sUDBPrescaler_STATUS_CMP2_INT_EN_MASK_SHIFT          (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_CMP1_INT_EN_MASK_SHIFT          (CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT - 4)
    /* Status Register Bit Masks */
    #define CapSense_sUDBPrescaler_STATUS_KILL            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY      (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL        (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_TC              (0x01u << CapSense_sUDBPrescaler_STATUS_TC_SHIFT)
    #define CapSense_sUDBPrescaler_STATUS_CMP2            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_CMP1            (0x01u << CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT)
    /* Status Register Interrupt Bit Masks*/
    #define CapSense_sUDBPrescaler_STATUS_KILL_INT_EN_MASK            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_INT_EN_MASK      (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_INT_EN_MASK        (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_TC_INT_EN_MASK              (CapSense_sUDBPrescaler_STATUS_TC >> 4)
    #define CapSense_sUDBPrescaler_STATUS_CMP2_INT_EN_MASK            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sUDBPrescaler_STATUS_CMP1_INT_EN_MASK            (CapSense_sUDBPrescaler_STATUS_CMP1 >> 4)

    /* Datapath Auxillary Control Register definitions */
    //#define CapSense_sUDBPrescaler_AUX_CTRL_FIFO0_CLR         0x01u   /* As defined by Register map */
    //#define CapSense_sUDBPrescaler_AUX_CTRL_FIFO1_CLR       0x02u   /* As defined by Register map */
    //#define CapSense_sUDBPrescaler_AUX_CTRL_FIFO0_LVL       0x04u   /* As defined by Register map */
    //#define CapSense_sUDBPrescaler_AUX_CTRL_FIFO1_LVL       0x08u   /* As defined by Register map */
    //#define CapSense_sUDBPrescaler_STATUS_ACTL_INT_EN_MASK    0x10u   /* As defined for the ACTL Register */
#else
    #define CapSense_sUDBPrescaler_STATUS                (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sSTSReg_stsreg__STATUS_REG )
    #define CapSense_sUDBPrescaler_STATUS_MASK           (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sSTSReg_stsreg__MASK_REG)
    #define CapSense_sUDBPrescaler_STATUS_AUX_CTRL       (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sSTSReg_stsreg__STATUS_AUX_CTL_REG)
    #define CapSense_sUDBPrescaler_CONTROL               (*(reg8 *) CapSense_sUDBPrescaler_PWMUDB_sCTRLReg_ctrlreg__CONTROL_REG)
    /***********************************
    *     Constants
    ***********************************/
    /* Control Register definitions */
    #define CapSense_sUDBPrescaler_CTRL_ENABLE_SHIFT      0x07u
    #define CapSense_sUDBPrescaler_CTRL_RESET_SHIFT       0x06u
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE2_SHIFT    0x03u
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE1_SHIFT    0x00u
	#define CapSense_sUDBPrescaler_CTRL_DEAD_TIME_SHIFT   0x00u   /* No Shift Needed for UDB block */
    /* Control Register Bit Masks */
    #define CapSense_sUDBPrescaler_CTRL_ENABLE            (0x01u << CapSense_sUDBPrescaler_CTRL_ENABLE_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_RESET             (0x01u << CapSense_sUDBPrescaler_CTRL_RESET_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE2_MASK     (0x07u << CapSense_sUDBPrescaler_CTRL_CMPMODE2_SHIFT)
    #define CapSense_sUDBPrescaler_CTRL_CMPMODE1_MASK     (0x07u << CapSense_sUDBPrescaler_CTRL_CMPMODE1_SHIFT) 
    
    /* Status Register Bit Locations */
    #define CapSense_sUDBPrescaler_STATUS_KILL_SHIFT          0x05u
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_SHIFT    0x04u
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_SHIFT      0x03u  
    #define CapSense_sUDBPrescaler_STATUS_TC_SHIFT            0x02u
    #define CapSense_sUDBPrescaler_STATUS_CMP2_SHIFT          0x01u
    #define CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT          0x00u
    /* Status Register Interrupt Enable Bit Locations - UDB Status Interrupt Mask match Status Bit Locations*/
    #define CapSense_sUDBPrescaler_STATUS_KILL_INT_EN_MASK_SHIFT          CapSense_sUDBPrescaler_STATUS_KILL_SHIFT          
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_SHIFT    
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      CapSense_sUDBPrescaler_STATUS_FIFOFULL_SHIFT        
    #define CapSense_sUDBPrescaler_STATUS_TC_INT_EN_MASK_SHIFT            CapSense_sUDBPrescaler_STATUS_TC_SHIFT            
    #define CapSense_sUDBPrescaler_STATUS_CMP2_INT_EN_MASK_SHIFT          CapSense_sUDBPrescaler_STATUS_CMP2_SHIFT          
    #define CapSense_sUDBPrescaler_STATUS_CMP1_INT_EN_MASK_SHIFT          CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT   
    /* Status Register Bit Masks */
    #define CapSense_sUDBPrescaler_STATUS_KILL            (0x00u << CapSense_sUDBPrescaler_STATUS_KILL_SHIFT )
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL        (0x01u << CapSense_sUDBPrescaler_STATUS_FIFOFULL_SHIFT)
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY      (0x01u << CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_SHIFT)
    #define CapSense_sUDBPrescaler_STATUS_TC              (0x01u << CapSense_sUDBPrescaler_STATUS_TC_SHIFT)
    #define CapSense_sUDBPrescaler_STATUS_CMP2            (0x01u << CapSense_sUDBPrescaler_STATUS_CMP2_SHIFT) 
    #define CapSense_sUDBPrescaler_STATUS_CMP1            (0x01u << CapSense_sUDBPrescaler_STATUS_CMP1_SHIFT)
    /* Status Register Interrupt Bit Masks  - UDB Status Interrupt Mask match Status Bit Locations */
    #define CapSense_sUDBPrescaler_STATUS_KILL_INT_EN_MASK            CapSense_sUDBPrescaler_STATUS_KILL
    #define CapSense_sUDBPrescaler_STATUS_FIFOFULL_INT_EN_MASK        CapSense_sUDBPrescaler_STATUS_FIFOFULL
    #define CapSense_sUDBPrescaler_STATUS_FIFONEMPTY_INT_EN_MASK      CapSense_sUDBPrescaler_STATUS_FIFONEMPTY
    #define CapSense_sUDBPrescaler_STATUS_TC_INT_EN_MASK              CapSense_sUDBPrescaler_STATUS_TC
    #define CapSense_sUDBPrescaler_STATUS_CMP2_INT_EN_MASK            CapSense_sUDBPrescaler_STATUS_CMP2
    #define CapSense_sUDBPrescaler_STATUS_CMP1_INT_EN_MASK            CapSense_sUDBPrescaler_STATUS_CMP1
                                                          
    /* Datapath Auxillary Control Register definitions */
    #define CapSense_sUDBPrescaler_AUX_CTRL_FIFO0_CLR     0x01u
    #define CapSense_sUDBPrescaler_AUX_CTRL_FIFO1_CLR     0x02u
    #define CapSense_sUDBPrescaler_AUX_CTRL_FIFO0_LVL     0x04u
    #define CapSense_sUDBPrescaler_AUX_CTRL_FIFO1_LVL     0x08u
    #define CapSense_sUDBPrescaler_STATUS_ACTL_INT_EN_MASK  0x10u /* As defined for the ACTL Register */
#endif /* CapSense_sUDBPrescaler_UsingFixedFunction */

#endif  /* CY_PWM_CapSense_sUDBPrescaler_H */
