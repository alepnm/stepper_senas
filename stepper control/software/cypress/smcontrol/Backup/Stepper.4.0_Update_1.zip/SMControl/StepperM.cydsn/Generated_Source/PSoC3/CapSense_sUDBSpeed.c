/*******************************************************************************
* File Name: CapSense_sUDBSpeed.c  
* Version 1.10
*
* Description:
*  The PWM User Module consist of an 8 or 16-bit counter with two 8 or 16-bit
*  comparitors.  Each instance of this user module is capable of generating
*  two PWM outputs with the same period.  The pulse width is selectable
*  between 1 and 255/65535.  The period is selectable between 2 and 255/65536 clocks. 
*  The compare value output may be configured to be active when the present 
*  counter is less than or less than/equal to the compare value.
*  A terminal count output is also provided.  It generates a pulse one clock
*  width wide when the counter is equal to zero.
*
* Note:
*
*******************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "CapSense_sUDBSpeed.h"

uint8 CapSense_sUDBSpeed_initvar = 0;


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_Start
********************************************************************************
* Summary:
*  The start function initializes the pwm with the default values, the 
*  enables the counter to begin counting.  It does not enable interrupts,
*  the EnableInt command should be called if interrupt generation is required.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_Start(void) 
{
    if(CapSense_sUDBSpeed_initvar == 0)
    {
        #if (CapSense_sUDBSpeed_UsingFixedFunction || CapSense_sUDBSpeed_UseControl)
        uint8 ctrl;
        #endif
        CapSense_sUDBSpeed_initvar = 1;
        
        #if (CapSense_sUDBSpeed_UsingFixedFunction)
            /* Mode Bit of the Configuration Register must be 1 before */
            /* you are allowed to write the compare value (FF only) */
            CapSense_sUDBSpeed_CONTROL |= CapSense_sUDBSpeed_CFG0_MODE;
            #if CapSense_sUDBSpeed_DeadBand2_4
                CapSense_sUDBSpeed_CONTROL |= CapSense_sUDBSpeed_CFG0_DB;
            #endif
            ctrl = CapSense_sUDBSpeed_CONTROL2 & ~CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK;
            CapSense_sUDBSpeed_CONTROL2 = ctrl | CapSense_sUDBSpeed_DEFAULT_COMPARE1_MODE;
        #elif (CapSense_sUDBSpeed_UseControl)
            /* Set the default compare mode defined in the parameter */
            ctrl = CapSense_sUDBSpeed_CONTROL & ~CapSense_sUDBSpeed_CTRL_CMPMODE2_MASK & ~CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK;
            CapSense_sUDBSpeed_CONTROL = ctrl | CapSense_sUDBSpeed_DEFAULT_COMPARE2_MODE | CapSense_sUDBSpeed_DEFAULT_COMPARE1_MODE;
        #endif 
        
        #if (!CapSense_sUDBSpeed_UsingFixedFunction)
            #if (CapSense_sUDBSpeed_Resolution == 8)
                /* Set FIFO 0 to 1 byte register for period*/
               CapSense_sUDBSpeed_AUX_CONTROLDP0 |= (CapSense_sUDBSpeed_AUX_CTRL_FIFO0_CLR);
            #else /* (CapSense_sUDBSpeed_Resolution == 16)*/
               /* Set FIFO 0 to 1 byte register for period */
               CapSense_sUDBSpeed_AUX_CONTROLDP0 |= (CapSense_sUDBSpeed_AUX_CTRL_FIFO0_CLR);
               CapSense_sUDBSpeed_AUX_CONTROLDP1 |= (CapSense_sUDBSpeed_AUX_CTRL_FIFO0_CLR);
            #endif
        #endif
        
        CapSense_sUDBSpeed_WritePeriod(CapSense_sUDBSpeed_INIT_PERIOD_VALUE);
        //CapSense_sUDBSpeed_WriteCounter(CapSense_sUDBSpeed_INIT_PERIOD_VALUE);
        
        #if CapSense_sUDBSpeed_UseOneCompareMode
            CapSense_sUDBSpeed_WriteCompare(CapSense_sUDBSpeed_INIT_COMPARE_VALUE1);
        #else
            CapSense_sUDBSpeed_WriteCompare1(CapSense_sUDBSpeed_INIT_COMPARE_VALUE1);
            CapSense_sUDBSpeed_WriteCompare2(CapSense_sUDBSpeed_INIT_COMPARE_VALUE2);
        #endif
        
        #if CapSense_sUDBSpeed_KillModeMinTime
            CapSense_sUDBSpeed_WriteKillTime(CapSense_sUDBSpeed_MinimumKillTime);
        #endif
        
        #if CapSense_sUDBSpeed_DeadBandUsed
            CapSense_sUDBSpeed_WriteDeadTime( CapSense_sUDBSpeed_INIT_DEAD_TIME );
        #endif

        #if (CapSense_sUDBSpeed_UseStatus || CapSense_sUDBSpeed_UsingFixedFunction)
        CapSense_sUDBSpeed_SetInterruptMode(CapSense_sUDBSpeed_INIT_INTERRUPTS_MODE);
        #endif
        
        #if (CapSense_sUDBSpeed_UsingFixedFunction)
            /* Globally Enable the Fixed Function Block chosen */
            CapSense_sUDBSpeed_GLOBAL_ENABLE |= CapSense_sUDBSpeed_BLOCK_EN_MASK;
            /* Set the Interrupt source to come from the status register */
            CapSense_sUDBSpeed_CONTROL2 |= CapSense_sUDBSpeed_CTRL2_IRQ_SEL;
        #else
            #if(CapSense_sUDBSpeed_UseStatus)
                /* Use the interrupt output of the status register for IRQ output */
                CapSense_sUDBSpeed_STATUS_AUX_CTRL |= CapSense_sUDBSpeed_STATUS_ACTL_INT_EN_MASK;
            #endif
        #endif
    }
    #if (CapSense_sUDBSpeed_UseControl)
        CapSense_sUDBSpeed_CONTROL |= CapSense_sUDBSpeed_CTRL_ENABLE;
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_Stop
********************************************************************************
* Summary:
*  The stop function halts the PWM, but does not change any modes or disable
*  interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_Stop(void)
{
    #if (CapSense_sUDBSpeed_UseControl || CapSense_sUDBSpeed_UsingFixedFunction)
        CapSense_sUDBSpeed_CONTROL &= ~CapSense_sUDBSpeed_CTRL_ENABLE;
    #endif
}


#if (CapSense_sUDBSpeed_UseStatus || CapSense_sUDBSpeed_UsingFixedFunction)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_SetInterruptMode
********************************************************************************
* Summary:
*  This function is used to set enable the individual interrupt sources.
*
* Parameters:  
*  irqMode:  Enables or disables the interrupt source, compare1, compare2, and 
*            terminal count.  Also, the Less Than or Less Than or equal To 
*            mode may be changed as well with this function. 
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_SetInterruptMode(uint8 interruptMode)
{
    /* Set the status Registers Mask Register with the bit-field */
    CapSense_sUDBSpeed_STATUS_MASK = interruptMode; 
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_GetInterruptSource
********************************************************************************
* Summary:
*  This function is used to get the source of an interrupt by the ISR routine
*
* Parameters:  
*  void  
*
* Return: 
*  Status Register containing bit-field of interrupt source
*
* Side Effects:  The status register is clear on Read.  This will clear the 
*                interrupt.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_GetInterruptSource(void)
{
    return CapSense_sUDBSpeed_STATUS;
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadStatusRegister
********************************************************************************
* Summary:
*  Reads the status register and returns it's state. This function should use
*  defined types for the bit-field information as the bits in this register may
*  be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  The contents of the status register
*
* Side Effects:
*  Some status register bits are clear on read. 
*******************************************************************************/
uint8   CapSense_sUDBSpeed_ReadStatusRegister(void)
{
    return CapSense_sUDBSpeed_STATUS;
}
#endif /* (CapSense_sUDBSpeed_UseStatus || CapSense_sUDBSpeed_UsingFixedFunction) */


#if (CapSense_sUDBSpeed_UseControl || CapSense_sUDBSpeed_UsingFixedFunction)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadControlRegister
********************************************************************************
* Summary:
*  Reads the control register and returns it's state. This function should use
*  defined types for the bit-field information as the bits in this register may
*  be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  The contents of the control register
*
*******************************************************************************/
uint8   CapSense_sUDBSpeed_ReadControlRegister(void)
{
    return CapSense_sUDBSpeed_CONTROL;
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteControlRegister
********************************************************************************
* Summary:
*  Sets the bit-field of the control register.  This function should use
*  defined types for the bit-field information as the bits in this
*  register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  The contents of the control register
*
*******************************************************************************/
void    CapSense_sUDBSpeed_WriteControlRegister(uint8 control)
{
    CapSense_sUDBSpeed_CONTROL = control;
}
#endif  /* (CapSense_sUDBSpeed_UseControl || CapSense_sUDBSpeed_UsingFixedFunction) */


#if CapSense_sUDBSpeed_UseOneCompareMode
#if CapSense_sUDBSpeed_CompareMode1SW
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_SetCompareMode
********************************************************************************
* Summary:
*  This function writes the Compare Mode for the pwm output when in Dither mode
*
* Parameters:
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_SetCompareMode( uint8 comparemode )
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        uint8 comparemodemasked = (comparemode << CapSense_sUDBSpeed_CTRL_CMPMODE1_SHIFT);
        CapSense_sUDBSpeed_CONTROL2 &= ~CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK; /*Clear Existing Data */
        CapSense_sUDBSpeed_CONTROL2 |= comparemodemasked;
        
    #elif (CapSense_sUDBSpeed_UseControl)
        uint8 comparemode1masked = (comparemode << CapSense_sUDBSpeed_CTRL_CMPMODE1_SHIFT) & CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK;
        uint8 comparemode2masked = (comparemode << CapSense_sUDBSpeed_CTRL_CMPMODE2_SHIFT) & CapSense_sUDBSpeed_CTRL_CMPMODE2_MASK;
        CapSense_sUDBSpeed_CONTROL &= ~(CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK | CapSense_sUDBSpeed_CTRL_CMPMODE2_MASK); /*Clear existing mode */
        CapSense_sUDBSpeed_CONTROL |= (comparemode1masked | comparemode2masked);
        
    #else
        uint8 temp = comparemode;
    #endif
}
#endif /* CapSense_sUDBSpeed_CompareMode1SW */

#else /* UseOneCompareMode */

#if CapSense_sUDBSpeed_CompareMode1SW
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_SetCompareMode1
********************************************************************************
* Summary:
*  This function writes the Compare Mode for the pwm or pwm1 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_SetCompareMode1( uint8 comparemode )
{
    uint8 comparemodemasked = (comparemode << CapSense_sUDBSpeed_CTRL_CMPMODE1_SHIFT) & CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK;
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        CapSense_sUDBSpeed_CONTROL2 &= CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK; /*Clear existing mode */
        CapSense_sUDBSpeed_CONTROL2 |= comparemodemasked; 
    #elif (CapSense_sUDBSpeed_UseControl)
        CapSense_sUDBSpeed_CONTROL &= CapSense_sUDBSpeed_CTRL_CMPMODE1_MASK; /*Clear existing mode */
        CapSense_sUDBSpeed_CONTROL |= comparemodemasked;
    #endif    
}
#endif /* CapSense_sUDBSpeed_CompareMode1SW */

#if CapSense_sUDBSpeed_CompareMode2SW
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_SetCompareMode2
********************************************************************************
* Summary:
*  This function writes the Compare Mode for the pwm or pwm2 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_SetCompareMode2( uint8 comparemode )
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        /* Do Nothing because there is no second Compare Mode Register in FF block*/ 
    #elif (CapSense_sUDBSpeed_UseControl)
    uint8 comparemodemasked = (comparemode << CapSense_sUDBSpeed_CTRL_CMPMODE2_SHIFT) & CapSense_sUDBSpeed_CTRL_CMPMODE2_MASK;
    CapSense_sUDBSpeed_CONTROL &= CapSense_sUDBSpeed_CTRL_CMPMODE2_MASK; /*Clear existing mode */
    CapSense_sUDBSpeed_CONTROL |= comparemodemasked;
    #endif    
}
#endif /*CapSense_sUDBSpeed_CompareMode2SW */
#endif /* UseOneCompareMode */

/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteCounter
********************************************************************************
* Summary:
*  This function is used to change the counter value.
*
* Parameters:  
*  counter:  This value may be between 1 and (2^Resolution)-1.   
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteCounter(uint8 counter)
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        uint16 counter_temp = (uint16)counter;
        CY_SET_REG16(CapSense_sUDBSpeed_COUNTER_LSB_PTR, counter_temp);
    #else
        CY_SET_REG8(CapSense_sUDBSpeed_COUNTER_LSB_PTR, counter);
    #endif
}


#if (!CapSense_sUDBSpeed_UsingFixedFunction)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadCounter
********************************************************************************
* Summary:
*  This function returns the current value of the counter.  It doesn't matter
*  if the counter is enabled or running.
*
* Parameters:  
*  void  
*
* Return: 
*  The current value of the counter.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadCounter(void)
{
    CY_GET_REG8(CapSense_sUDBSpeed_COUNTERCAP_LSB_PTR);
    return ( CY_GET_REG8(CapSense_sUDBSpeed_CAPTURE_LSB_PTR) );
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadCapture
********************************************************************************
* Summary:
*  This function returns the last value captured.
*
* Parameters:  
*  void 
*
* Return: 
*  Present Capture value.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadCapture( void )
{
   return ( CY_GET_REG8(CapSense_sUDBSpeed_CAPTURE_LSB_PTR) );  
}


#if (CapSense_sUDBSpeed_UseStatus)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ClearFIFO
********************************************************************************
* Summary:
*  This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_ClearFIFO(void)
{
    while(CapSense_sUDBSpeed_ReadStatusRegister() & CapSense_sUDBSpeed_STATUS_FIFONEMPTY)
        CapSense_sUDBSpeed_ReadCapture();
}
#endif /* CapSense_sUDBSpeed_UseStatus */
#endif /* !CapSense_sUDBSpeed_UsingFixedFunction */


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WritePeriod
********************************************************************************
* Summary:
*  This function is used to change the period of the counter.  The new period 
*  will be loaded the next time terminal count is detected.
*
* Parameters:  
*  void  
*
* Return: 
*  Period value. May be between 1 and (2^Resolution)-1.  A value of 0 will result in
*  the counter remaining at zero.
*
*******************************************************************************/
void CapSense_sUDBSpeed_WritePeriod(uint8 period)
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        uint16 period_temp = (uint16)period;
        CY_SET_REG16(CapSense_sUDBSpeed_PERIOD_LSB_PTR, period_temp);
    #else
        CY_SET_REG8(CapSense_sUDBSpeed_PERIOD_LSB_PTR, period);
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadPeriod
********************************************************************************
* Summary:
*  This function reads the period without affecting pwm operation.
*
* Parameters:  
*  uint8:  Current Period Value
*
* Return: 
*  (void)
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadPeriod( void )
{
   return ( CY_GET_REG8(CapSense_sUDBSpeed_PERIOD_LSB_PTR) );
}


#if CapSense_sUDBSpeed_UseOneCompareMode
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteCompare
********************************************************************************
* Summary:
*  This funtion is used to change the compare1 value when the PWM is in Dither
*  mode.  The compare output will 
*  reflect the new value on the next UDB clock.  The compare output will be 
*  driven high when the present counter value is compared to the compare value
*  based on the compare mode defined in Dither Mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteCompare(uint8 compare)
{
   CY_SET_REG8(CapSense_sUDBSpeed_COMPARE1_LSB_PTR, compare);
   #if (CapSense_sUDBSpeed_PWMMode == CapSense_sUDBSpeed__B_PWM__DITHER)
        CY_SET_REG8(CapSense_sUDBSpeed_COMPARE2_LSB_PTR, compare+1);
   #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadCompare
********************************************************************************
* Summary:
*  This function returns the compare value.
*
* Parameters:  
*  void  
*
* Return: 
*  Current compare value.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadCompare( void )
{
  return ( CY_GET_REG8(CapSense_sUDBSpeed_COMPARE1_LSB_PTR) );
}


#else


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteCompare1
********************************************************************************
* Summary:
*  This funtion is used to change the compare1 value.  The compare output will 
*  reflect the new value on the next UDB clock.  The compare output will be 
*  driven high when the present counter value is less than or less than or 
*  equal to the compare register, depending on the mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteCompare1(uint8 compare)
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
        uint16 compare_temp = (uint16)compare;
        CY_SET_REG16(CapSense_sUDBSpeed_COMPARE1_LSB_PTR, compare_temp);
    #else
        CY_SET_REG8(CapSense_sUDBSpeed_COMPARE1_LSB_PTR, compare);
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadCompare1
********************************************************************************
* Summary:
*  This function returns the compare1 value.
*
* Parameters:  
*  void  
*
* Return: 
*  Current compare value.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadCompare1( void )
{
  return ( CY_GET_REG8(CapSense_sUDBSpeed_COMPARE1_LSB_PTR) );
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteCompare2
********************************************************************************
* Summary:
*  This funtion is used to change the compare value, for compare1 output.  
*  The compare output will reflect the new value on the next UDB clock.  
*  The compare output will be driven high when the present counter value is 
*  less than or less than or equal to the compare register, depending on the 
*  mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteCompare2(uint8 compare)
{
    #if(CapSense_sUDBSpeed_UsingFixedFunction)
       //TODO: This should generate an error because the fixed function block doesn't have a compare 2 register
       uint16 compare_temp = (uint16)compare;
       CY_SET_REG16(CapSense_sUDBSpeed_COMPARE2_LSB_PTR, compare_temp);
    #else
        CY_SET_REG8(CapSense_sUDBSpeed_COMPARE2_LSB_PTR, compare);
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadCompare2
********************************************************************************
* Summary:
*  This function returns the compare value, for the second compare output.
*
* Parameters:  
*  void
*
* Return: 
*  Present compare2 value.
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadCompare2( void )
{
    return ( CY_GET_REG8(CapSense_sUDBSpeed_COMPARE2_LSB_PTR) );
}
#endif /* UseOneCompareMode */


#if (CapSense_sUDBSpeed_DeadBandUsed)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteDeadTime
********************************************************************************
* Summary:
*  This function writes the dead-band counts to the corresponding register
*
* Parameters:  
*  deadtime:  Number of counts for dead time 
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteDeadTime( uint8 deadtime )
{
    /* If using the Dead Band 1-255 mode then just write the register */
    #if(!CapSense_sUDBSpeed_DeadBand2_4)
        CY_SET_REG8(CapSense_sUDBSpeed_DEADBAND_COUNT_PTR, deadtime);
    #else
        /* Otherwise the data has to be masked and offset */
        uint8 deadtimemasked = (deadtime << CapSense_sUDBSpeed_DEADBAND_COUNT_SHIFT) & CapSense_sUDBSpeed_DEADBAND_COUNT_MASK;
        CapSense_sUDBSpeed_DEADBAND_COUNT &= ~CapSense_sUDBSpeed_DEADBAND_COUNT_MASK; /* Clear existing data */
        CapSense_sUDBSpeed_DEADBAND_COUNT |= deadtimemasked; /* Set new dead time */
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadDeadTime
********************************************************************************
* Summary:
*  This function reads the dead-band counts from the corresponding register
*
* Parameters:  
*  void
*
* Return: 
*  Dead Band Counts
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadDeadTime(void)
{
    /* If using the Dead Band 1-255 mode then just read the register */
    #if(!CapSense_sUDBSpeed_DeadBand2_4)
        return ( CY_GET_REG8(CapSense_sUDBSpeed_DEADBAND_COUNT_PTR) );
    #else
        /* Otherwise the data has to be masked and offset */
        return ((CapSense_sUDBSpeed_DEADBAND_COUNT & CapSense_sUDBSpeed_DEADBAND_COUNT_MASK) >> CapSense_sUDBSpeed_DEADBAND_COUNT_SHIFT);
    #endif
}
#endif /* DeadBandUsed */


#if ( CapSense_sUDBSpeed_KillModeMinTime)
/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_WriteKillTime
********************************************************************************
* Summary:
*  This function writes the kill-time counts to the corresponding register
*
* Parameters:
*  killtime:  Number of counts for killtime 
*
* Return: 
*  void
*
*******************************************************************************/
void CapSense_sUDBSpeed_WriteKillTime( uint8 killtime )
{
    /* Not available in Fixed Function mode.  This is taken care of by the 
     * customizer to not allow the user to set Fixed Function and set 
     * the Kill Mode*/
    CY_SET_REG8(CapSense_sUDBSpeed_KILLMODEMINTIME_PTR, killtime);
}


/*******************************************************************************
* Function Name: CapSense_sUDBSpeed_ReadKillTime
********************************************************************************
* Summary:
*  This function reads the Kill-time counts from the corresponding register
*
* Parameters:  
*  void
*
* Return: 
*  Kill Time Counts
*
*******************************************************************************/
uint8 CapSense_sUDBSpeed_ReadKillTime(void)
{
    return ( CY_GET_REG8(CapSense_sUDBSpeed_KILLMODEMINTIME_PTR) );
}
#endif /* KillModeMinTime */


/* [] END OF FILE */
