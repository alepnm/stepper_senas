/*******************************************************************************
* File Name: CapSense_sbCSD_cComp.h  
* Version 1.10
*
*  Description:
*    This file contains the function prototypes and constants used in
*    the Analog Comparitor User Module.
*
*   Note:
*     
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "cyfitter.h"

#if !defined(CY_COMP_CapSense_sbCSD_cComp_H) 
#define CY_COMP_CapSense_sbCSD_cComp_H 

#define CapSense_sbCSD_cComp_RECALMODE 0

/**************************************
*        Function Prototypes 
**************************************/

void    CapSense_sbCSD_cComp_Start(void);
void    CapSense_sbCSD_cComp_Stop(void);
void    CapSense_sbCSD_cComp_SetSpeed(uint8 speed);
uint8   CapSense_sbCSD_cComp_GetCompare(void);
uint8   CapSense_sbCSD_cComp_ZeroCal(void);
void    CapSense_sbCSD_cComp_LoadTrim(uint8 trimVal); 


/**************************************
*           API Constants        
**************************************/
/* Power constants for SetSpeed() function */
#define CapSense_sbCSD_cComp_SLOWSPEED   0x00u
#define CapSense_sbCSD_cComp_HIGHSPEED   0x01u
#define CapSense_sbCSD_cComp_LOWPOWER    0x02u


/**************************************
*           Parameter Defaults        
**************************************/

#define CapSense_sbCSD_cComp_DEFAULT_SPEED       0 
#define CapSense_sbCSD_cComp_DEFAULT_HYSTERESIS  0 
#define CapSense_sbCSD_cComp_DEFAULT_POLARITY    0 
#define CapSense_sbCSD_cComp_DEFAULT_BYPASS_SYNC 1 

/**************************************
*             Registers        
**************************************/

#define CapSense_sbCSD_cComp_CR     (* (reg8 *) CapSense_sbCSD_cComp_ctComp__CR )   /* Config register   */
#define CapSense_sbCSD_cComp_CLK    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__CLK )  /* Comp clock comtrol register */
#define CapSense_sbCSD_cComp_SW0    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__SW0 )  /* Routing registers */
#define CapSense_sbCSD_cComp_SW2    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__SW2 )
#define CapSense_sbCSD_cComp_SW3    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__SW3 )
#define CapSense_sbCSD_cComp_SW4    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__SW4 )
#define CapSense_sbCSD_cComp_SW6    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__SW6 )
#define CapSense_sbCSD_cComp_TR     (* (reg8 *) CapSense_sbCSD_cComp_ctComp__TR )   /* Trim registers */
#define CapSense_sbCSD_cComp_WRK    (* (reg8 *) CapSense_sbCSD_cComp_ctComp__WRK )  /* Working register - output */
#define CapSense_sbCSD_cComp_PWRMGR (* (reg8 *) CapSense_sbCSD_cComp_ctComp__PM_ACT_CFG )  /* Power manager */


/**************************************
*       Register Constants        
**************************************/

/* CR (Comp Control Register)             */
#define CapSense_sbCSD_cComp_CFG_MODE_MASK  0x78u
#define CapSense_sbCSD_cComp_FILTER_ON      0x40u
#define CapSense_sbCSD_cComp_HYST_OFF       0x20u
#define CapSense_sbCSD_cComp_CAL_ON         0x10u
#define CapSense_sbCSD_cComp_MX_AO          0x08u
#define CapSense_sbCSD_cComp_PWRDWN_OVRD    0x04u

#define CapSense_sbCSD_cComp_PWR_MODE_SHIFT 0x00u
#define CapSense_sbCSD_cComp_PWR_MODE_MASK  (0x03u << CapSense_sbCSD_cComp_PWR_MODE_SHIFT)
#define CapSense_sbCSD_cComp_PWR_MODE_SLOW  (0x00u << CapSense_sbCSD_cComp_PWR_MODE_SHIFT)
#define CapSense_sbCSD_cComp_PWR_MODE_FAST  (0x01u << CapSense_sbCSD_cComp_PWR_MODE_SHIFT)
#define CapSense_sbCSD_cComp_PWR_MODE_ULOW  (0x02u << CapSense_sbCSD_cComp_PWR_MODE_SHIFT)

/* CLK (Comp Clock Control Register)      */
#define CapSense_sbCSD_cComp_BYPASS_SYNC    0x10u
#define CapSense_sbCSD_cComp_SYNC_CLK_EN    0x08u
#define CapSense_sbCSD_cComp_SYNCCLK_MASK   (CapSense_sbCSD_cComp_BYPASS_SYNC | CapSense_sbCSD_cComp_SYNC_CLK_EN)

/* SW3Routing Register definitions */
#define CapSense_sbCSD_cComp_CMP_SW3_INPCTL_MASK    0x09u   /* SW3 bits for inP routing control */

/* TR (Comp Trim Register)     */
#define CapSense_sbCSD_cComp_CMP_TRIM1_DIR  0x08u   /* Trim direction for N-type load for offset calibration */
#define CapSense_sbCSD_cComp_CMP_TRIM1_MASK 0x07u   /* Trim for N-type load for offset calibration */
#define CapSense_sbCSD_cComp_CMP_TRIM2_DIR  0x80u   /* Trim direction for P-type load for offset calibration */
#define CapSense_sbCSD_cComp_CMP_TRIM2_MASK 0x70u   /* Trim for P-type load for offset calibration */

/* WRK (Comp output working register)     */ 
#define CapSense_sbCSD_cComp_CMP_OUT_MASK   CapSense_sbCSD_cComp_ctComp__WRK_MASK /* Specific comparator out mask */

/* PM_ACT_CFG (Active Power Mode CFG Register)     */ 
#define CapSense_sbCSD_cComp_ACT_PWR_EN     CapSense_sbCSD_cComp_ctComp__PM_ACT_MSK /* Power enable mask */

#endif /* CY_COMP_CapSense_sbCSD_cComp_H */
/* [] END OF FILE  */
