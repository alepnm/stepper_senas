/*******************************************************************************
* File Name: CapSense_sbCSD_cRAW.c  
* Version 1.20
*
*  Description:
*     The Counter User Module consists of a 8, 16, 24 or 32-bit counter with
*     a selectable period between 2 and 2^Width - 1.  
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/


#include "cytypes.h"
#include "CapSense_sbCSD_cRAW.h"

uint8 CapSense_sbCSD_cRAW_initvar = 0;

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_Start
********************************************************************************
* Summary:
*  Enables the counter for operation 
*
* Parameters:  
*  void:  
*
* Return: 
*  (void)
*
* Theory: 
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_Start(void) 
{
    if(CapSense_sbCSD_cRAW_initvar == 0)
    {
        #if (!CapSense_sbCSD_cRAW_UsingFixedFunction && !CapSense_sbCSD_cRAW_ControlRegRemoved)
            uint8 ctrl;
        #endif
        
        CapSense_sbCSD_cRAW_initvar = 1; /* Clear this bit for Initialization */
        
        #if (CapSense_sbCSD_cRAW_UsingFixedFunction)
            /* Clear all bits but the enable bit (if it's already set for Timer operation */
            CapSense_sbCSD_cRAW_CONTROL &= CapSense_sbCSD_cRAW_CTRL_ENABLE;
            
            /* Clear the mode bits to be 000 for continuous mode */
            CapSense_sbCSD_cRAW_CONTROL2 &= ~CapSense_sbCSD_cRAW_CTRL_CMPMODE_MASK; 
            /* Compare Mode is not available with Fixed Function block so don't set the compare mode */
            
            /* Set the IRQ to use the status register interrupts */
            CapSense_sbCSD_cRAW_CONTROL2 |= CapSense_sbCSD_cRAW_CTRL2_IRQ_SEL;
        #else
            #if(!CapSense_sbCSD_cRAW_ControlRegRemoved)
            /* Set the default compare mode defined in the parameter */
            ctrl = CapSense_sbCSD_cRAW_CONTROL & ~CapSense_sbCSD_cRAW_CTRL_CMPMODE_MASK;
            CapSense_sbCSD_cRAW_CONTROL = ctrl | CapSense_sbCSD_cRAW_DEFAULT_COMPARE_MODE;
            
            /* Set the default capture mode defined in the parameter */
            ctrl = CapSense_sbCSD_cRAW_CONTROL & ~CapSense_sbCSD_cRAW_CTRL_CAPMODE_MASK;
            CapSense_sbCSD_cRAW_CONTROL = ctrl | CapSense_sbCSD_cRAW_DEFAULT_CAPTURE_MODE;
            #endif
        #endif 
        
        /* Clear all data in the FIFO's */
        #if (!CapSense_sbCSD_cRAW_UsingFixedFunction)
            CapSense_sbCSD_cRAW_ClearFIFO();
        #endif
        
         /* Set Initial values from Configuration */
        CapSense_sbCSD_cRAW_WritePeriod(CapSense_sbCSD_cRAW_INIT_PERIOD_VALUE);
        CapSense_sbCSD_cRAW_WriteCounter(CapSense_sbCSD_cRAW_INIT_COUNTER_VALUE);
        CapSense_sbCSD_cRAW_SetInterruptMode(CapSense_sbCSD_cRAW_INIT_INTERRUPTS_MASK);
        
        #if (CapSense_sbCSD_cRAW_UsingFixedFunction)
            /* Globally Enable the Fixed Function Block chosen */
            CapSense_sbCSD_cRAW_GLOBAL_ENABLE |= CapSense_sbCSD_cRAW_BLOCK_EN_MASK;
            /* Set the Interrupt source to come from the status register */
            CapSense_sbCSD_cRAW_CONTROL2 |= CapSense_sbCSD_cRAW_CTRL2_IRQ_SEL;
        #else
            /* Set the compare value (only available to non-fixed function implementation */
            CapSense_sbCSD_cRAW_WriteCompare(CapSense_sbCSD_cRAW_INIT_COMPARE_VALUE);
            /* Use the interrupt output of the status register for IRQ output */
            CapSense_sbCSD_cRAW_STATUS_AUX_CTRL |= CapSense_sbCSD_cRAW_STATUS_ACTL_INT_EN_MASK;
        #endif

    }
    
    /* Enable the counter from the control register  */
    /* If Fixed Function then make sure Mode is set correctly */
    /* else make sure reset is clear */
    #if(!CapSense_sbCSD_cRAW_ControlRegRemoved || CapSense_sbCSD_cRAW_UsingFixedFunction)
   CapSense_sbCSD_cRAW_CONTROL |= CapSense_sbCSD_cRAW_CTRL_ENABLE;
   #endif
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_Stop
********************************************************************************
* Summary:
* Halts the counter, but does not change any modes or disable
* interrupts.
*
* Parameters:  
*  void:  
*
* Return: 
*  (void)
*
* Theory: 
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_Stop(void)
{
    #if(!CapSense_sbCSD_cRAW_ControlRegRemoved || CapSense_sbCSD_cRAW_UsingFixedFunction)
        CapSense_sbCSD_cRAW_CONTROL &= ~CapSense_sbCSD_cRAW_CTRL_ENABLE;
    #endif
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_SetInterruptMode
********************************************************************************
* Summary:
* Configures which interrupt sources are enabled to generate the final interrupt
*
* Parameters:  
*  InterruptsMask: This parameter is an or'd collection of the status bits
*                   which will be allowed to generate the counters interrupt.   
*
* Return: 
*  (void)
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_SetInterruptMode(uint8 interruptsMask)
{
    CapSense_sbCSD_cRAW_STATUS_MASK = interruptsMask;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_GetInterruptSource
********************************************************************************
* Summary:
* Returns the status register with data about the interrupt source.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint8): Status Register Bit-Field of interrupt source(s)
*
* Theory: 
*
* Side Effects:  The Status register may be clear on read and all interrupt sources
*                    must be handled.
*
*******************************************************************************/
uint8 CapSense_sbCSD_cRAW_GetInterruptSource(void)
{
    return CapSense_sbCSD_cRAW_STATUS;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadStatusRegister
********************************************************************************
* Summary:
*   Reads the status register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the status register
*
* Theory: 
*
* Side Effects:
*   Status register bits may be clear on read. 
*******************************************************************************/
uint8   CapSense_sbCSD_cRAW_ReadStatusRegister(void)
{
    return CapSense_sbCSD_cRAW_STATUS;
}

#if(!CapSense_sbCSD_cRAW_ControlRegRemoved)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadControlRegister
********************************************************************************
* Summary:
*   Reads the control register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
* Theory: 
*
* Side Effects:
*   
*******************************************************************************/
uint8   CapSense_sbCSD_cRAW_ReadControlRegister(void)
{
    return CapSense_sbCSD_cRAW_CONTROL;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_WriteControlRegister
********************************************************************************
* Summary:
*   Sets the bit-field of the control register.  This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
* Theory: 
*
* Side Effects:
*   
*******************************************************************************/
void    CapSense_sbCSD_cRAW_WriteControlRegister(uint8 control)
{
    CapSense_sbCSD_cRAW_CONTROL = control;
}
#endif

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_WriteCounter
********************************************************************************
* Summary:
*   This funtion is used to set the counter to a specific value
*
* Parameters:  
*  counter:  New counter value. 
*
* Return: 
*  (void) 
*
* Theory: 
*
* Side Effects:
*   
*******************************************************************************/
void CapSense_sbCSD_cRAW_WriteCounter(uint16 counter )
{
    #if(CapSense_sbCSD_cRAW_UsingFixedFunction)
        uint16 counter_temp = (uint16)counter;
        CY_SET_REG16(CapSense_sbCSD_cRAW_COUNTER_LSB_PTR, counter_temp);
    #else
        CY_SET_REG16(CapSense_sbCSD_cRAW_COUNTER_LSB_PTR, counter);
    #endif
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadCounter
********************************************************************************
* Summary:
* Returns the current value of the counter.  It doesn't matter
* if the counter is enabled or running.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint16) The present value of the counter.
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
uint16 CapSense_sbCSD_cRAW_ReadCounter(void)
{
    
    CY_GET_REG8(CapSense_sbCSD_cRAW_COUNTER_LSB_PTR);
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    return (CY_GET_REG16(CapSense_sbCSD_cRAW_STATICCOUNT_LSB_PTR));
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadCapture
********************************************************************************
* Summary:
*   This function returns the last value captured.
*
* Parameters:  
*  void: 
*
* Return: 
*  (uint16) Present Capture value.
*
* Theory: 
*
* Side Effects:
*  
*******************************************************************************/
uint16 CapSense_sbCSD_cRAW_ReadCapture( void )
{
   return ( CY_GET_REG16(CapSense_sbCSD_cRAW_STATICCOUNT_LSB_PTR) );  
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_WritePeriod
********************************************************************************
* Summary:
* Changes the period of the counter.  The new period 
* will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period: (uint16) A value of 0 will result in
*         the counter remaining at zero.  
*
* Return: 
*  (void)
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_WritePeriod(uint16 period)
{
    #if(CapSense_sbCSD_cRAW_UsingFixedFunction)
        uint16 period_temp = (uint16)period;
        CY_SET_REG16(CapSense_sbCSD_cRAW_PERIOD_LSB_PTR,period_temp);
    #else
        CY_SET_REG16(CapSense_sbCSD_cRAW_PERIOD_LSB_PTR,period);
    #endif
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadPeriod
********************************************************************************
* Summary:
* Reads the current period value without affecting counter operation.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint16) Present period value.
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
uint16 CapSense_sbCSD_cRAW_ReadPeriod(void)
{
   return ( CY_GET_REG16(CapSense_sbCSD_cRAW_PERIOD_LSB_PTR));
}

#if (!CapSense_sbCSD_cRAW_UsingFixedFunction)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_WriteCompare
********************************************************************************
* Summary:
* Changes the compare value.  The compare output will 
* reflect the new value on the next UDB clock.  The compare output will be 
* driven high when the present counter value compares true based on the 
* configured compare mode setting. 
*
* Parameters:  
*  Compare:  New compare value. 
*
* Return: 
*  void
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_WriteCompare(uint16 compare)
{
    #if(CapSense_sbCSD_cRAW_UsingFixedFunction)
        uint16 compare_temp = (uint16)compare;
        CY_SET_REG16(CapSense_sbCSD_cRAW_COMPARE_LSB_PTR,compare_temp);
    #else
        CY_SET_REG16(CapSense_sbCSD_cRAW_COMPARE_LSB_PTR,compare);
    #endif
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ReadCompare
********************************************************************************
* Summary:
* Returns the compare value.
*
* Parameters:  
*  void:
*
* Return: 
*  (uint16) Present compare value.
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
uint16 CapSense_sbCSD_cRAW_ReadCompare(void)
{
   return ( CY_GET_REG16(CapSense_sbCSD_cRAW_COMPARE_LSB_PTR));
}


#if (CapSense_sbCSD_cRAW_COMPARE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_SetCompareMode
********************************************************************************
*
* Summary:
*  Sets the software controlled Compare Mode.
*
* Parameters:
*  compareMode:  Compare Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_SetCompareMode(uint8 compareMode)
{
    /* Clear the compare mode bits in the control register */
    CapSense_sbCSD_cRAW_CONTROL &= ~CapSense_sbCSD_cRAW_CTRL_CMPMODE_MASK;
    
    /* Write the new setting */
    CapSense_sbCSD_cRAW_CONTROL |= (compareMode << CapSense_sbCSD_cRAW_CTRL_CMPMODE0_SHIFT);
}
#endif


#if (CapSense_sbCSD_cRAW_CAPTURE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_SetCaptureMode
********************************************************************************
*
* Summary:
*  Sets the software controlled Capture Mode.
*
* Parameters:
*  captureMode:  Capture Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cRAW_SetCaptureMode(uint8 captureMode)
{
    /* Clear the capture mode bits in the control register */
    CapSense_sbCSD_cRAW_CONTROL &= ~CapSense_sbCSD_cRAW_CTRL_CAPMODE_MASK;
    
    /* Write the new setting */
    CapSense_sbCSD_cRAW_CONTROL |= (captureMode << CapSense_sbCSD_cRAW_CTRL_CAPMODE0_SHIFT);
}
#endif


/*******************************************************************************
* Function Name: CapSense_sbCSD_cRAW_ClearFIFO
********************************************************************************
* Summary:
*   This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void:
*
* Return: 
*  None
*
* Theory: 
*
* Side Effects:
*   
*******************************************************************************/
void CapSense_sbCSD_cRAW_ClearFIFO(void)
{

   /* It will be easier to cler FIFO in using auxilary control register */
      CapSense_sbCSD_cRAW_AUX_CONTROLDP0 |=  CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
      CapSense_sbCSD_cRAW_AUX_CONTROLDP0 &= ~CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
     
#if (CapSense_sbCSD_cRAW_Resolution == 16 || CapSense_sbCSD_cRAW_Resolution == 24 || CapSense_sbCSD_cRAW_Resolution == 32)
      CapSense_sbCSD_cRAW_AUX_CONTROLDP1 |=  CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
      CapSense_sbCSD_cRAW_AUX_CONTROLDP1 &= ~CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
#endif

#if (CapSense_sbCSD_cRAW_Resolution == 24 || CapSense_sbCSD_cRAW_Resolution == 32)
      CapSense_sbCSD_cRAW_AUX_CONTROLDP2 |=  CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;   
      CapSense_sbCSD_cRAW_AUX_CONTROLDP2 &= ~CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
#endif

#if (CapSense_sbCSD_cRAW_Resolution == 32)
      CapSense_sbCSD_cRAW_AUX_CONTROLDP3 |=  CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;   
      CapSense_sbCSD_cRAW_AUX_CONTROLDP3 &= ~CapSense_sbCSD_cRAW_AUX_CTRL_FIFO0_CLR;
#endif
      
//    while(CapSense_sbCSD_cRAW_ReadStatusRegister() & CapSense_sbCSD_cRAW_STATUS_FIFONEMP)
//        CapSense_sbCSD_cRAW_ReadCapture();

}
#endif

/* [] END OF FILE */
