/*******************************************************************************
* File Name: CapSense_sbCSD_cISR_intc.h
* Version 1.0
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__CapSense_sbCSD_cISR_INTC_H__)
#define __CapSense_sbCSD_cISR_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>


/* Interrupt Controller API. */
void CapSense_sbCSD_cISR_Start(void);
void CapSense_sbCSD_cISR_Stop(void);

CY_ISR_PROTO(CapSense_sbCSD_cISR_Interrupt);

void CapSense_sbCSD_cISR_SetVector(cyisraddress address);
cyisraddress CapSense_sbCSD_cISR_GetVector(void);

void CapSense_sbCSD_cISR_SetPriority(uint8 priority);
uint8 CapSense_sbCSD_cISR_GetPriority(void);

void CapSense_sbCSD_cISR_Enable(void);
uint8 CapSense_sbCSD_cISR_GetState(void);
void CapSense_sbCSD_cISR_Disable(void);

void CapSense_sbCSD_cISR_SetPending(void);
void CapSense_sbCSD_cISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the CapSense_sbCSD_cISR ISR. */
#define CapSense_sbCSD_cISR_INTC_VECTOR            ((reg16 *) CapSense_sbCSD_cISR__INTC_VECT)

/* Address of the CapSense_sbCSD_cISR ISR priority. */
#define CapSense_sbCSD_cISR_INTC_PRIOR             ((reg8 *) CapSense_sbCSD_cISR__INTC_PRIOR_REG)

/* Priority of the CapSense_sbCSD_cISR interrupt. */
#define CapSense_sbCSD_cISR_INTC_PRIOR_NUMBER      CapSense_sbCSD_cISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable CapSense_sbCSD_cISR interrupt. */
#define CapSense_sbCSD_cISR_INTC_SET_EN            ((reg8 *) CapSense_sbCSD_cISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the CapSense_sbCSD_cISR interrupt. */
#define CapSense_sbCSD_cISR_INTC_CLR_EN            ((reg8 *) CapSense_sbCSD_cISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the CapSense_sbCSD_cISR interrupt state to pending. */
#define CapSense_sbCSD_cISR_INTC_SET_PD            ((reg8 *) CapSense_sbCSD_cISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the CapSense_sbCSD_cISR interrupt. */
#define CapSense_sbCSD_cISR_INTC_CLR_PD            ((reg8 *) CapSense_sbCSD_cISR__INTC_CLR_PD_REG)

/* __CapSense_sbCSD_cISR_INTC_H__ */
#endif

