/*******************************************************************************
* File Name: Control_Start_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Control_Start.h"

/* Check for removal by optimization */
#if !defined(Control_Start_Sync_ctrl_reg__REMOVED)

static Control_Start_BACKUP_STRUCT  Control_Start_backup = {0u};

    
/*******************************************************************************
* Function Name: Control_Start_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Control_Start_SaveConfig(void) 
{
    Control_Start_backup.controlState = Control_Start_Control;
}


/*******************************************************************************
* Function Name: Control_Start_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void Control_Start_RestoreConfig(void) 
{
     Control_Start_Control = Control_Start_backup.controlState;
}


/*******************************************************************************
* Function Name: Control_Start_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Control_Start_Sleep(void) 
{
    Control_Start_SaveConfig();
}


/*******************************************************************************
* Function Name: Control_Start_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Control_Start_Wakeup(void)  
{
    Control_Start_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
