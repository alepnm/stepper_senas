/*******************************************************************************
* File Name: CapSense.c
* Version 1.30
*
* Description:
*  This file provides the source code to the API for the CapSense Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSense.h"

CapSense_Slot CapSense_ScanSlotTable[] = 
{
    {0, 0, 1, 1, 0},
    {1, 1, 1, 2, 0},
    {2, 2, 1, 0, 0},
    {3, 3, 1, 0, 0}
};

const uint8 CapSense_IndexTable[] = { 0x00 };

CapSense_CSD_Settings CapSense_SettingsTable[] = 
{
    {CapSense_IDAC_RANGE_32uA, 20, CapSense_PWM_RESOLUTION_8_BITS, CapSense_SCAN_SPEED_ULTRA_FAST, CapSense_DISABLE_STATE_GND},
    {CapSense_IDAC_RANGE_32uA, 20, CapSense_PWM_RESOLUTION_8_BITS, CapSense_SCAN_SPEED_ULTRA_FAST, CapSense_DISABLE_STATE_GND},
    {CapSense_IDAC_RANGE_32uA, 20, CapSense_PWM_RESOLUTION_8_BITS, CapSense_SCAN_SPEED_ULTRA_FAST, CapSense_DISABLE_STATE_GND},
    {CapSense_IDAC_RANGE_32uA, 20, CapSense_PWM_RESOLUTION_8_BITS, CapSense_SCAN_SPEED_ULTRA_FAST, CapSense_DISABLE_STATE_GND}
};

const CapSense_PortShift CapSense_PortShiftTable[] = 
{
    {CapSense_sbCSD_cPort__BTN_B1__PORT, CapSense_sbCSD_cPort__BTN_B1__SHIFT},
    {CapSense_sbCSD_cPort__BTN_B2__PORT, CapSense_sbCSD_cPort__BTN_B2__SHIFT},
    {CapSense_sbCSD_cPort__LS_S1_e0__PORT, CapSense_sbCSD_cPort__LS_S1_e0__SHIFT},
    {CapSense_sbCSD_cPort__LS_S1_e1__PORT, CapSense_sbCSD_cPort__LS_S1_e1__SHIFT}
};

uint8 CapSense_status = 0;

uint8 CapSense_idacInitVar = 0;

uint16 CapSense_SlotResult[CapSense_TOTAL_SCANSLOT_COUNT] = {0};
uint16 *CapSense_SlotRaw = CapSense_SlotResult;


/*******************************************************************************
* Function Name: CapSense_Start
********************************************************************************
*
* Summary:
*  Initializes registers for each module and starts the component. This function
*  calls functions automatically depending on modules selected in the
*  customizer. This function should be called prior to calling any other
*  component functions.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_Start(void)
{
    CapSense_CSD_Start();
}


/*******************************************************************************
* Function Name: CapSense_Stop
********************************************************************************
*
* Summary:
*  Stops the slot scanner, disables interrupts, and resets all slots to an 
*  inactive state
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_Stop(void)
{
    CapSense_CSD_Stop();
}


/*******************************************************************************
* Function Name: CapSense_ScanSlot
********************************************************************************
*
* Summary:
*  Calls the function CapSense_CSD_ScanSlot and scans defined scan slot.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_ScanSlot(uint8 slot)
{
      CapSense_CSD_ScanSlot(slot);
}


/*******************************************************************************
* Function Name: CapSense_ScanAllSlots
********************************************************************************
*
* Summary:
*  Scans all slots by calling CapSense_CSD_ScanAllSlots function for method
*  selected in customizer.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_ScanAllSlots(void)
{
    CapSense_CSD_ScanAllSlots();
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cIDAC_SetValue
********************************************************************************
*
* Summary:
*  Sets DAC value
*
* Parameters:
*  value:  Sets DAC value between 0 and 255.
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cIDAC_SetValue(uint8 value)
{
    /*  Set Value  */
    CapSense_IDAC_DATA = value;
    
    #if defined(CapSense_IDAC_FIRST_SILICON)
        CapSense_IDAC_DATA = value;        /*  TODO: Need for first version of silicon */
    #endif
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cIDAC_DacTrim
********************************************************************************
*
* Summary:
*  Sets the trim value for the given range.
*
* Parameters:
*  value:  Sets DAC value between 0 and 255.
* 
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cIDAC_DacTrim(void)
{
    uint8 mode;
    
    mode = ((CapSense_IDAC_CR0 & CapSense_IDAC_RANGE_MASK) >> 1);
    if((CapSense_IDAC_IDIR_MASK & CapSense_IDAC_CR1) == CapSense_IDAC_IDIR_SINK)
    {
        mode++;
    }
    
    CapSense_IDAC_TR = CY_GET_XTND_REG8((uint8 *)(CapSense_DAC_TRIM_BASE + mode));
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cIDAC_Start
********************************************************************************
*
* Summary:
*  Sets power level then turn on IDAC8.
*
* Parameters:
*  power:  Sets power level between off (0) and (3) high power
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cIDAC_Start(void)
{
    /* Hardware initiazation only needs to occure the first time */
    if ( CapSense_idacInitVar == 0)
    {
        CapSense_idacInitVar = 1;
        
        CapSense_IDAC_CR0 = CapSense_IDAC_MODE_I;
        
        CapSense_IDAC_CR1 = CapSense_IDAC_IDIR_SRC | CapSense_IDAC_IDIR_CTL_UDB;
        
        CapSense_sbCSD_cIDAC_SetValue(CapSense_TURN_OFF_IDAC);
        
        CapSense_sbCSD_cIDAC_DacTrim();
    }
    
    /* Enable power to DAC */
    CapSense_IDAC_PWRMGR |= CapSense_IDAC_ACT_PWR_EN;
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cIDAC_Stop
********************************************************************************
*
* Summary:
*  Powers down IDAC8 to lowest power state.
*
* Parameters:
*   void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cIDAC_Stop(void)
{
    #if defined(CapSense_IDAC_FIRST_SILICON)
        /* TODO: Work around for IDAC */
        /* De-initiaize the IDAC */
        CapSense_idacInitVar = 0;
        
        /* Change IDAC to VDAC mode */
        CapSense_IDAC_CR0 &= ~CapSense_IDAC_MODE_I;
    #endif
    
    /* Disble power to DAC */
    CapSense_IDAC_PWRMGR &= ~CapSense_IDAC_ACT_PWR_EN;
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cIDAC_SetRange
********************************************************************************
*
* Summary:
*  Sets current range
*
* Parameters:
*  Range:  Sets on of four valid ranges.
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_sbCSD_cIDAC_SetRange(uint8 range)
{
    /* Clear existing mode */
    CapSense_IDAC_CR0 &= ~CapSense_IDAC_RANGE_MASK; 
    
    /*  Set Range  */
    CapSense_IDAC_CR0 |= ( range & CapSense_IDAC_RANGE_MASK );
    CapSense_sbCSD_cIDAC_DacTrim();
}


/*******************************************************************************
* Function Name: CapSense_CSD_Start
********************************************************************************
*
* Summary:
*  Initializes registers and starts the CapSense Component.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_Start(void)
{
    /* Setup DIG_CLK_DivSerial */
    CapSense_sUDBSpeed_Start();
    
    /* Setup sbCSD_csRawCnt */
    CapSense_sbCSD_cRAW_Start();
    
    /* Setup sbCSD_csPWM */
    CapSense_sbCSD_cPWM_Start();
    
    /* Enable Comparator */
    CapSense_sbCSD_cComp_Start();
    
    /* Initialize AMux */
    CapSense_sbCSD_cAMux_Start();
    
    /* Start Idac */
    CapSense_sbCSD_cIDAC_Start();
    
    /* Connect Cmod, Cmp, Idac */
    CapSense_sbCSD_cAMux_Connect(CapSense_CMOD_CHANNEL);
    CapSense_sbCSD_cAMux_Connect(CapSense_CMP_VP_CHANNEL);
    
    CapSense_sbCSD_cAMux_Connect(CapSense_IDAC_CHANNEL);
    
    /* Clear all Sensor */
    CapSense_CSD_ClearSlots();
    
    /* Setup ISR Component for CapSense */
    CyIntDisable(CapSense_ISR_NUMBER);
    CyIntSetVector(CapSense_ISR_NUMBER, CapSense_ISR);
    CyIntSetPriority(CapSense_ISR_NUMBER, CapSense_ISR_PRIORITY);
    CyIntEnable(CapSense_ISR_NUMBER);
    
    /* Enable csBuf */
    CapSense_CSBUF_PWRMGR |= CapSense_CSBUF_PWR_ENABLE;
    CapSense_CAPS_CFG0 |= CapSense_CSBUF_ENABLE;
}


/*******************************************************************************
* Function Name: CapSense_CSD_Stop
********************************************************************************
*
* Summary:
*  Stops the slot scanner, disables internal interrupts, and calls 
*  CSD_ClearSlots() to reset all slots to an inactive state.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_Stop(void)
{
    /* Stop Capsensing */
    CapSense_CONTROL &= ~CapSense_START_CAPSENSING;
    
    /* Disable the CapSense interrupt */
    CyIntEnable(CapSense_ISR_NUMBER);
    
    /* Clear all Sensor */
    CapSense_CSD_ClearSlots();
    
    /* Disable Comparator */
    CapSense_sbCSD_cComp_Stop();
    
    /* Disable power to IDAC */
    CapSense_sbCSD_cIDAC_Stop();
    
    /* Disable csBuf */
    CapSense_CAPS_CFG0 &= ~CapSense_CSBUF_ENABLE;
    CapSense_CSBUF_PWRMGR &= ~CapSense_CSBUF_PWR_ENABLE;
}


/*******************************************************************************
* Function Name: CapSense_CSD_ScanSlot
********************************************************************************
*
* Summary:
*  Sets scan settings and scans the selected scan slot. Each scan slot has
*  a unique number within the slot array. This number is assigned by the
*  CapSense customizer in sequence.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_ScanSlot(uint8 slot)
{
    uint8 i, s, state;
    uint8 maxSns = CapSense_ScanSlotTable[slot].SnsCnt;
    uint8 startIndex = CapSense_ScanSlotTable[slot].IndexOffset;
    uint8 rawIndex = CapSense_ScanSlotTable[slot].RawIndex; 
    
    /* Set Slot Settings */
    CapSense_CSD_SetSlotSettings(slot);
    
    /* Disable CapSense Buffer */
    CapSense_CAPS_CFG0 &= ~CapSense_CSBUF_ENABLE;    
    
    /* Enable Sensors */
    if (maxSns == CapSense_ALONE_SENSOR)
    {
        CapSense_CSD_EnableSensor(startIndex);
    }
    else
    {
        for(i=0; i < maxSns; i++)
        {
            s = CapSense_IndexTable[startIndex+i];
            CapSense_CSD_EnableSensor(s);
        }
    }
    
    /* Set Flag CapSensing in progres */
    CapSense_status |= CapSense_START_CAPSENSING;
    
    /* Start PWM One Shout and PRS at one time */
    CapSense_CONTROL |= CapSense_START_CAPSENSING;
    
    /* Wait for finish CapSensing */
    while (CapSense_status == CapSense_START_CAPSENSING)
    { ; }
    
    /* Stop Capsensing */
    CapSense_CONTROL &= ~CapSense_START_CAPSENSING;
    
    /* Read SlotResult from RawCnt */
    CapSense_SlotResult[rawIndex] = CapSense_sbCSD_cRAW_ReadCounter();
    
    /* Disable Sensors */
    state = CapSense_SettingsTable[slot].DisableState;
    if (maxSns == CapSense_ALONE_SENSOR)
    {
        CapSense_CSD_DisableSensor(startIndex, state);
    }
    else
    {
        for(i=0; i < maxSns; i++)
        {
            s = CapSense_IndexTable[startIndex+i];
            CapSense_CSD_DisableSensor(s, state);
        }
    }
    
    /* Turn off IDAC */
    CapSense_sbCSD_cIDAC_SetValue(CapSense_TURN_OFF_IDAC);
    
    /* Enable Vref on AMUX */
    CapSense_CAPS_CFG0 |= CapSense_CSBUF_ENABLE;
}


/*******************************************************************************
* Function Name: CapSense_CSD_ScanAllSlots
********************************************************************************
*
* Summary:
*  Scans all scan slots by callingCapSense_CSD_ScanSlot for each
*  slot index.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_ScanAllSlots(void)
{
    uint8 i;
    
    for(i=0; i < CapSense_TOTAL_SCANSLOT_COUNT;i++)
    {
         CapSense_CSD_ScanSlot(i);
    }
}


/*******************************************************************************
* Function Name: CapSense_CSD_SetSlotSettings
********************************************************************************
*
* Summary:
*  Sets the scan settings of selected scan slot. Each setting has a unique
*  number within the settings array and is connected to corresponding scan slot.
*  This number is assigned by the CapSense customizer in sequence.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_SetSlotSettings(uint8 slot)
{
    uint8 scanSpeed = CapSense_SettingsTable[slot].ScanSpeed;
    uint16 resolution = ((uint16) CapSense_SettingsTable[slot].Resolution << CapSense_PWM_WINDOW_SHIFT)\
                        | CapSense_PWM_RESOLUTION_16_BITS;
    uint8 idacRange = CapSense_SettingsTable[slot].IdacRange;
    uint8 idacSettings = CapSense_SettingsTable[slot].IdacSettings;
    
    /* PWM Resolution */
    CapSense_sbCSD_cPWM_WritePeriod(resolution);
    CapSense_sbCSD_cPWM_WriteCompare(resolution);
    
    /* Reset RawCnt and rearm PWM */
    CapSense_CONTROL |= CapSense_RESET_PWM_CNTR;
    
    /* Set ScanSpeed */
    CapSense_sUDBSpeed_Stop();
    CapSense_sUDBSpeed_WriteCounter(scanSpeed);
    CapSense_sUDBSpeed_WritePeriod(scanSpeed);
    CapSense_sUDBSpeed_Start();
    
    CapSense_CONTROL &= ~CapSense_RESET_PWM_CNTR;
    
    /* Set Idac */
    CapSense_sbCSD_cIDAC_SetRange(idacRange);
    CapSense_sbCSD_cIDAC_SetValue(idacSettings);
}


/*******************************************************************************
* Function Name: CapSense_CSD_ClearSlots
********************************************************************************
*
* Summary:
*  Clears all slots to the non-sampling state by sequentially disconnecting all
*  slots from Analog MUX Bus, disable pin global control and connecting them to
*  GND or Shield electrode.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_ClearSlots(void)
{
    uint8 i, s, j;
    uint8 startIndex, maxSns, state;
    
    for (i=0; i < CapSense_TOTAL_SCANSLOT_COUNT; i++)
    {
        startIndex = CapSense_ScanSlotTable[i].IndexOffset;
        maxSns = CapSense_ScanSlotTable[i].SnsCnt;
        state = CapSense_SettingsTable[i].DisableState;
        
        /* Disable Sensors */
        if (maxSns == CapSense_ALONE_SENSOR)
        {
            CapSense_CSD_DisableSensor(startIndex, state);
        }
        else
        {
            for(j=0; j < maxSns; j++)
            {
                s = CapSense_IndexTable[startIndex+j];
                CapSense_CSD_DisableSensor(s, state);
            }
        }
    }
}


/*******************************************************************************
* Function Name: CapSense_CSD_ReadSlot
********************************************************************************
*
* Summary:
*  Returns scan slot raw data from the SlotResult[] array. Each scan slot has a
*  unique number within the slot array. This number is assigned by the CapSense
*  customizer in sequence.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  Returns current raw data value for defined scan slot
*
*******************************************************************************/
uint16 CapSense_CSD_ReadSlot(uint8 slot)
{
    uint8 index = CapSense_ScanSlotTable[slot].RawIndex;
    
    return CapSense_SlotResult[index];
}


/*******************************************************************************
* Function Name: CapSense_CSD_EnableSensor
********************************************************************************
*
* Summary:
*  Configures the selected sensor to measure during the next measurement cycle.
*  The corresponding pins are set to Analog High-Z mode and connected to the
*  Analog Mux Bus. This also enables the comparator function.
*
* Parameters:
*  sensor:  Sensor number
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_EnableSensor(uint8 sensor)
{
    uint8 port = CapSense_PortShiftTable[sensor].port;
    uint8 shift = CapSense_PortShiftTable[sensor].shift;
    uint8 mask = 1;
    
    mask <<= shift;
    
    /* Make sensor High-Z */
    *(CapSense_BASE_PRT_PC + (CapSense_PRT_PC_OFFSET*port) + shift) = CapSense_PRT_PC_HIGHZ;
    
    /* Connect from DSI output */
    *(CapSense_BASE_PRTDSI_CAPS + (CapSense_PRTDSI_OFFSET*port)) |= mask;
    
    /* Connect to AMUX */
    CapSense_sbCSD_cAMux_Connect(sensor);    
}


/*******************************************************************************
* Function Name: CapSense_CSD_DisableSensor
********************************************************************************
*
* Summary:
*  Disables the selected sensor. The corresponding pin is disconnected from the
*  Analog Mux Bus and connected to GND, High_Z or Shield electrode.
*
* Parameters:
*  sensor:  Sensor number
*  state:  State of sensor when disabled
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSD_DisableSensor(uint8 sensor, uint8 state)
{
    uint8 port = CapSense_PortShiftTable[sensor].port;
    uint8 shift = CapSense_PortShiftTable[sensor].shift;
    uint8 mask = 1;
    
    mask <<= shift;
    
    /* Disconnect from AMUX */
    CapSense_sbCSD_cAMux_Disconnect(sensor);
    
    /* Connect from DSI output */
    *(CapSense_BASE_PRTDSI_CAPS + (CapSense_PRTDSI_OFFSET*port)) &= ~mask;
    
    switch(state)
    {
        case CapSense_DISABLE_STATE_GND:
            *(CapSense_BASE_PRT_PC + (CapSense_PRT_PC_OFFSET*port) + shift) = CapSense_PRT_PC_GND;
        break;
        
        case CapSense_DISABLE_STATE_HIGHZ:
            *(CapSense_BASE_PRT_PC + (CapSense_PRT_PC_OFFSET*port) + shift) = CapSense_PRT_PC_HIGHZ;
        break;
        
        case CapSense_DISABLE_STATE_SHIELD:
            *(CapSense_BASE_PRT_PC + (CapSense_PRT_PC_OFFSET*port) + shift) = CapSense_PRT_PC_SHIELD;
        break;
        
        default:
            *(CapSense_BASE_PRT_PC + (CapSense_PRT_PC_OFFSET*port) + shift) = CapSense_PRT_PC_GND;
        break;
    }
}


/* [] END OF FILE */
