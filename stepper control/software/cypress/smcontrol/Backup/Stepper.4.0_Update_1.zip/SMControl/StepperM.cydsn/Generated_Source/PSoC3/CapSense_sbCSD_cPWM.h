/*******************************************************************************
* File Name: CapSense_sbCSD_cPWM.h  
* Version 1.10
*
* Description:
*  Contains the prototypes and constants for the functions available to the 
*  PWM user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "cyfitter.h"

#if !defined(CY_PWM_CapSense_sbCSD_cPWM_H)
#define CY_PWM_CapSense_sbCSD_cPWM_H

#define CapSense_sbCSD_cPWM_Resolution 16
#define CapSense_sbCSD_cPWM_UsingFixedFunction 0
#define CapSense_sbCSD_cPWM_DeadBandMode 0
#define CapSense_sbCSD_cPWM_KillModeMinTime 0
#define CapSense_sbCSD_cPWM_KillMode 0
#define CapSense_sbCSD_cPWM_PWMMode 0
#define CapSense_sbCSD_cPWM_PWMModeIsCenterAligned 0
#define CapSense_sbCSD_cPWM_DeadBandUsed 0
#define CapSense_sbCSD_cPWM_DeadBand2_4 0
#if !defined(CapSense_sbCSD_cPWM_PWMUDB_sSTSReg_stsreg__REMOVED)
    #define CapSense_sbCSD_cPWM_UseStatus 1
#else
    #define CapSense_sbCSD_cPWM_UseStatus 0
#endif
#if !defined(CapSense_sbCSD_cPWM_PWMUDB_sCTRLReg_ctrlreg__REMOVED)
    #define CapSense_sbCSD_cPWM_UseControl 0
#else
    #define CapSense_sbCSD_cPWM_UseControl 0
#endif
#define CapSense_sbCSD_cPWM_UseOneCompareMode 1
#define CapSense_sbCSD_cPWM_MinimumKillTime 1
#define CapSense_sbCSD_cPWM_EnableMode 1

#define CapSense_sbCSD_cPWM_CompareMode1SW 0
#define CapSense_sbCSD_cPWM_CompareMode2SW 0

/* Use Kill Mode Enumerated Types */
#define CapSense_sbCSD_cPWM__B_PWM__DISABLED 0
#define CapSense_sbCSD_cPWM__B_PWM__ASYNCHRONOUS 1
#define CapSense_sbCSD_cPWM__B_PWM__SINGLECYCLE 2
#define CapSense_sbCSD_cPWM__B_PWM__LATCHED 3
#define CapSense_sbCSD_cPWM__B_PWM__MINTIME 4


/* Use Dead Band Mode Enumerated Types */
#define CapSense_sbCSD_cPWM__B_PWM__DBMDISABLED 0
#define CapSense_sbCSD_cPWM__B_PWM__DBM_2_4_CLOCKS 1
#define CapSense_sbCSD_cPWM__B_PWM__DBM_256_CLOCKS 2


/* Used PWM Mode Enumerated Types */
#define CapSense_sbCSD_cPWM__B_PWM__ONE_OUTPUT 0
#define CapSense_sbCSD_cPWM__B_PWM__TWO_OUTPUTS 1
#define CapSense_sbCSD_cPWM__B_PWM__DUAL_EDGE 2
#define CapSense_sbCSD_cPWM__B_PWM__CENTER_ALIGN 3
#define CapSense_sbCSD_cPWM__B_PWM__DITHER 5
#define CapSense_sbCSD_cPWM__B_PWM__HARDWARESELECT 4


/* Used PWM Compare Mode Enumerated Types */
#define CapSense_sbCSD_cPWM__B_PWM__LESS_THAN 1
#define CapSense_sbCSD_cPWM__B_PWM__LESS_THAN_OR_EQUAL 2
#define CapSense_sbCSD_cPWM__B_PWM__GREATER_THAN 3
#define CapSense_sbCSD_cPWM__B_PWM__GREATER_THAN_OR_EQUAL_TO 4
#define CapSense_sbCSD_cPWM__B_PWM__EQUAL 0
#define CapSense_sbCSD_cPWM__B_PWM__FIRMWARE 5


/***************************************
 *   Function Prototypes
 **************************************/
void    CapSense_sbCSD_cPWM_Start(void);
void    CapSense_sbCSD_cPWM_Stop(void);
void    CapSense_sbCSD_cPWM_SetInterruptMode(uint8 interruptMode);
uint8   CapSense_sbCSD_cPWM_GetInterruptSource(void);
#if (CapSense_sbCSD_cPWM_UseStatus || CapSense_sbCSD_cPWM_UsingFixedFunction)
	uint8   CapSense_sbCSD_cPWM_ReadStatusRegister(void);
#endif
#if (CapSense_sbCSD_cPWM_UseControl)
	uint8   CapSense_sbCSD_cPWM_ReadControlRegister(void);
	void    CapSense_sbCSD_cPWM_WriteControlRegister(uint8 control);
#endif
#if CapSense_sbCSD_cPWM_UseOneCompareMode
	#if CapSense_sbCSD_cPWM_CompareMode1SW
	void    CapSense_sbCSD_cPWM_SetCompareMode(uint8 comparemode);
	#endif
#else
	#if CapSense_sbCSD_cPWM_CompareMode1SW
	void    CapSense_sbCSD_cPWM_SetCompareMode1(uint8 comparemode);
	#endif
	#if CapSense_sbCSD_cPWM_CompareMode2SW
	void    CapSense_sbCSD_cPWM_SetCompareMode2(uint8 comparemode);
	#endif
#endif

#if (!CapSense_sbCSD_cPWM_UsingFixedFunction)
uint16   CapSense_sbCSD_cPWM_ReadCounter(void);
uint16  CapSense_sbCSD_cPWM_ReadCapture(void);
#if (CapSense_sbCSD_cPWM_UseStatus)
void CapSense_sbCSD_cPWM_ClearFIFO(void);
#endif
#endif

void    CapSense_sbCSD_cPWM_WriteCounter(uint16 counter);
void    CapSense_sbCSD_cPWM_WritePeriod(uint16 period);
uint16   CapSense_sbCSD_cPWM_ReadPeriod(void);
#if CapSense_sbCSD_cPWM_UseOneCompareMode
    void    CapSense_sbCSD_cPWM_WriteCompare(uint16 compare);
    uint16   CapSense_sbCSD_cPWM_ReadCompare(void);
#else
    void    CapSense_sbCSD_cPWM_WriteCompare1(uint16 compare);
    uint16   CapSense_sbCSD_cPWM_ReadCompare1(void);
    void    CapSense_sbCSD_cPWM_WriteCompare2(uint16 compare);
    uint16   CapSense_sbCSD_cPWM_ReadCompare2(void);
#endif


#if (CapSense_sbCSD_cPWM_DeadBandUsed)
	void    CapSense_sbCSD_cPWM_WriteDeadTime(uint8 deadtime);
	uint8   CapSense_sbCSD_cPWM_ReadDeadTime(void);
#endif

#if ( CapSense_sbCSD_cPWM_KillModeMinTime)
	void CapSense_sbCSD_cPWM_WriteKillTime(uint8 killtime);
	uint8 CapSense_sbCSD_cPWM_ReadKillTime(void);
#endif

/***************************************
 *    Initialization Values
 **************************************/
#define CapSense_sbCSD_cPWM_INIT_PERIOD_VALUE        255
#define CapSense_sbCSD_cPWM_INIT_COMPARE_VALUE1      255
#define CapSense_sbCSD_cPWM_INIT_COMPARE_VALUE2      63
#define CapSense_sbCSD_cPWM_INIT_INTERRUPTS_MODE     ((1 << CapSense_sbCSD_cPWM_STATUS_TC_INT_EN_MASK_SHIFT) | (0 << CapSense_sbCSD_cPWM_STATUS_CMP2_INT_EN_MASK_SHIFT) | (0 << CapSense_sbCSD_cPWM_STATUS_CMP1_INT_EN_MASK_SHIFT ) | (0 << CapSense_sbCSD_cPWM_STATUS_KILL_INT_EN_MASK_SHIFT ))
#define CapSense_sbCSD_cPWM_DEFAULT_COMPARE2_MODE    (2 << CapSense_sbCSD_cPWM_CTRL_CMPMODE2_SHIFT)
#define CapSense_sbCSD_cPWM_DEFAULT_COMPARE1_MODE    (1 << CapSense_sbCSD_cPWM_CTRL_CMPMODE1_SHIFT)
#define CapSense_sbCSD_cPWM_INIT_DEAD_TIME           1

/********************************
 ******     Registers       *****
 ******************************** */

#if (CapSense_sbCSD_cPWM_UsingFixedFunction)
   #define CapSense_sbCSD_cPWM_PERIOD_LSB      (*(reg16 *) CapSense_sbCSD_cPWM_PWMHW__PER0)
   #define CapSense_sbCSD_cPWM_PERIOD_LSB_PTR   ((reg16 *) CapSense_sbCSD_cPWM_PWMHW__PER0)
   #define CapSense_sbCSD_cPWM_COMPARE1_LSB    (*(reg16 *) CapSense_sbCSD_cPWM_PWMHW__CNT_CMP0)
   #define CapSense_sbCSD_cPWM_COMPARE1_LSB_PTR ((reg16 *) CapSense_sbCSD_cPWM_PWMHW__CNT_CMP0)
   #define CapSense_sbCSD_cPWM_COMPARE2_LSB     0x00u
   #define CapSense_sbCSD_cPWM_COMPARE2_LSB_PTR 0x00u
   #define CapSense_sbCSD_cPWM_COUNTER_LSB     (*(reg16 *) CapSense_sbCSD_cPWM_PWMHW__CNT_CMP0)
   #define CapSense_sbCSD_cPWM_COUNTER_LSB_PTR  ((reg16 *) CapSense_sbCSD_cPWM_PWMHW__CNT_CMP0)
   #define CapSense_sbCSD_cPWM_CAPTURE_LSB     (*(reg16 *) CapSense_sbCSD_cPWM_PWMHW__CAP0)
   #define CapSense_sbCSD_cPWM_CAPTURE_LSB_PTR  ((reg16 *) CapSense_sbCSD_cPWM_PWMHW__CAP0)
   
#else
   #if(CapSense_sbCSD_cPWM_PWMModeIsCenterAligned)
       #define CapSense_sbCSD_cPWM_PERIOD_LSB      (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D1_REG)
       #define CapSense_sbCSD_cPWM_PERIOD_LSB_PTR   ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #else
       #define CapSense_sbCSD_cPWM_PERIOD_LSB      (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__F0_REG)
       #define CapSense_sbCSD_cPWM_PERIOD_LSB_PTR   ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__F0_REG)
   #endif
   #define CapSense_sbCSD_cPWM_COMPARE1_LSB    (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D0_REG)
   #define CapSense_sbCSD_cPWM_COMPARE1_LSB_PTR ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D0_REG)
   #define CapSense_sbCSD_cPWM_COMPARE2_LSB    (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #define CapSense_sbCSD_cPWM_COMPARE2_LSB_PTR ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__D1_REG)
   #define CapSense_sbCSD_cPWM_COUNTERCAP_LSB   *(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__A1_REG)
   #define CapSense_sbCSD_cPWM_COUNTERCAP_LSB_PTR ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__A1_REG)
   #define CapSense_sbCSD_cPWM_COUNTER_LSB     (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__A0_REG)
   #define CapSense_sbCSD_cPWM_COUNTER_LSB_PTR  ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__A0_REG)
   #define CapSense_sbCSD_cPWM_CAPTURE_LSB     (*(reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__F1_REG)
   #define CapSense_sbCSD_cPWM_CAPTURE_LSB_PTR  ((reg16 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__F1_REG)
   #define CapSense_sbCSD_cPWM_AUX_CONTROLDP0      (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)
   #define CapSense_sbCSD_cPWM_AUX_CONTROLDP0_PTR  ((reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)
   #if (CapSense_sbCSD_cPWM_Resolution == 16)
       #define CapSense_sbCSD_cPWM_AUX_CONTROLDP1    (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)
       #define CapSense_sbCSD_cPWM_AUX_CONTROLDP1_PTR  ((reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)
   #endif
#endif
   
#if(CapSense_sbCSD_cPWM_KillModeMinTime )
    #define CapSense_sbCSD_cPWM_KILLMODEMINTIME      (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    #define CapSense_sbCSD_cPWM_KILLMODEMINTIME_PTR   ((reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    /* Fixed Function Block has no Kill Mode parameters because it is Asynchronous only */
#endif

#if(CapSense_sbCSD_cPWM_DeadBandMode == CapSense_sbCSD_cPWM__B_PWM__DBM_256_CLOCKS)
    #define CapSense_sbCSD_cPWM_DEADBAND_COUNT        (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
#elif(CapSense_sbCSD_cPWM_DeadBandMode == CapSense_sbCSD_cPWM__B_PWM__DBM_2_4_CLOCKS)
    /* In Fixed Function Block these bits are in the control blocks control register */
    #if (CapSense_sbCSD_cPWM_UsingFixedFunction)
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT        (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__CFG0) 
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sbCSD_cPWM_PWMHW__CFG0)
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_MASK    (0x03u << CapSense_sbCSD_cPWM_DEADBAND_COUNT_SHIFT) 
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_SHIFT   0x06u /* As defined by the Register Map as DEADBAND_PERIOD[1:0] in CFG0 */ 
    #else
        /* Lower two bits of the added control register define the count 1-3 */
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT        (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sDB3_dbctrlreg__CONTROL_REG)
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_PTR     ((reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sDB3_dbctrlreg__CONTROL_REG)
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_MASK    (0x03u << CapSense_sbCSD_cPWM_DEADBAND_COUNT_SHIFT) 
        #define CapSense_sbCSD_cPWM_DEADBAND_COUNT_SHIFT   0x00u /* As defined by the verilog implementation of the Control Register */
    #endif
#endif



#if (CapSense_sbCSD_cPWM_UsingFixedFunction)
    #define CapSense_sbCSD_cPWM_STATUS                (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__SR0)
    #define CapSense_sbCSD_cPWM_STATUS_MASK           (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__SR0)
    #define CapSense_sbCSD_cPWM_CONTROL               (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__CFG0)
    #define CapSense_sbCSD_cPWM_CONTROL2              (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__CFG1)
    #define CapSense_sbCSD_cPWM_GLOBAL_ENABLE         (*(reg8 *) CapSense_sbCSD_cPWM_PWMHW__PM_ACT_CFG)

    /***********************************
    *     Constants
    ***********************************/
    /* Fixed Function Block Chosen */
    #define CapSense_sbCSD_cPWM_BLOCK_EN_MASK          CapSense_sbCSD_cPWM_PWMHW__PM_ACT_MSK
    /* Control Register definitions */
    #define CapSense_sbCSD_cPWM_CTRL_ENABLE_SHIFT      0x00u
    #define CapSense_sbCSD_cPWM_CTRL_RESET_SHIFT       0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE2_SHIFT    0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE1_SHIFT    0x01u   /* As defined by Register map as MODE_CFG bits in CFG1*/
    #define CapSense_sbCSD_cPWM_CTRL_DEAD_TIME_SHIFT   0x06u   /* As defined by Register map */
    /* Fixed Function Block Only CFG register bit definitions */
    #define CapSense_sbCSD_cPWM_CFG0_MODE              0x03u   /* Enable the block to run and set to compare mode */
    #define CapSense_sbCSD_cPWM_CFG0_DB                0x20u   /* As defined by Register map as DB bit in CFG0 */

    /* Control Register Bit Masks */
    #define CapSense_sbCSD_cPWM_CTRL_ENABLE            (0x01u << CapSense_sbCSD_cPWM_CTRL_ENABLE_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_RESET             (0x01u << CapSense_sbCSD_cPWM_CTRL_RESET_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE2_MASK     (0x07u << CapSense_sbCSD_cPWM_CTRL_CMPMODE2_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE1_MASK     (0x07u << CapSense_sbCSD_cPWM_CTRL_CMPMODE1_SHIFT)
    
    /* Control2 Register Bit Masks */
    #define CapSense_sbCSD_cPWM_CTRL2_IRQ_SEL_SHIFT    0x00u       /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define CapSense_sbCSD_cPWM_CTRL2_IRQ_SEL          (0x01u << CapSense_sbCSD_cPWM_CTRL2_IRQ_SEL_SHIFT)  
    
    /* Status Register Bit Locations */
    #define CapSense_sbCSD_cPWM_STATUS_KILL_SHIFT          0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_SHIFT    0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_SHIFT      0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_TC_SHIFT            0x07u   /* As defined by Register map as TC in SR0 */
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_SHIFT          0x00u   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT          0x06u   /* As defined by the Register map as CAP_CMP in SR0 */
    /* Status Register Interrupt Enable Bit Locations */
    #define CapSense_sbCSD_cPWM_STATUS_KILL_INT_EN_MASK_SHIFT          (0x00u)    /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_TC_INT_EN_MASK_SHIFT            (CapSense_sbCSD_cPWM_STATUS_TC_SHIFT - 4)
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_INT_EN_MASK_SHIFT          (0x00u)   /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_INT_EN_MASK_SHIFT          (CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT - 4)
    /* Status Register Bit Masks */
    #define CapSense_sbCSD_cPWM_STATUS_KILL            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY      (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL        (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_TC              (0x01u << CapSense_sbCSD_cPWM_STATUS_TC_SHIFT)
    #define CapSense_sbCSD_cPWM_STATUS_CMP2            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_CMP1            (0x01u << CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT)
    /* Status Register Interrupt Bit Masks*/
    #define CapSense_sbCSD_cPWM_STATUS_KILL_INT_EN_MASK            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_INT_EN_MASK      (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_INT_EN_MASK        (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_TC_INT_EN_MASK              (CapSense_sbCSD_cPWM_STATUS_TC >> 4)
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_INT_EN_MASK            (0x00u) /* Not available in Fixed Function Block */
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_INT_EN_MASK            (CapSense_sbCSD_cPWM_STATUS_CMP1 >> 4)

    /* Datapath Auxillary Control Register definitions */
    //#define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO0_CLR         0x01u   /* As defined by Register map */
    //#define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO1_CLR       0x02u   /* As defined by Register map */
    //#define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO0_LVL       0x04u   /* As defined by Register map */
    //#define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO1_LVL       0x08u   /* As defined by Register map */
    //#define CapSense_sbCSD_cPWM_STATUS_ACTL_INT_EN_MASK    0x10u   /* As defined for the ACTL Register */
#else
    #define CapSense_sbCSD_cPWM_STATUS                (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sSTSReg_stsreg__STATUS_REG )
    #define CapSense_sbCSD_cPWM_STATUS_MASK           (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sSTSReg_stsreg__MASK_REG)
    #define CapSense_sbCSD_cPWM_STATUS_AUX_CTRL       (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sSTSReg_stsreg__STATUS_AUX_CTL_REG)
    #define CapSense_sbCSD_cPWM_CONTROL               (*(reg8 *) CapSense_sbCSD_cPWM_PWMUDB_sCTRLReg_ctrlreg__CONTROL_REG)
    /***********************************
    *     Constants
    ***********************************/
    /* Control Register definitions */
    #define CapSense_sbCSD_cPWM_CTRL_ENABLE_SHIFT      0x07u
    #define CapSense_sbCSD_cPWM_CTRL_RESET_SHIFT       0x06u
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE2_SHIFT    0x03u
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE1_SHIFT    0x00u
	#define CapSense_sbCSD_cPWM_CTRL_DEAD_TIME_SHIFT   0x00u   /* No Shift Needed for UDB block */
    /* Control Register Bit Masks */
    #define CapSense_sbCSD_cPWM_CTRL_ENABLE            (0x01u << CapSense_sbCSD_cPWM_CTRL_ENABLE_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_RESET             (0x01u << CapSense_sbCSD_cPWM_CTRL_RESET_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE2_MASK     (0x07u << CapSense_sbCSD_cPWM_CTRL_CMPMODE2_SHIFT)
    #define CapSense_sbCSD_cPWM_CTRL_CMPMODE1_MASK     (0x07u << CapSense_sbCSD_cPWM_CTRL_CMPMODE1_SHIFT) 
    
    /* Status Register Bit Locations */
    #define CapSense_sbCSD_cPWM_STATUS_KILL_SHIFT          0x05u
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_SHIFT    0x04u
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_SHIFT      0x03u  
    #define CapSense_sbCSD_cPWM_STATUS_TC_SHIFT            0x02u
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_SHIFT          0x01u
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT          0x00u
    /* Status Register Interrupt Enable Bit Locations - UDB Status Interrupt Mask match Status Bit Locations*/
    #define CapSense_sbCSD_cPWM_STATUS_KILL_INT_EN_MASK_SHIFT          CapSense_sbCSD_cPWM_STATUS_KILL_SHIFT          
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_SHIFT    
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      CapSense_sbCSD_cPWM_STATUS_FIFOFULL_SHIFT        
    #define CapSense_sbCSD_cPWM_STATUS_TC_INT_EN_MASK_SHIFT            CapSense_sbCSD_cPWM_STATUS_TC_SHIFT            
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_INT_EN_MASK_SHIFT          CapSense_sbCSD_cPWM_STATUS_CMP2_SHIFT          
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_INT_EN_MASK_SHIFT          CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT   
    /* Status Register Bit Masks */
    #define CapSense_sbCSD_cPWM_STATUS_KILL            (0x00u << CapSense_sbCSD_cPWM_STATUS_KILL_SHIFT )
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL        (0x01u << CapSense_sbCSD_cPWM_STATUS_FIFOFULL_SHIFT)
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY      (0x01u << CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_SHIFT)
    #define CapSense_sbCSD_cPWM_STATUS_TC              (0x01u << CapSense_sbCSD_cPWM_STATUS_TC_SHIFT)
    #define CapSense_sbCSD_cPWM_STATUS_CMP2            (0x01u << CapSense_sbCSD_cPWM_STATUS_CMP2_SHIFT) 
    #define CapSense_sbCSD_cPWM_STATUS_CMP1            (0x01u << CapSense_sbCSD_cPWM_STATUS_CMP1_SHIFT)
    /* Status Register Interrupt Bit Masks  - UDB Status Interrupt Mask match Status Bit Locations */
    #define CapSense_sbCSD_cPWM_STATUS_KILL_INT_EN_MASK            CapSense_sbCSD_cPWM_STATUS_KILL
    #define CapSense_sbCSD_cPWM_STATUS_FIFOFULL_INT_EN_MASK        CapSense_sbCSD_cPWM_STATUS_FIFOFULL
    #define CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY_INT_EN_MASK      CapSense_sbCSD_cPWM_STATUS_FIFONEMPTY
    #define CapSense_sbCSD_cPWM_STATUS_TC_INT_EN_MASK              CapSense_sbCSD_cPWM_STATUS_TC
    #define CapSense_sbCSD_cPWM_STATUS_CMP2_INT_EN_MASK            CapSense_sbCSD_cPWM_STATUS_CMP2
    #define CapSense_sbCSD_cPWM_STATUS_CMP1_INT_EN_MASK            CapSense_sbCSD_cPWM_STATUS_CMP1
                                                          
    /* Datapath Auxillary Control Register definitions */
    #define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO0_CLR     0x01u
    #define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO1_CLR     0x02u
    #define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO0_LVL     0x04u
    #define CapSense_sbCSD_cPWM_AUX_CTRL_FIFO1_LVL     0x08u
    #define CapSense_sbCSD_cPWM_STATUS_ACTL_INT_EN_MASK  0x10u /* As defined for the ACTL Register */
#endif /* CapSense_sbCSD_cPWM_UsingFixedFunction */

#endif  /* CY_PWM_CapSense_sbCSD_cPWM_H */
