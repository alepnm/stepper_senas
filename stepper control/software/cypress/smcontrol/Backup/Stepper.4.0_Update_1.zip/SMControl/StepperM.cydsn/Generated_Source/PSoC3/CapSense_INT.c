/*******************************************************************************
* File Name: CapSense.c
* Version 1.30
*
* Description:
*  This file provides the source code of Interrupt Service Routine (ISR)
*  for CapSense Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSense.h"


#if defined(CapSense_TOTAL_SENSOR_COUNT)
/*******************************************************************************
*  Place your includes, defines and code here
*******************************************************************************/
/* `#START CapSense_ISR_intc` */

/* `#END` */

/*******************************************************************************
* Function Name: CapSense_ISR
********************************************************************************
* Summary:
*  This ISR is executed when PWM window is closed. The widow depends on PWM 
*  resolution paramter. This interrupt handler only used in Serial  mode of 
*  CapSense operation.
*
* Parameters:
*  void:
*
* Return:
*  void
*
*******************************************************************************/
CY_ISR(CapSense_ISR)
{
    /*  Place your Interrupt code here. */
    /* `#START CapSense_ISR` */

    /* `#END` */
    CapSense_status &= ~CapSense_START_CAPSENSING;

    #if(CYDEV_CHIP_DIE_EXPECT == CYDEV_CHIP_DIE_LEOPARD)
        #if defined(CapSense_CSD_METHOD)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_sbCSD_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
        #if defined(CapSense_CSA_METHOD)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_sbCSA_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
    #endif
}
#endif


#if defined(CapSense_TOTAL_SENSOR_COUNT_LEFT)
/*******************************************************************************
*  Place your includes, defines and code here
*******************************************************************************/
/* `#START CapSense_ISRLeft_intc` */

/* `#END` */

/*******************************************************************************
* Function Name: CapSense_ISRLeft
********************************************************************************
* Summary:
*  This ISR is executed when PWM window is closed. The widow depends on PWM 
*  resolution paramter. This interrupt handler only used in Parallel  mode of 
*  CapSense operation.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
CY_ISR(CapSense_ISRLeft)
{
    /*  Place your Interrupt code here. */
    /* `#START CapSense_ISRLeft` */

    /* `#END` */
    CapSense_statusLeft &= ~CapSense_START_CAPSENSING;

    #if(CYDEV_CHIP_DIE_EXPECT == CYDEV_CHIP_DIE_LEOPARD)
        #if defined(CapSense_CSD_METHOD_LEFT)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_lbCSD_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
        #if defined(CapSense_CSA_METHOD_LEFT)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_lbCSA_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
    #endif
}
#endif


#if defined(CapSense_TOTAL_SENSOR_COUNT_RIGHT)
/*******************************************************************************
*  Place your includes, defines and code here
*******************************************************************************/
/* `#START CapSense_ISRRight_intc` */

/* `#END` */

/*******************************************************************************
* Function Name: CapSense_ISRRight
********************************************************************************
* Summary:
*  This ISR is executed when PWM window is closed. The widow depends on PWM 
*  resolution paramter. This interrupt handler only used in Parallel  mode of 
*  CapSense operation.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
CY_ISR(CapSense_ISRRight)
{
    /*  Place your Interrupt code here. */
    /* `#START CapSense_ISRRight` */

    /* `#END` */
    CapSense_statusRight &= ~CapSense_START_CAPSENSING;

    #if(CYDEV_CHIP_DIE_EXPECT == CYDEV_CHIP_DIE_LEOPARD)
        #if defined(CapSense_CSD_METHOD_RIGHT)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_rbCSD_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
        #if defined(CapSense_CSA_METHOD_RIGHT)
            #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_rbCSA_cISR__ES2_PATCH))
                CapSense_ISR_PATCH();
            #endif
        #endif
    #endif
}
#endif


/* [] END OF FILE */
