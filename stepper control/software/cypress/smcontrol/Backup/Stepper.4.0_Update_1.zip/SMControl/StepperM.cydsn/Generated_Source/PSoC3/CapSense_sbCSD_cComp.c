/*******************************************************************************
* File Name: CapSense_sbCSD_cComp.c  
* Version 1.10
*
*  Description:
*    This file provides the source code to the API for the Comparator component.
*
*   Note:
*     
*******************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "CapSense_sbCSD_cComp.h"
#include "CyLib.h"

/* Local Function Prototypes */
void CapSense_sbCSD_cComp_trim1Adjust(void);
void CapSense_sbCSD_cComp_trim2Adjust(void);
void CapSense_sbCSD_cComp_CalDelay(void);

static uint8   CapSense_sbCSD_cComp_initVar = 0;

/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_Start
********************************************************************************
* Summary:
*  The start function initializes the Analog Comparator with the default values.
*
* Parameters:   none
*
* Return:  
*  (void) 
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cComp_Start(void) 
{
    if ( CapSense_sbCSD_cComp_initVar == 0 )
    {
        CapSense_sbCSD_cComp_initVar = 1;

        /* Set default speed/power */
        CapSense_sbCSD_cComp_SetSpeed(CapSense_sbCSD_cComp_DEFAULT_SPEED);

        /* Set default Hysteresis */
        if ( CapSense_sbCSD_cComp_DEFAULT_HYSTERESIS == 0 )
        {
            CapSense_sbCSD_cComp_CR |= CapSense_sbCSD_cComp_HYST_OFF;
        }
        else
        {
            CapSense_sbCSD_cComp_CR &= ~CapSense_sbCSD_cComp_HYST_OFF;  
        }

        /* Set default sync */
        CapSense_sbCSD_cComp_CLK &= ~CapSense_sbCSD_cComp_SYNCCLK_MASK;
        if ( CapSense_sbCSD_cComp_DEFAULT_BYPASS_SYNC == 0 )
        {
            CapSense_sbCSD_cComp_CLK |= CapSense_sbCSD_cComp_SYNC_CLK_EN;
        }
        else
        {
            CapSense_sbCSD_cComp_CLK |= CapSense_sbCSD_cComp_BYPASS_SYNC;
        }
    }

    /* Enable power to comparator */
    CapSense_sbCSD_cComp_PWRMGR |= CapSense_sbCSD_cComp_ACT_PWR_EN;
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_Stop
********************************************************************************
* Summary:
*  Powers down amplifier to lowest power state.
*
* Parameters:  
*   (void)
*
* Return: 
*   (void) 
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cComp_Stop(void)
{
    /* Disable power to comparator */
    CapSense_sbCSD_cComp_PWRMGR &= ~CapSense_sbCSD_cComp_ACT_PWR_EN;
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_SetSpeed
********************************************************************************
* Summary:
*  This function sets the speed of the Analog Comparator.  The faster the speed
*  the more power that is used.
*
* Parameters:  
*  speed:   (uint8) Sets operation mode of Comparator
*
* Return:  
*  (void) 
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cComp_SetSpeed(uint8 speed) 
{
    CapSense_sbCSD_cComp_CR &= ~CapSense_sbCSD_cComp_PWR_MODE_MASK;            /* Clear power level */
    CapSense_sbCSD_cComp_CR |= (speed & CapSense_sbCSD_cComp_PWR_MODE_MASK);   /* Set power level */
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_GetCompare
********************************************************************************
* Summary:
*  This function returns the comparator output value.
*
* Parameters:  
*   None
*
* Return:  
*  (uint8)  0  if Pos_Input less than Neg_input
*           1  if Pos_Input greater than Neg_input. 
*
* Theory: 
*
* Side Effects:
*
*******************************************************************************/
uint8 CapSense_sbCSD_cComp_GetCompare(void) 
{
    return( CapSense_sbCSD_cComp_WRK & CapSense_sbCSD_cComp_CMP_OUT_MASK);
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_ZeroCal
********************************************************************************
* Summary:
*  This function calibrates the offset of the Analog Comparator.
*
* Parameters:  
*  None
*
* Return:  
*  (uint8)  value written in trim register when calibration complete.
*
* Theory: 
*  This function is used to optimize the calibration for user specific voltage
*  range.  The comprator trim is adjusted to counter transitor offsets
*   - offset is defined as positive if the output transitions to high before inP
*     is greater than inN
*   - offset is defined as negative if the output transitions to high avter inP
*     is greater than inP
*
*  The Analog Comparator provides 1 byte for offset trim.  The byte contains two
*  4 bit trim fields - one is a course trim and the other allows smaller
*  offset adjustments.
*  - low nibble is refered to as trim1 - fine trim for Fast mode, course trim
*    for Slow mode
*  - high nibble is refered to as trim2 - fine trim for Slow mode, course trim
*    for Fast mode
*  - trimX[3] selects postive or negative offset adjust
*  - for trim1: trim1[3]is set high to add negative offset
*  - for trim2: trim2[3]is set high to add positive offset  
*
*  Trim algorithm is a two phase process
*  The first phase performs course offset adjustment
*  The second phase serves one of two purposes depending on the outcome of the
*  first phase
*  - if the first trim value was maxed out without a comparator output 
*    transition, more offset will be added by adjusting the second trim value.
*  - if the first trim phase resulted in a comparator output transition, the
*    second trim value will serve as fine trim (in the opposite direction)to
*    ensure the offset is < 1mv.
*
*  Trim Process:   
*  1) User applies a voltage to the negative input.  Voltage should in the
*     comparator operating range or an average of the operating voltage range.
*  2) Clear registers associted analog routing to the positive input.
*  3) Disable Hysteresis
*  4) Set the calibration bit to short the negative and positive inputs to
*     the users calibration voltage.
*  5) Clear the TR register  ( TR = 0x00 )
*  ** SLOW MODE
*  6) Check if compare output is high, if so, set trim1[3] to a 1.
*  7) Increment trim1[2:0] until the compare output changes  (course trim).
*  8) Check if compare output is low, if so, set trim2[3] to a 1.
*  9) Increment trim2[2:0] until the compare output changes state (fine trim)
*  ** FAST MODE - change order of steps 6,7 vs. steps 8,9
*
* Side Effects:
*  Routine clears analog routing associated with the comparator positive input.  
*  This may affect routing of signals from other components that are connected
*  to the positive input of the comparator.
*
*******************************************************************************/
uint8 CapSense_sbCSD_cComp_ZeroCal(void) 
{
    uint8 tmpSW0;
    uint8 tmpSW2;
    uint8 tmpSW3;
    uint8 tmpCR;

    /* Save a copy of routing registers associated with inP */
    tmpSW0 = CapSense_sbCSD_cComp_SW0;
    tmpSW2 = CapSense_sbCSD_cComp_SW2;
    tmpSW3 = CapSense_sbCSD_cComp_SW3;

     /* Clear routing for inP, retain routing for inN */
    CapSense_sbCSD_cComp_SW0 = 0x00;
    CapSense_sbCSD_cComp_SW2 = 0x00;
    CapSense_sbCSD_cComp_SW3 = tmpSW3 & ~CapSense_sbCSD_cComp_CMP_SW3_INPCTL_MASK;

    /* Preserve original configuration
     * - turn off Hysteresis
     * - set calibration bit - shorts inN to inP
    */
    tmpCR = CapSense_sbCSD_cComp_CR;
    CapSense_sbCSD_cComp_CR |= (CapSense_sbCSD_cComp_CAL_ON | CapSense_sbCSD_cComp_HYST_OFF);
    
    /* Write default low values to trim register - no offset adjust */
    CapSense_sbCSD_cComp_TR = 0x00;

    /* Two phase trim - mode determines which value is trimed first */   
    if ( (CapSense_sbCSD_cComp_CR & CapSense_sbCSD_cComp_PWR_MODE_MASK) == CapSense_sbCSD_cComp_PWR_MODE_FAST)
    {
        CapSense_sbCSD_cComp_trim2Adjust();          /* course trim */
        CapSense_sbCSD_cComp_trim1Adjust();          /* fine trim */
    }
    else /* default to trim for slow mode */
    {
        CapSense_sbCSD_cComp_trim1Adjust();          /* course trim */
        CapSense_sbCSD_cComp_trim2Adjust();          /* fine trim */
    }
   
    /* Restore Config Register */
    CapSense_sbCSD_cComp_CR = tmpCR;
    
    /* Restore routing registers for inP */
    CapSense_sbCSD_cComp_SW0 = tmpSW0;
    CapSense_sbCSD_cComp_SW2 = tmpSW2;
    CapSense_sbCSD_cComp_SW3 = tmpSW3;
    
    return(CapSense_sbCSD_cComp_TR);
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_LoadTrim
********************************************************************************
* Summary:
*  This function stores a value in the Analog Comparator trim register.
*
* Parameters:  
*  uint8    trimVal - trim value.  This value is the same format as the value 
*           returned by the _ZeroCal routine.
*
* Return:  
*  None
*
*******************************************************************************/
void CapSense_sbCSD_cComp_LoadTrim(uint8 trimVal) 
{
      CapSense_sbCSD_cComp_TR = trimVal;
}



/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_trim1Adjust
********************************************************************************
* Summary:
*  This function adjusts the value in the low nibble of the Analog Comparator 
*  trim register (trim1)
*
* Parameters:  
*  None
*
* Return:
*  None
*
* Theory: 
*  Function assumes comparator block is setup for trim adjust.
*  Intended to be called from Comp_ZeroCal()
* 
* Side Effects:
*  Routine uses a course 1ms delay following each trim adjustment to allow 
*  the comparator output to respond.  Worse case trim adjustment can result in
*  upto a 16ms delay.
*
*******************************************************************************/
void CapSense_sbCSD_cComp_trim1Adjust(void) 
{
    uint8 trimCnt;
    uint8 cmpState;   

    /* get current state of comparator output */
    cmpState = CapSense_sbCSD_cComp_WRK & CapSense_sbCSD_cComp_CMP_OUT_MASK;
    
    /* if comparator output is high, negative offset adjust is required */
    if ( cmpState != 0 )
    {
        CapSense_sbCSD_cComp_TR |= CapSense_sbCSD_cComp_CMP_TRIM1_DIR;
    }

    /* Increment trim value until compare output changes state */
    for ( trimCnt = 0; trimCnt < 7; trimCnt++ )
    {
        CapSense_sbCSD_cComp_TR += 1;
        CyDelay(1);

        /* Check for change in comparator output */
        if ((CapSense_sbCSD_cComp_WRK & CapSense_sbCSD_cComp_CMP_OUT_MASK) != cmpState)
        {
            break;      /* output changed state, trim phase is complete */
        }
    }
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cComp_trim2Adjust
********************************************************************************
* Summary:
*  This function adjusts the value in the high nibble of the Analog Comparator 
*  trim register (trim2)
*
* Parameters:  
*  None
*
* Return:
*  None
*
* Theory: 
*  Function assumes comparator block is setup for trim adjust.
*  Intended to be called from Comp_ZeroCal()
* 
* Side Effects:
*  Routine uses a course 1ms delay following each trim adjustment to allow 
*  the comparator output to respond.  Worse case trim adjustment can result in
*  upto a 16ms delay.
*
*******************************************************************************/
void CapSense_sbCSD_cComp_trim2Adjust(void) 
{
    uint8 trimCnt;
    uint8 cmpState;

    /* get current state of comparator output */
    cmpState = CapSense_sbCSD_cComp_WRK & CapSense_sbCSD_cComp_CMP_OUT_MASK;
    
    /* if comparator output is low, positive offset adjust is required */
    if ( cmpState == 0 )
    {
        CapSense_sbCSD_cComp_TR |= CapSense_sbCSD_cComp_CMP_TRIM2_DIR; 
    }

    /* Increment trim value until compare output changes state */
    for ( trimCnt = 0; trimCnt < 7; trimCnt++ )
    {
        CapSense_sbCSD_cComp_TR += 0x10;
        CyDelay(1);
        
        /* Check for change in comparator output */
        if ( (CapSense_sbCSD_cComp_WRK & CapSense_sbCSD_cComp_CMP_OUT_MASK) != cmpState )
        {
            break;      /* output changed state, trim phase is complete */
        }
    }
}

/* [] END OF FILE */

