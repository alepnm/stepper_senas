/*******************************************************************************
* File Name: LED_Test.c  
* Version 1.0
*
* Description:
*  This file contains API to enable firmware control of a Digital Port.
*
* Note:
*
********************************************************************************
* Copyright (2008), Cypress Semiconductor Corporation.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is 
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable 
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress Source Code and derivative works for the sole purpose of creating 
* custom software in support of licensee product to be used only in conjunction 
* with a Cypress integrated circuit as specified in the applicable agreement. 
* Any reproduction, modification, translation, compilation, or representation of 
* this software except as specified above is prohibited without the express 
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. Use may be 
* limited by and subject to the applicable Cypress software license agreement. 
*******************************************************************************/

#include "cytypes.h"
#include "LED_Test.h"


/*******************************************************************************
* Function Name: LED_Test_Write
********************************************************************************
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  void 
*  
*******************************************************************************/
void LED_Test_Write(uint8 prtValue)
{
    uint8 staticBits = LED_Test_DR & ~LED_Test_MASK;
    LED_Test_DR = staticBits | ((prtValue << LED_Test_SHIFT) & LED_Test_MASK);
}


/*******************************************************************************
* Function Name: LED_Test_WriteDM
********************************************************************************
* Summary:
*  Change the drive mode on the pins of the port.  Use the input mask to change
*  a selected subset of the pins.
* 
* Parameters:  
*  mode:  Change the pins to this drive mode.
*  mask:  Bits of the mask that are set to 1 will allow the associated pins to 
*         be set to the new drive mode.
*
* Return: 
*  void
*  
* Note: 
*  The mask parameter is a mask of the LED_Test Digital Port component.
*  It is _NOT_ a mask for the physical port. 
*
*******************************************************************************/
void LED_Test_WriteDM(uint8 mode, uint8 mask)
{
    /* Temp variable for read, modify, write of DM registers */
    uint8 staticBits = 0;
    /* Temp value for state of each drive mode pin*/
    uint8 dmBitState = 0;
    /* Map the right justified Digital Port mask to the physical location */ 
    mask = mask << LED_Test_SHIFT;
    /* Ensure that no pins outside the digital port are attempted to be masked
     * Then Mask is adjusted for the physical port.  For this function, it 
     * should be used instead of `INSTANCE_NAME`_MASK.
     */
    mask &= LED_Test_MASK;
    

    /* Mode must be between 0 and 7 */
    mode &= LED_Test_MODE_MASK;
    
    
    /* Should bit-0 be set or cleared? */
    if((mode & LED_Test_MODE_BIT_0) != 0)
        dmBitState = LED_Test_BIT_SET;
 
    /* Read, modify, write drive mode Bit-0 */
    staticBits = LED_Test_DM0 & ~ mask;
    LED_Test_DM0 = staticBits | (dmBitState & mask); 
    
    
    /* Should bit-1 be set or cleared? */
    if((mode & LED_Test_MODE_BIT_1) != 0)
        dmBitState = LED_Test_BIT_SET;
    else
        dmBitState = LED_Test_BIT_CLEAR;
    
    /* Read, modify, write drive mode Bit-1 */
    staticBits = LED_Test_DM1 & ~ mask;
    LED_Test_DM1 = staticBits | (dmBitState & mask); 
    
    
    /* Should bit-2 be set or cleared? */
    if((mode & LED_Test_MODE_BIT_2) != 0)
        dmBitState = LED_Test_BIT_SET;
    else
        dmBitState = LED_Test_BIT_CLEAR;

    /* Read, modify, write drive mode Bit-2 */
    staticBits = LED_Test_DM2 & ~ mask;
    LED_Test_DM2 = staticBits | (dmBitState & mask); 
}


/*******************************************************************************
* Function Name: LED_Test_Read
********************************************************************************
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  void 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro LED_Test_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 LED_Test_Read(void)
{
    return (LED_Test_PS & LED_Test_MASK) >> LED_Test_SHIFT;
}


/*******************************************************************************
* Function Name: LED_Test_ReadDR
********************************************************************************
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  void 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 LED_Test_ReadDR(void)
{
    return (LED_Test_DR & LED_Test_MASK) >> LED_Test_SHIFT;
}


/* If Interrupts Are Enabled for this Digital Port */ 
#if defined(LED_Test_INTSTAT) 

    /*******************************************************************************
    * Function Name: LED_Test_ClearInterrupt
    ********************************************************************************
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  void 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 LED_Test_ClearInterrupt(void)
    {
        return (LED_Test_INTSTAT & LED_Test_MASK) >> LED_Test_SHIFT;
    }


    /*******************************************************************************
    * Function Name: LED_Test_GetLastInterrupt
    ********************************************************************************
    * Summary:
    *  Gets the value of the interrupt status register from the last time it was 
    *  read by reading the Snapshot Register.  
    *
    * Parameters:  
    *  void 
    *
    * Return: 
    *  Returns the last value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 LED_Test_GetLastInterrupt(void)
    {
        return (LED_Test_SNAP & LED_Test_MASK) >> LED_Test_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Digital Port */ 


/* [] END OF FILE */ 
