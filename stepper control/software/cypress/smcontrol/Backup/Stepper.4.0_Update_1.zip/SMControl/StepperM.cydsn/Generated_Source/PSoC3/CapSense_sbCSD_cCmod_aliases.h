/*******************************************************************************
* File Name: CapSense_sbCSD_cCmod.h  
* Version 1.20
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_CapSense_sbCSD_cCmod_ALIASES_H) /* Pins CapSense_sbCSD_cCmod_ALIASES_H */
#define CY_PINS_CapSense_sbCSD_cCmod_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"

/***************************************
*              Constants        
***************************************/
#define CapSense_sbCSD_cCmod_0		CapSense_sbCSD_cCmod__0__PC

#define CapSense_sbCSD_cCmod_sCmod		CapSense_sbCSD_cCmod__sCmod__PC

#endif /* End Pins CapSense_sbCSD_cCmod_ALIASES_H */

/* [] END OF FILE */
