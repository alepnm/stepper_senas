/*******************************************************************************
* File Name: VDAC8_IrefA_PM.c  
* Version 1.90
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "VDAC8_IrefA.h"

static VDAC8_IrefA_backupStruct VDAC8_IrefA_backup;


/*******************************************************************************
* Function Name: VDAC8_IrefA_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC8_IrefA_SaveConfig(void) 
{
    if (!((VDAC8_IrefA_CR1 & VDAC8_IrefA_SRC_MASK) == VDAC8_IrefA_SRC_UDB))
    {
        VDAC8_IrefA_backup.data_value = VDAC8_IrefA_Data;
    }
}


/*******************************************************************************
* Function Name: VDAC8_IrefA_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC8_IrefA_RestoreConfig(void) 
{
    if (!((VDAC8_IrefA_CR1 & VDAC8_IrefA_SRC_MASK) == VDAC8_IrefA_SRC_UDB))
    {
        if((VDAC8_IrefA_Strobe & VDAC8_IrefA_STRB_MASK) == VDAC8_IrefA_STRB_EN)
        {
            VDAC8_IrefA_Strobe &= (uint8)(~VDAC8_IrefA_STRB_MASK);
            VDAC8_IrefA_Data = VDAC8_IrefA_backup.data_value;
            VDAC8_IrefA_Strobe |= VDAC8_IrefA_STRB_EN;
        }
        else
        {
            VDAC8_IrefA_Data = VDAC8_IrefA_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: VDAC8_IrefA_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  VDAC8_IrefA_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void VDAC8_IrefA_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(VDAC8_IrefA_ACT_PWR_EN == (VDAC8_IrefA_PWRMGR & VDAC8_IrefA_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        VDAC8_IrefA_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        VDAC8_IrefA_backup.enableState = 0u;
    }
    
    VDAC8_IrefA_Stop();
    VDAC8_IrefA_SaveConfig();
}


/*******************************************************************************
* Function Name: VDAC8_IrefA_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  VDAC8_IrefA_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void VDAC8_IrefA_Wakeup(void) 
{
    VDAC8_IrefA_RestoreConfig();
    
    if(VDAC8_IrefA_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        VDAC8_IrefA_Enable();

        /* Restore the data register */
        VDAC8_IrefA_SetValue(VDAC8_IrefA_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
