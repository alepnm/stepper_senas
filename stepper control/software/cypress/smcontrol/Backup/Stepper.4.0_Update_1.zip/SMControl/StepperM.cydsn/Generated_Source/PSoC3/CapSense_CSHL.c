/*******************************************************************************
* File Name: CapSense.c
* Version 1.30
*
* Description:
*  This file provides the source code to the High Level API for the CapSesne
*  Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSense_CSHL.h"


CapSense_SlSettings CapSense_SlSettingsTable[1] = 
{
    {25600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

CapSense_Widget CapSense_CSHL_WidgetTable[] = 
{
    {CapSense_CSHL_TYPE_LINEAR_SLIDER, 2, 2, 20, 10, 0, 0, 0, &CapSense_SlSettingsTable[0]},
    {CapSense_CSHL_TYPE_BUTTON, 0, 1, 20, 10, 5, 5, 0, 0x00},
    {CapSense_CSHL_TYPE_BUTTON, 1, 1, 20, 10, 5, 5, 0, 0x00}
};
extern CapSense_Slot CapSense_ScanSlotTable[CapSense_TOTAL_SCANSLOT_COUNT]; 
extern uint16 CapSense_SlotResult[CapSense_TOTAL_SCANSLOT_COUNT];

uint8 CapSense_CSHL_SlotOnMask[(((CapSense_TOTAL_SCANSLOT_COUNT - 1) / 8) + 1)] = {0};
uint16 CapSense_CSHL_SlotBaseline[CapSense_TOTAL_SCANSLOT_COUNT] = {0};
uint8 CapSense_CSHL_SlotBaselineLow[CapSense_TOTAL_SCANSLOT_COUNT] = {0};
uint8 CapSense_CSHL_SlotSignal[CapSense_TOTAL_SCANSLOT_COUNT] = {0};


/*******************************************************************************
* Function Name: CapSense_CSHL_MedianFilter
********************************************************************************
*
* Summary:
*  Median filter funciton.
*
* Parameters:
*  x1:  Current value
*  x2:  Previous value
*  x3:  Before previous value
*
* Return:
*  Returns filtered value.
*
*******************************************************************************/
uint16 CapSense_CSHL_MedianFilter(uint16 x1, uint16 x2, uint16 x3)
{
    uint16 tmp;

    if (x1 > x2)
    {
        tmp = x2;
        x2 = x1;
        x1 = tmp;
    }

    if(x2 > x3)
    {
        x2 = x3;
    }

    return ((x1 > x2) ? x1 : x2);
}


/*******************************************************************************
* Function Name: CapSense_CSHL_AveragingFilter
********************************************************************************
*
* Summary:
*  Averaging filter function.
*
* Parameters:
*  x1:  Current value
*  x2:  Previous value
*  x3:  Before previous value
*
* Return:
*  Returns filtered value.
*
*******************************************************************************/
uint16 CapSense_CSHL_AveragingFilter(uint16 x1, uint16 x2, uint16 x3)
{
    uint32 tmp = ((uint32)x1 + (uint32)x2 + (uint32)x3)/3;

    return ((uint16) tmp);
}


/*******************************************************************************
* Function Name: CapSense_CSHL_IIRFilter
********************************************************************************
*
* Summary:
*  IIR filter function.
*
* Parameters:
*  x1:  Current value
*  x2:  Previous value
*  type:  Type formula of IIR filter.
*
* Return:
*  Returns filtered value.
*
*******************************************************************************/
uint16 CapSense_CSHL_IIRFilter(uint16 x1, uint16 x2, uint8 type)
{
    uint32 tmp;

    if (type == CapSense_CSHL_IIR_FILTER_0)
    {
        /* IIR = 1/2 Current Value+ 1/2 Previous Value */
        tmp = (uint32)x1 + (uint32)x2;
        tmp >>= 1;
    }
    else
    {
        /* IIR = 1/4 Current Value + 3/4 Previous Value */
        tmp = (uint32)x1 + (uint32)x2;
        tmp += ((uint32)x2 << 1);
        tmp >>= 2;
    }

    return ((uint16) tmp);
}


/*******************************************************************************
* Function Name: uint16 CapSense_CSHL_JitterFilter
********************************************************************************
*
* Summary:
*  Jitter filter funciton.
*
* Parameters:
*  x1:  Current value
*  x2:  Previous value
*
* Return:
*  Returns filtered value.
*
*******************************************************************************/
uint16 CapSense_CSHL_JitterFilter(uint16 x1, uint16 x2)
{
    if (x1 > x2)
    {
        x1--;
    }
    else
    {
        if (x1 < x2)
        {
            x1++;
        }
    }

    return x1;
}

/*******************************************************************************
* Function Name: CapSense_CSHL_InitializeSlotBaseline
********************************************************************************
*
* Summary:
*  Loads the CapSense_CSHL_SlotBaseline[slot] array element with an initial
*  value by scanning the selected slot. The raw count value is copied into
*  the baseline array for each slot. The raw data filters are initialized
*  if enabled.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSHL_InitializeSlotBaseline(uint8 slot)
{
    void *ptr;
    uint8 rawIndex = CapSense_ScanSlotTable[slot].RawIndex;
    uint8 widget = CapSense_ScanSlotTable[slot].WidgetNumber;
    uint8 filterPos = rawIndex - CapSense_CSHL_WidgetTable[widget].RawOffset;
    
    if( widget != CapSense_CSHL_NO_WIDGET)
    {
        /* Scan slot to have raw data */
        CapSense_CSD_ScanSlot(slot);
        
        /* Initialize Baseline */
        CapSense_CSHL_SlotBaseline[rawIndex] = CapSense_SlotResult[rawIndex];
        CapSense_CSHL_SlotBaselineLow[rawIndex] = 0;
        CapSense_CSHL_SlotSignal[rawIndex] = 0;
        CapSense_ScanSlotTable[slot].DebounceCount = CapSense_CSHL_WidgetTable[widget].Debounce;
        
        switch ((CapSense_CSHL_WidgetTable[widget].Type & (~CapSense_CSHL_IS_DIPLEX)))
        {
            /* This case include BTN and PROX */
            case CapSense_CSHL_TYPE_BUTTON:
            case CapSense_CSHL_TYPE_PROXIMITY:
                if (CapSense_CSHL_WidgetTable[widget].AdvancedSettings)
                {
                    ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                    
                    /* Median filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                    {
                        ((CapSense_BtnSettings *) ptr)->Raw2Median = CapSense_SlotResult[rawIndex];
                        ((CapSense_BtnSettings *) ptr)->Raw1Median = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* Averaging filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                    {
                        ((CapSense_BtnSettings *) ptr)->Raw2Averaging = CapSense_SlotResult[rawIndex];
                        ((CapSense_BtnSettings *) ptr)->Raw1Averaging = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* IIR filter first time initialization */
                    if((CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0) ||
                        (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1))
                    {
                        ((CapSense_BtnSettings *) ptr)->RawIIR = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* Jitter filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                    {
                        ((CapSense_BtnSettings *) ptr)->RawJitter = CapSense_SlotResult[rawIndex];
                    }
                }
                break;
            
            /* This case include LINEAR and RADIAL Slider */
            case CapSense_CSHL_TYPE_RADIAL_SLIDER :
            case CapSense_CSHL_TYPE_LINEAR_SLIDER :
                
                ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                ((CapSense_SlSettings *) ptr)->FirstTime=0;
                
                /* Median filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                {
                    ((CapSense_SlSettings *) ptr)->Raw2Median[filterPos] = CapSense_SlotResult[rawIndex];
                    ((CapSense_SlSettings *) ptr)->Raw1Median[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* Averaging filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                {
                    ((CapSense_SlSettings *) ptr)->Raw2Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                    ((CapSense_SlSettings *) ptr)->Raw1Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* IIR filter first time initialization */
                if((CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0) ||
                    (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1))
                {
                    ((CapSense_SlSettings *) ptr)->RawIIR[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* Jitter filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                {
                    ((CapSense_SlSettings *) ptr)->RawJitter[filterPos] = CapSense_SlotResult[rawIndex];
                }
                break;
                
            case CapSense_CSHL_TYPE_TOUCHPAD:
                
                ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                ((CapSense_TPSettings *) ptr)->FirstTime=0;
                
                /* Median filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                {
                    ((CapSense_TPSettings *) ptr)->Raw2Median[filterPos] = CapSense_SlotResult[rawIndex];
                    ((CapSense_TPSettings *) ptr)->Raw1Median[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* Averaging filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                {
                    ((CapSense_TPSettings *) ptr)->Raw2Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                    ((CapSense_TPSettings *) ptr)->Raw1Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* IIR filter first time initialization */
                if((CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0) ||
                    (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1))
                {
                    ((CapSense_TPSettings *) ptr)->RawIIR[filterPos] = CapSense_SlotResult[rawIndex];
                }
                
                /* Jitter filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                {
                    ((CapSense_TPSettings *) ptr)->RawJitter[filterPos] = CapSense_SlotResult[rawIndex];
                }
                break;
                
            case CapSense_CSHL_TYPE_MATRIX_BUTTONS:
                
                if (CapSense_CSHL_WidgetTable[widget].AdvancedSettings)
                {
                    ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                    
                    /* Median filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                    {
                        ((CapSense_MBSettings *) ptr)->Raw2Median[filterPos] = CapSense_SlotResult[rawIndex];
                    (   (CapSense_MBSettings *) ptr)->Raw1Median[filterPos] = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* Averaging filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                    {
                        ((CapSense_MBSettings *) ptr)->Raw2Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                        ((CapSense_MBSettings *) ptr)->Raw1Averaging[filterPos] = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* IIR filter first time initialization */
                    if((CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0) ||
                        (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1))
                    {
                        ((CapSense_MBSettings *) ptr)->RawIIR[filterPos] = CapSense_SlotResult[rawIndex];
                    }
                    
                    /* Jitter filter first time initialization */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                    {
                        ((CapSense_MBSettings *) ptr)->RawJitter[filterPos] = CapSense_SlotResult[rawIndex];
                    }
                }
                break;
                        
            default:
            
                break;
        }
    }
}


/*******************************************************************************
* Function Name: CapSense_CSHL_InitializeAllBaselines
********************************************************************************
*
* Summary:
*  Uses the CapSense_CSHL_InitializeSlotBaselines function to
*  loads the CapSense_CSHL_SlotBaseline[ ] array with an initial values by
*  scanning all slots. The raw count values are copied into the baseline array
*  for all slots. The raw data filters are initialized if enabled.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void CapSense_CSHL_InitializeAllBaselines(void)
{
    uint8 i;
    
    for(i = 0; i < CapSense_TOTAL_SCANSLOT_COUNT; i++)
    {
        CapSense_CSHL_InitializeSlotBaseline(i);
    }
}


/*******************************************************************************
* Function Name: CapSense_CSHL_UpdateSlotBaseline
********************************************************************************
*
* Summary:
*  Updates the CapSense_CSHL_SlotBaseline[ ] array using the LP filter with
*  k = 256. The signal calculates the difference between raw count and baseline.
*  The baseline stops updating if signal is greater that zero.
*  Raw data filters are applied to the values if enabled.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  void
*
*******************************************************************************/
 void CapSense_CSHL_UpdateSlotBaseline(uint8 slot)
{
    void *ptr;
    uint8 rawIndex = CapSense_ScanSlotTable[slot].RawIndex;
    uint8 widget = CapSense_ScanSlotTable[slot].WidgetNumber;
    uint8 filterPos = rawIndex - CapSense_CSHL_WidgetTable[widget].RawOffset;
    uint16 filteredRawData = CapSense_SlotResult[rawIndex];
    int32 temp;
    uint16 baseRawData;
    
    if( widget != CapSense_CSHL_NO_WIDGET)
    {
        
        /* Do filtering */
        switch ((CapSense_CSHL_WidgetTable[widget].Type & (~CapSense_CSHL_IS_DIPLEX)))
        {
            /* This case include BTN and PROX */
            case CapSense_CSHL_TYPE_BUTTON:
            case CapSense_CSHL_TYPE_PROXIMITY:
                if(CapSense_CSHL_WidgetTable[widget].AdvancedSettings)
                {
                    ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                    
                    /* Median filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_MedianFilter(filteredRawData, ((CapSense_BtnSettings *) ptr)->Raw1Median, ((CapSense_BtnSettings *) ptr)->Raw2Median);
                        ((CapSense_BtnSettings *) ptr)->Raw2Median = ((CapSense_BtnSettings *) ptr)->Raw1Median;
                        ((CapSense_BtnSettings *) ptr)->Raw1Median = baseRawData;
                    }
                    
                    /* Averaging filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_AveragingFilter(filteredRawData, ((CapSense_BtnSettings *) ptr)->Raw1Averaging, ((CapSense_BtnSettings *) ptr)->Raw2Averaging);
                        ((CapSense_BtnSettings *) ptr)->Raw2Averaging = ((CapSense_BtnSettings *) ptr)->Raw1Averaging;
                        ((CapSense_BtnSettings *) ptr)->Raw1Averaging = baseRawData;
                    }
                    
                    /* IIR filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_BtnSettings *) ptr)->RawIIR, CapSense_CSHL_IIR_FILTER_0);
                        ((CapSense_BtnSettings *) ptr)->RawIIR = baseRawData;
                    }
                    else if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_BtnSettings *) ptr)->RawIIR, CapSense_CSHL_IIR_FILTER_1);
                        ((CapSense_BtnSettings *) ptr)->RawIIR = baseRawData;
                    }
                    
                    /* Jitter filter*/
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_JitterFilter(filteredRawData, ((CapSense_BtnSettings *) ptr)->RawJitter);
                        ((CapSense_BtnSettings *) ptr)->RawJitter = baseRawData;
                    }
                }
                break;
            
            /* This case include LINEAR and RADIAL Slider */
            case CapSense_CSHL_TYPE_RADIAL_SLIDER :
            case CapSense_CSHL_TYPE_LINEAR_SLIDER :
                ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                
                /* Median filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_MedianFilter(filteredRawData, ((CapSense_SlSettings *) ptr)->Raw1Median[filterPos], ((CapSense_SlSettings *) ptr)->Raw2Median[filterPos]);
                    ((CapSense_SlSettings *) ptr)->Raw2Median[filterPos] = ((CapSense_SlSettings *) ptr)->Raw1Median[filterPos];
                    ((CapSense_SlSettings *) ptr)->Raw1Median[filterPos] = baseRawData;
                }
                
                /* Averaging filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                {
                    baseRawData = filteredRawData;
                       filteredRawData = CapSense_CSHL_AveragingFilter(filteredRawData, ((CapSense_SlSettings *) ptr)->Raw1Averaging[filterPos], ((CapSense_SlSettings *) ptr)->Raw2Averaging[filterPos]);
                    ((CapSense_SlSettings *) ptr)->Raw2Averaging[filterPos] = ((CapSense_SlSettings *) ptr)->Raw1Averaging[filterPos];
                    ((CapSense_SlSettings *) ptr)->Raw1Averaging[filterPos] = baseRawData;
                }
                
                /* IIR filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_SlSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_0);
                    ((CapSense_SlSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                }
                else if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_SlSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_1);
                    ((CapSense_SlSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                }
                
                /* Jitter filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_JitterFilter(filteredRawData, ((CapSense_SlSettings *) ptr)->RawJitter[filterPos]);
                    ((CapSense_SlSettings *) ptr)->RawJitter[filterPos] = baseRawData;
                }
                break;
                
            case CapSense_CSHL_TYPE_TOUCHPAD:
                ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                
                /* Median filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_MedianFilter(filteredRawData, ((CapSense_TPSettings *) ptr)->Raw1Median[filterPos], ((CapSense_TPSettings *) ptr)->Raw2Median[filterPos]);
                       ((CapSense_TPSettings *) ptr)->Raw2Median[filterPos] = ((CapSense_TPSettings *) ptr)->Raw1Median[filterPos];
                    ((CapSense_TPSettings *) ptr)->Raw1Median[filterPos] = baseRawData;
                }
                
                /* Averaging filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_AveragingFilter(filteredRawData, ((CapSense_TPSettings *) ptr)->Raw1Averaging[filterPos], ((CapSense_TPSettings *) ptr)->Raw2Averaging[filterPos]);
                    ((CapSense_TPSettings *) ptr)->Raw2Averaging[filterPos] = ((CapSense_TPSettings *) ptr)->Raw1Averaging[filterPos];
                    ((CapSense_TPSettings *) ptr)->Raw1Averaging[filterPos] = baseRawData;
                }
                
                /* IIR filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_TPSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_0);
                    ((CapSense_TPSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                }
                else if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_TPSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_1);
                    ((CapSense_TPSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                }
                
                /* Jitter filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                {
                    baseRawData = filteredRawData;
                    filteredRawData = CapSense_CSHL_JitterFilter(filteredRawData, ((CapSense_TPSettings *) ptr)->RawJitter[filterPos]);
                    ((CapSense_TPSettings *) ptr)->RawJitter[filterPos] = baseRawData;
                }
                break;
                
            case CapSense_CSHL_TYPE_MATRIX_BUTTONS:
                if(CapSense_CSHL_WidgetTable[widget].AdvancedSettings)
                {
                ptr = CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
                
                    /* Median filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_MEDIAN_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_MedianFilter(filteredRawData, ((CapSense_MBSettings *) ptr)->Raw1Median[filterPos], ((CapSense_MBSettings *) ptr)->Raw2Median[filterPos]);
                        ((CapSense_MBSettings *) ptr)->Raw2Median[filterPos] = ((CapSense_MBSettings *) ptr)->Raw1Median[filterPos];
                        ((CapSense_MBSettings *) ptr)->Raw1Median[filterPos] = baseRawData;
                    }
                    
                    /* Averaging filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_AVERAGING_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_AveragingFilter(filteredRawData, ((CapSense_MBSettings *) ptr)->Raw1Averaging[filterPos], ((CapSense_MBSettings *) ptr)->Raw2Averaging[filterPos]);
                        ((CapSense_MBSettings *) ptr)->Raw2Averaging[filterPos] = ((CapSense_MBSettings *) ptr)->Raw1Averaging[filterPos];
                        ((CapSense_MBSettings *) ptr)->Raw1Averaging[filterPos] = baseRawData;                
                    }
                    
                    /* IIR filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_0)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_MBSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_0);
                        ((CapSense_MBSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                    }
                    else if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_IIR_FILTER_1)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_IIRFilter(filteredRawData, ((CapSense_MBSettings *) ptr)->RawIIR[filterPos], CapSense_CSHL_IIR_FILTER_1);
                        ((CapSense_MBSettings *) ptr)->RawIIR[filterPos] = baseRawData;
                    }
                    
                    /* Jitter filter */
                    if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_RAW_JITTER_FILTER)
                    {
                        baseRawData = filteredRawData;
                        filteredRawData = CapSense_CSHL_JitterFilter(filteredRawData, ((CapSense_MBSettings *) ptr)->RawJitter[filterPos]);
                        ((CapSense_MBSettings *) ptr)->RawJitter[filterPos] = baseRawData;
                    }
                }
                break;
                
            default:
                
                break;
        }
        
        /* Baseline calculation */
        CapSense_SlotResult[rawIndex] = filteredRawData;
        
        /* Find the Signal */
        temp = ( (int32) filteredRawData) - ( (int32) CapSense_CSHL_SlotBaseline[rawIndex]);
        if (temp < 0)
        {
            /* RawData less that Baseline */
            CapSense_CSHL_SlotSignal[rawIndex] = 0;
        }
        
        /* Update Baseline if lower that NoiseThreshold */
        if (temp < CapSense_CSHL_WidgetTable[widget].NoiseThreshold)
        {
            /* make full Baseline 23 bits */;
            temp = ((((uint32) CapSense_CSHL_SlotBaseline[rawIndex]) << 8) | ((uint32) CapSense_CSHL_SlotBaselineLow[rawIndex]));
            
            /* add Raw Data to Baseline */
              temp += filteredRawData;
            
            /* sub the high Baseline */
            temp -= CapSense_CSHL_SlotBaseline[rawIndex];
            
            /* Put Baseline and BaselineLow */
            CapSense_CSHL_SlotBaselineLow[rawIndex] = ((uint8) temp);
            CapSense_CSHL_SlotBaseline[rawIndex] = ((uint16) (temp >> 8));
            
            /* Signal is zero */
            CapSense_CSHL_SlotSignal[rawIndex] = 0;
        }
        else
        {
            temp -= CapSense_CSHL_WidgetTable[widget].NoiseThreshold;
            
            if(temp < 0xFFu)
            {
                CapSense_CSHL_SlotSignal[rawIndex] = (uint8) temp;
            }
            else
            {
                CapSense_CSHL_SlotSignal[rawIndex] = 0xFFu;
            }
        }
    }
}


/*******************************************************************************
* Function Name: CapSense_CSHL_UpdateAllBaselines
********************************************************************************
*
* Summary:
*  Uses the CapSense_CSHL_UpdateSlotBaselines function to update
*  baselines for all slots. Raw data filters are applied to the values if
*  enabled.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
 void CapSense_CSHL_UpdateAllBaselines(void)
{
    uint8 i;
    
    for(i = 0; i < CapSense_TOTAL_SCANSLOT_COUNT; i++)
    {
        CapSense_CSHL_UpdateSlotBaseline(i);
    }
}


/*******************************************************************************
* Function Name: CapSense_CSHL_CheckIsSlotActive
********************************************************************************
*
* Summary:
*  Compares the selected slot of the CapSense_CSHL_Signal[ ] array to its finger
*  threshold. Hysteresis and Debounce are taken into account. The Hysteresis value
*  is added or subtracted from the finger threshold based on whether the slot is
*  currently active. If the slot is active, the threshold is lowered by the
*  hysteresis amount. If it is inactive, the threshold is raised by the
*  hysteresis amount. The Debounce counter added to the slot active transition.
*  This function also updates the slot's bit in the
*  CapSense_CSHL_SlotOnMask[ ] array
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  Returns scan slot state 1 if active, 0 if inactive
*
*******************************************************************************/
uint8 CapSense_CSHL_CheckIsSlotActive(uint8 slot)
{
    uint8 rawIndex = CapSense_ScanSlotTable[slot].RawIndex;
    uint8 widget = CapSense_ScanSlotTable[slot].WidgetNumber;
    uint8 onMask = 0x01u;
    
    if( widget != CapSense_CSHL_NO_WIDGET)
    {
        /* Get On/Off mask */
        onMask <<= (rawIndex % 8);
        
        /* Was on */
        if (CapSense_CSHL_SlotOnMask[(rawIndex)/8] & onMask)
        {
            /* Hysteresis minus */
            if (CapSense_CSHL_SlotSignal[rawIndex] < (CapSense_CSHL_WidgetTable[widget].FingerThreshold - CapSense_CSHL_WidgetTable[widget].Hysteresis))
            {
                CapSense_CSHL_SlotOnMask[(rawIndex)/8] &= ~onMask;
                CapSense_ScanSlotTable[slot].DebounceCount = CapSense_CSHL_WidgetTable[widget].Debounce;
            }
        }
        else    /* Was off */
        {
            /* Hysteresis plus */
            if (CapSense_CSHL_SlotSignal[rawIndex] > (CapSense_CSHL_WidgetTable[widget].FingerThreshold + CapSense_CSHL_WidgetTable[widget].Hysteresis))
            {
                if (CapSense_ScanSlotTable[slot].DebounceCount-- == 0)
                {
                    /* Slot active */
                    CapSense_CSHL_SlotOnMask[rawIndex/8] |= onMask;
                }
            }
            else
            {
                /* Slot inactive - reset Debounce count  */
                CapSense_ScanSlotTable[slot].DebounceCount = CapSense_CSHL_WidgetTable[widget].Debounce;
            }
        }
    }
    
    return (CapSense_CSHL_SlotOnMask[rawIndex/8] & onMask) ? 1 : 0;
}


/*******************************************************************************
* Function Name: CapSense_CSHL_CheckIsAnySlotActive
********************************************************************************
*
* Summary:
*  Compares all slots of the CapSense_CSHL_Signal[ ] array to their finger
*  threshold. Calls CapSense_CSHL_CheckIsAnySlotActive for each slot so
*  the CapSense_CSHL_SlotOnMask[ ] array is up to date after calling this
*  function.
*
* Parameters:
*  slot:  Scan slot number
*
* Return:
*  Returns 1 if any scan slot is active, 0 none of scan slots are active
*
*******************************************************************************/
uint8 CapSense_CSHL_CheckIsAnySlotActive(void)
{
    uint8 i, result = 0;
    
    for(i = 0; i < CapSense_TOTAL_SCANSLOT_COUNT; i++)
    {
        if (CapSense_CSHL_CheckIsSlotActive(i) == CapSense_CSHL_SLOT_ACTIVE)
        {
            result = CapSense_CSHL_SLOT_ACTIVE;
        }
    }
    
    return result;
}



/*******************************************************************************
* Function Name: CapSense_CSHL_GetCentroidPos
********************************************************************************
*
* Summary:
*  Checks the CapSense_CSHL_Signal[ ] array for a centroid within
*  slider specified range. The centroid position is calculated to the resolution
*  specified in the CapSense customizer. The position filters are applied to the
*  result if enabled.
*
* Parameters:
*  widget:  Widget number.
*  For every linear slider widget there are defines in this format:
*  #define CapSense_CSHL_LS__"widget_name"            5
* 
* Return:
*  Returns position value of the slider
*
* Side Effects:
*  If any slider slot is active, the function returns values from zero to
*  the resolution value set in the CapSense customizer. If no sensors
*  are active, the function returns -1. If an error occurs during
*  execution of the centroid/diplexing algorithm, the function returns -1.
*  You can use the _CSHL_ChecklsSlotActive() routine to determine which
*  slider segments are touched, if required.
*
* Note:
*  If noise counts on the slider segments are greater than the noise
*  threshold, this subroutine may generate a false centroid result. The noise
*  threshold should be set carefully (high enough above the noise level) so
*  that noise will not generate a false centroid.
*
*******************************************************************************/
uint16 CapSense_CSHL_GetCentroidPos(uint8 widget)
{
    CapSense_SlSettings *ptr = (CapSense_SlSettings *) CapSense_CSHL_WidgetTable[widget].AdvancedSettings;
    uint8 *diplex = ptr->DiplexTable;
    uint8 offset = CapSense_CSHL_WidgetTable[widget].RawOffset;
    uint8 count = CapSense_CSHL_WidgetTable[widget].ScanSlotCount;
    uint8 curPos = 0;
    uint8 index = 0;
    uint8 curCtrdStartPos = 0xFFu;
    uint8 curCntrdSize = 0;
    uint8 biggestCtrdStartPos = 0;
    uint8 biggestCtrdSize = 0;
    uint8 localMax = 0xFFu;
    uint8 i;
    uint8 posPrev, pos, posNext;
    int32 numerator = 0;
    int32 denominator  = 0;
    uint16 position;
    uint16 basePos;
    
    if (CapSense_CSHL_WidgetTable[widget].Type & CapSense_CSHL_TYPE_LINEAR_SLIDER)
    {
      /* Centoroid Calculations */
      
        while(1)
        {
            if (CapSense_CSHL_SlotSignal[offset+curPos] > 0)
            {        
                if (curCtrdStartPos == 0xFFu)
                {
                    /* Start of Centroid */
                    curCtrdStartPos = index;
                    curCntrdSize++;
                }
                else
                {
                    curCntrdSize++;
                }
            }
            else
            {
                if(curCntrdSize > 0)
                {
                    /* We are in the end of current */
                    if(curCntrdSize > biggestCtrdSize)
                    {
                        biggestCtrdSize = curCntrdSize;
                        biggestCtrdStartPos = curCtrdStartPos;
                        curCntrdSize = 0;
                        curCtrdStartPos = 0xFFu;
                    }
                    else
                    {
                        curCntrdSize = 0;
                        curCtrdStartPos = 0xFFu;
                    }
                    
                }
            }
            
            if(CapSense_CSHL_WidgetTable[widget].Type & CapSense_CSHL_IS_DIPLEX)
            {
                curPos = diplex[index+1];
                if(index == ((count*2)-1))
                {
                    break;
                }
            }
            else
            {
                if(index == (count-1))
                {
                    break;
                }
                curPos++;
            }        
            
            index++;
        }
      
        /* Find the biggest Centroid 
        * if two are the same size, last one wins
        * We are in the end of current */
        if(curCntrdSize >= biggestCtrdSize) 
        {
            biggestCtrdSize = curCntrdSize;
            biggestCtrdStartPos = curCtrdStartPos;
        }
        
        if (biggestCtrdSize >= 2)
        {
            for (i = 0; i < biggestCtrdSize; i++)
            {
                if(CapSense_CSHL_WidgetTable[widget].Type & CapSense_CSHL_IS_DIPLEX)
                {
                    posPrev = diplex[biggestCtrdStartPos + i-1];
                    pos = diplex[biggestCtrdStartPos + i];
                    posNext = diplex[biggestCtrdStartPos + i+1];
                }
                else
                {
                    posPrev = biggestCtrdStartPos + i-1;
                    pos = biggestCtrdStartPos + i;
                    posNext = biggestCtrdStartPos + i+1;
                }
                
                /* Ignore if lower that FingerThreshold */
                if(CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_WidgetTable[widget].FingerThreshold)
                {
                    if (i == 0)
                    {
                        /* First element pos > posNext */
                        if(CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posNext])
                        {
                            /* Find localMax */
                            localMax = i;
                            break;
                        }
                        else
                        {
                            if(CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posNext])
                            {
                                /* Compare BaselinesLow (i+1) and (i) */
                                if(CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posNext])
                                {
                                    localMax = i;
                                    break;
                                }
                            }
                        }
                    }
                    else if (i == (biggestCtrdSize-1))
                    {
                        /* Last element posNext > pos */
                        if(CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posPrev])
                        {
                            /* Find localMax */
                            localMax = i;
                            break;
                        }
                        else
                        {
                            if(CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posPrev])
                            {
                                /* Compare BaselinesLow (i+1) and (i) */
                                if(CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posPrev])
                                {
                                    localMax = i;
                                    break;
                                }
                            }    
                        }
                        
                    }
                    else
                    {
                        /* point (i+1) > (i) and (i+1) > (i+2) */
                        if((CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posNext]) && (CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posPrev]))
                        {
                            localMax = i;
                            break;
                        }
                        else
                        {
                            /* (i+1) == (i), compare BaselinesLow */
                            if(CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posNext])
                            {
                                /* Compare BaselinesLow (i+1) and (i), if lower go next */
                                if(CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posNext])
                                {
                                    if(CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posPrev])
                                    {
                                        localMax = i;
                                        break;
                                    }
                                    else
                                    {
                                        /* (i+1) == (i+2), compare BaselinesLow */
                                        if ((CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posPrev]) && (CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posPrev]))
                                        {
                                            localMax = i;
                                            break;
                                        }
                                    }
                                }
                            }
                            if(CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posPrev])
                            {
                                /* Compare BaselinesLow (i+1) and (i), if lower go next */
                                if (CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posPrev])
                                {
                                    if (CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_SlotSignal[offset + posNext])
                                    {
                                        localMax = i;
                                        break;
                                    }
                                    else
                                    {
                                        /* (i+1) == (i+2), compare BaselinesLow */
                                        if((CapSense_CSHL_SlotSignal[offset + pos] == CapSense_CSHL_SlotSignal[offset + posNext]) && (CapSense_CSHL_SlotBaselineLow[offset + pos] < CapSense_CSHL_SlotBaselineLow[offset + posNext]))
                                        {
                                            localMax = i;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else if ((!(CapSense_CSHL_WidgetTable[widget].Type & CapSense_CSHL_IS_DIPLEX)) && (biggestCtrdSize == 1))
        {
            pos = biggestCtrdStartPos;
            /* Ignore if lower that FingerThreshold */
            if(CapSense_CSHL_SlotSignal[offset + pos] > CapSense_CSHL_WidgetTable[widget].FingerThreshold)
            {
                localMax = 0;
            }
            else
            {
                localMax = 0xFF;
            }
        }
        else
        {
            localMax = 0xFF;
        }
        
        if (localMax < 0xFFu)
        {
            /* Find positions of localMax and near it */
            if(CapSense_CSHL_WidgetTable[widget].Type & CapSense_CSHL_IS_DIPLEX)
            {
                posPrev = diplex[biggestCtrdStartPos + localMax-1];
                pos = diplex[biggestCtrdStartPos + localMax];
                posNext = diplex[biggestCtrdStartPos + localMax+1];
            }
            else
            {
                posPrev = biggestCtrdStartPos + localMax-1;
                pos = biggestCtrdStartPos + localMax;
                posNext = biggestCtrdStartPos + localMax+1;
            }
            
            if (biggestCtrdSize >= 2)        /* The Biggest Centriod Size is grater that 2, need interpolation */
            {    
                /* Calculate Sum(Si) */
                if (localMax == 0)
                {
                    /* Start of Centroid */
                    numerator = ((int32)CapSense_CSHL_SlotSignal[offset + posNext]);
                    denominator  =  ((int32) CapSense_CSHL_SlotSignal[offset + pos]) + ((int32) CapSense_CSHL_SlotSignal[offset + posNext]);
                }
                else
                {
                    if (localMax == (biggestCtrdSize-1))
                    {
                        /* End of Centroid */
                        numerator = ((int32) CapSense_CSHL_SlotSignal[offset + posPrev]) * (-1);
                        denominator  = ((int32) CapSense_CSHL_SlotSignal[offset + pos]) + ((int32) CapSense_CSHL_SlotSignal[offset + posPrev]);
                    }
                    else
                    {
                        /* Not first Not last */
                        numerator = ((int32) CapSense_CSHL_SlotSignal[offset + posNext]) - ((int32) CapSense_CSHL_SlotSignal[offset + posPrev]);
                        denominator  = ((int32) CapSense_CSHL_SlotSignal[offset + posPrev]) + ((int32) CapSense_CSHL_SlotSignal[offset + pos]) + ((int32) CapSense_CSHL_SlotSignal[offset + posNext]);
                        
                    }
                }
                
                numerator <<= 8;
                /* Div (numerator/denominator) * Resolution */
                denominator  = ((numerator/denominator) + (((uint16) (biggestCtrdStartPos + localMax) )<< 8)) *  ptr->Resolution;
                
                if(denominator < 0)
                {
                    denominator = denominator * (-1);
                }
                
                position = HI16(denominator);
            }
            else        /* The Biggest Centriod Size 1, NOT interpolation needed */
            {
                denominator = (pos * ptr->Resolution) + 0x7Fu;
                position = HI8(denominator);
            }
            
            /* Filtering */
            
            if (ptr->FirstTime == 0)        /* Initialize the filters */
            {
                /* Median filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_MEDIAN_FILTER)
                {
                    ptr->Pos2Median = position;
                    ptr->Pos1Median = position;
                }
                
                /* Averaging filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_AVERAGING_FILTER)
                {
                    ptr->Pos2Averaging = position;
                    ptr->Pos1Averaging = position;
                }
                /* IIR filter first time initialization */
                if((CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_IIR_FILTER_0) ||
                    (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_IIR_FILTER_1))
                {
                    ptr->PosIIR = position;
                }
                
                /* Jitter filter first time initialization */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_JITTER_FILTER)
                {
                    ptr->PosJitter = position;
                }
                ptr->FirstTime = 1;
            }
            else            /* Do the filtering */
            {
                /* Median filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_MEDIAN_FILTER)
                {
                    basePos = position;
                    position = CapSense_CSHL_MedianFilter(position, ptr->Pos1Median, ptr->Pos2Median);
                    ptr->Pos2Median = ptr->Pos1Median;
                    ptr->Pos1Median = basePos;
                }
                
                /* Averaging filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_AVERAGING_FILTER)
                {
                    basePos = position;
                    position = CapSense_CSHL_AveragingFilter(position, ptr->Pos1Averaging, ptr->Pos2Averaging);
                    ptr->Pos2Averaging = ptr->Pos1Averaging;
                    ptr->Pos1Averaging= basePos;
                }
                /* IIR filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_IIR_FILTER_0)
                {
                    basePos = position;
                    position = CapSense_CSHL_IIRFilter(position, ptr->PosIIR,CapSense_CSHL_IIR_FILTER_0);
                    ptr->PosIIR = basePos;
                }
                else if (CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_IIR_FILTER_1)
                {
                    basePos = position;
                    position = CapSense_CSHL_IIRFilter(position, ptr->PosIIR,CapSense_CSHL_IIR_FILTER_1);
                    ptr->PosIIR = basePos;
                }
                
                /* Jitter filter */
                if(CapSense_CSHL_WidgetTable[widget].Filters & CapSense_CSHL_POS_JITTER_FILTER)
                {
                    basePos = position;
                    position = CapSense_CSHL_JitterFilter(position, ptr->PosJitter);
                    ptr->PosJitter = basePos;
                }
            }
        }
        else
        {
            /* Local max doesn't find*/
            position = 0x00FFu;
            ptr->FirstTime = 0u;
        }
    }
    else
    {
        /* This Widget isn't Linear Slider Widget */
        position = 0x00FFu;
    }
    
    return position;
}


/* [] END OF FILE */
