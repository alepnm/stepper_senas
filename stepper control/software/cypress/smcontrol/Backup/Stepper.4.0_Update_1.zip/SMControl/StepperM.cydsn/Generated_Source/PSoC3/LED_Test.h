/*******************************************************************************
* File Name: LED_Test.h  
* Version 1.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright (2008), Cypress Semiconductor Corporation.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is 
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable 
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress Source Code and derivative works for the sole purpose of creating 
* custom software in support of licensee product to be used only in conjunction 
* with a Cypress integrated circuit as specified in the applicable agreement. 
* Any reproduction, modification, translation, compilation, or representation of 
* this software except as specified above is prohibited without the express 
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. Use may be 
* limited by and subject to the applicable Cypress software license agreement. 
*******************************************************************************/

#if !defined(CY_DIGITAL_PORT_LED_Test_H) /* Digital Port LED_Test_H */
#define CY_DIGITAL_PORT_LED_Test_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    LED_Test_Write(uint8 prtValue);
void    LED_Test_WriteDM(uint8 mode, uint8 mask);
uint8   LED_Test_ReadDR(void);
uint8   LED_Test_Read(void);
uint8   LED_Test_ClearInterrupt(void);
uint8   LED_Test_GetLastInterrupt(void);

/* 
 * Macros below provide access to write the DR and read the PS 
 * using the same nomenclature as above
 */
#define LED_Test_WriteDR(prtValue)  LED_Test_Write(prtValue) 
#define LED_Test_ReadPS()           LED_Test_Read()


/* Drive Mode Macros */
#define LED_Test_0_ReadDM()         ((LED_Test_PIN_0 & LED_Test_PC_DM_MASK) >> LED_Test_PC_DM_SHIFT)


/***************************************
*           API Constants        
***************************************/

/* Drive Mode Constants for WriteDM() */
#define LED_Test_BIT_SET            0xFFu
#define LED_Test_BIT_CLEAR          0x00u
#define LED_Test_MODE_MASK          0x07u
#define LED_Test_MODE_BIT_0         0x01u
#define LED_Test_MODE_BIT_1         0x02u
#define LED_Test_MODE_BIT_2         0x04u
#define LED_Test_PC_DM_MASK         0x0Eu
#define LED_Test_PC_DM_SHIFT        0x01u

/* Drive Modes */
#define LED_Test_HI_Z               0x01u
#define LED_Test_RES_PULL_UP        0x02u
#define LED_Test_RES_PULL_DOWN      0x03u
#define LED_Test_OPEN_DRAIN_LO      0x04u
#define LED_Test_OPEN_DRAIN_HI      0x05u
#define LED_Test_CMOS_OUT           0x06u
#define LED_Test_RES_PULL_UPDOWN    0x07u

/* Digital Port Constants */
#define LED_Test_MASK               LED_Test__MASK
#define LED_Test_SHIFT              LED_Test__SHIFT
#define LED_Test_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LED_Test_PS                     (* (reg8 *) LED_Test__PS)
/* Data Register */
#define LED_Test_DR                     (* (reg8 *) LED_Test__DR)
/* Port Number */
#define LED_Test_PRT_NUM                (* (reg8 *) LED_Test__PRT) 
/* Connect to Analog Globals */                                                  
#define LED_Test_AG                     (* (reg8 *) LED_Test__AG)                       
/* Analog MUX bux enable */
#define LED_Test_AMUX                   (* (reg8 *) LED_Test__AMUX) 
/* Bidirectional Enable */                                                        
#define LED_Test_BIE                    (* (reg8 *) LED_Test__BIE)
/* Bit-mask for Aliased Register Access */
#define LED_Test_BIT_MASK               (* (reg8 *) LED_Test__BIT_MASK)
/* Bypass Enable */
#define LED_Test_BYP                    (* (reg8 *) LED_Test__BYP)
/* Port wide control signals */                                                   
#define LED_Test_CTL                    (* (reg8 *) LED_Test__CTL)
/* Drive Modes */
#define LED_Test_DM0                    (* (reg8 *) LED_Test__DM0) 
#define LED_Test_DM1                    (* (reg8 *) LED_Test__DM1)
#define LED_Test_DM2                    (* (reg8 *) LED_Test__DM2) 
/* Input Buffer Disable Override */
#define LED_Test_INP_DIS                (* (reg8 *) LED_Test__INP_DIS)
/* LCD Common or Segment Drive */
#define LED_Test_LCD_COM_SEG            (* (reg8 *) LED_Test__LCD_COM_SEG)
/* Enable Segment LCD */
#define LED_Test_LCD_EN                 (* (reg8 *) LED_Test__LCD_EN)
/* Slew Rate Control */
#define LED_Test_SLW                    (* (reg8 *) LED_Test__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LED_Test_PRTDSI__CAPS_SEL       (* (reg8 *) LED_Test__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LED_Test_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LED_Test__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LED_Test_PRTDSI__OE_SEL0        (* (reg8 *) LED_Test__PRTDSI__OE_SEL0) 
#define LED_Test_PRTDSI__OE_SEL1        (* (reg8 *) LED_Test__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LED_Test_PRTDSI__OUT_SEL0       (* (reg8 *) LED_Test__PRTDSI__OUT_SEL0) 
#define LED_Test_PRTDSI__OUT_SEL1       (* (reg8 *) LED_Test__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LED_Test_PRTDSI__SYNC_OUT       (* (reg8 *) LED_Test__PRTDSI__SYNC_OUT) 


#if defined(LED_Test__INTSTAT)  /* Interrupt Registers */

    #define LED_Test_INTSTAT                (* (reg8 *) LED_Test__INTSTAT)
    #define LED_Test_SNAP                   (* (reg8 *) LED_Test__SNAP)

#endif /* Interrupt Registers */

/* Pin Registers */
#define LED_Test_PIN_0                       (* (reg8 *) LED_Test__0__PC)


#endif /* End Digital Port LED_Test_H */


/* [] END OF FILE */
