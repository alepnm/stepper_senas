/*******************************************************************************
* File Name: CapSense.h
* Version 1.30
*
* Description:
*  This file provides constants and parameter values for the CapSense
*  Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CapSense_H)
#define CY_CAPSENSE_CapSense_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cydevice_trm.h"
#include "CyLib.h"

#include "CapSense_sbCSD_cRAW.h"
#include "CapSense_sbCSD_cComp.h"
#include "CapSense_sbCSD_cAMux.h"
#include "CapSense_sbCSD_cPWM.h"
#include "CapSense_sUDBSpeed.h"


/***************************************
*       Types definition
***************************************/

/*       Scan Slot struct             */
typedef struct _CapSense_Slot
{
    uint8 RawIndex;         /* Entry in SlotResult */
    uint8 IndexOffset;      /* Offset in IndezTable */
    uint8 SnsCnt;           /* Number of Sensors in currect Slot */
    uint8 WidgetNumber;     /* Number of Widget this slot belongs */
    uint8 DebounceCount;    /* Helps to define if slot Active */
} CapSense_Slot;

/*        Settings for CSD         */
typedef struct _CapSense_CSD_Settings
{
    uint8 IdacRange;            /* 1-3 range exist, multiplier for IDAC */
    uint8 IdacSettings;         /* IDAC settings for measurament */
    uint8 Resolution;           /* PWM Resolution */
    uint8 ScanSpeed;            /* Speed of scanning  DIG_CLK */
    uint8 DisableState;         /* Disable state of ScanSlot */

} CapSense_CSD_Settings;

/*       Port Shift struct            */
typedef struct _CapSense_PortShift
{
    uint8 port;
    uint8 shift;
} CapSense_PortShift;


/***************************************
*        Function Prototypes
***************************************/

void CapSense_Start(void);
void CapSense_Stop(void);
void CapSense_ScanSlot(uint8 slot);
void CapSense_ScanAllSlots(void);

void CapSense_CSD_Start(void);
void CapSense_CSD_Stop(void);
void CapSense_CSD_ScanSlot(uint8 slot);
void CapSense_CSD_ScanAllSlots(void);
void CapSense_CSD_SetSlotSettings(uint8 slot);
void CapSense_CSD_ClearSlots(void);
void CapSense_CSD_EnableSensor(uint8 sensor);
void CapSense_CSD_DisableSensor(uint8 sensor, uint8 state);
uint16 CapSense_CSD_ReadSlot(uint8 slot);
/* Interrupt handler */
CY_ISR_PROTO(CapSense_ISR);

extern uint8 CapSense_status;


/***************************************
*           API Constants
***************************************/

#define CapSense_TOTAL_SENSOR_COUNT              4
#define CapSense_TOTAL_SCANSLOT_COUNT            4
#define CapSense_TOTAL_GENERIC_SCANSLOT_COUNT    0

/* Define Sensors */
#define CapSense_SENSOR_BTN_B1    0
#define CapSense_SENSOR_BTN_B2    1
#define CapSense_SENSOR_LS_S1_E0    2
#define CapSense_SENSOR_LS_S1_E1    3

/* Define ScanSlots */
#define CapSense_SCANSLOT_BTN_B1    0
#define CapSense_SCANSLOT_BTN_B2    1
#define CapSense_SCANSLOT_LS_S1_E0    2
#define CapSense_SCANSLOT_LS_S1_E1    3

/* Chanels of CapSense */
#define CapSense_CMOD_CHANNEL          4
#define CapSense_CMP_VP_CHANNEL        5
#define CapSense_IDAC_CHANNEL          6

#define CapSense_CSD_METHOD
#define CapSense_VREF_VDAC_VALUE        64

/* Scan Speed Type */
#define CapSense_SCAN_SPEED_ULTRA_FAST      0x01u
#define CapSense_SCAN_SPEED_FAST            0x03u
#define CapSense_SCAN_SPEED_NORMAL          0x07u
#define CapSense_SCAN_SPEED_SLOW            0x0Fu

/* Idac SetRange */
#define CapSense_IDAC_RANGE_MASK            0x0Cu
#define CapSense_IDAC_RANGE_32uA            0x00u
#define CapSense_IDAC_RANGE_255uA           0x04u
#define CapSense_IDAC_RANGE_2mA             0x08u

/* PWM Resolution */
#define CapSense_PWM_WINDOW_SHIFT           8u
#define CapSense_PWM_RESOLUTION_8_BITS      0x00u
#define CapSense_PWM_RESOLUTION_9_BITS      0x01u
#define CapSense_PWM_RESOLUTION_10_BITS     0x03u
#define CapSense_PWM_RESOLUTION_11_BITS     0x07u
#define CapSense_PWM_RESOLUTION_12_BITS     0x0Fu
#define CapSense_PWM_RESOLUTION_13_BITS     0x1Fu
#define CapSense_PWM_RESOLUTION_14_BITS     0x3Fu
#define CapSense_PWM_RESOLUTION_15_BITS     0x7Fu
#define CapSense_PWM_RESOLUTION_16_BITS     0xFFu

/* Enable csBuffer */
#define CapSense_CSBUF_BOOST_ENABLE         0x02u
#define CapSense_CSBUF_ENABLE               0x01u

/* Starts CapSensing */
#define CapSense_START_CAPSENSING           0x01u

/* Resets PWM and Raw Counter */
#define CapSense_RESET_PWM_CNTR             0x02u

/* Overfow of counter while CSA */
#define CapSense_RAW_OVERFLOW               0x04u

/* Turn off IDAC  */
#define CapSense_TURN_OFF_IDAC              0x00u

/* Rbleed */
#define CapSense_MAX_RB_NUMBER      3
#define CapSense_RBLEED1            0
#define CapSense_RBLEED2            1
#define CapSense_RBLEED3            2

/* Diasable States */
#define CapSense_DISABLE_STATE_GND          0
#define CapSense_DISABLE_STATE_HIGHZ        1
#define CapSense_DISABLE_STATE_SHIELD       2
#define CapSense_ALONE_SENSOR               1


/***************************************
*             Registers
***************************************/

/* Control Register */
#define CapSense_CONTROL             (* (reg8 *) CapSense_sbCSD_cControl_ctrl_reg__CONTROL_REG )

/* csBuffer */
#define CapSense_CAPS_CFG0           (* (reg8 *) CapSense_sbCSD_cBuf__CFG0 )
#define CapSense_CAPS_CFG1           (* (reg8 *) CapSense_sbCSD_cBuf__CFG1 )
#define CapSense_CSBUF_PWRMGR        (* (reg8 *) CapSense_sbCSD_cBuf__PM_ACT_CFG )
#define CapSense_CSBUF_PWR_ENABLE    CapSense_sbCSD_cBuf__PM_ACT_MSK

/* csIdac */
#define CapSense_IDAC_CR0        (* (reg8 *) CapSense_sbCSD_cIDAC__CR0 )
#define CapSense_IDAC_CR1        (* (reg8 *) CapSense_sbCSD_cIDAC__CR1 )
#define CapSense_IDAC_DATA       (* (reg8 *) CapSense_sbCSD_cIDAC__D )
#define CapSense_IDAC_STROBE     (* (reg8 *) CapSense_sbCSD_cIDAC__STROBE )
#define CapSense_IDAC_TR         (* (reg8 *) CapSense_sbCSD_cIDAC__TR )
#define CapSense_IDAC_PWRMGR     (* (reg8 *) CapSense_sbCSD_cIDAC__PM_ACT_CFG )

/* TODO: Remove this line after changes to DAC */
#define CapSense_IDAC_FIRST_SILICON

/* PM_ACT_CFG (Active Power Mode CFG Register) */ 
#if !defined(CapSense_IDAC_FIRST_SILICON)
    #define CapSense_IDAC_ACT_PWR_EN    CapSense_sbCSD_cIDAC__PM_ACT_MSK
#else
    #define CapSense_IDAC_ACT_PWR_EN    0xFFu /* TODO: Work around for incorrect power enable */
#endif

/* DAC offset address from CYDEV_FLSHID_BASE */
#define CapSense_DAC0_OFFSET    0x00011Cu
#define CapSense_DAC1_OFFSET    0x000112u
#define CapSense_DAC2_OFFSET    0x000124u
#define CapSense_DAC3_OFFSET    0x000134u

#define CapSense_DAC_POS  (CapSense_sbCSD_cIDAC__D - CYDEV_ANAIF_WRK_DAC0_BASE)

#if(CapSense_DAC_POS == 0)
    #define CapSense_DAC_TRIM_BASE    CYDEV_FLSHID_BASE + CapSense_DAC0_OFFSET
#endif

#if(CapSense_DAC_POS == 1)
    #define CapSense_DAC_TRIM_BASE    CYDEV_FLSHID_BASE + CapSense_DAC1_OFFSET
#endif

#if(CapSense_DAC_POS == 2)
    #define CapSense_DAC_TRIM_BASE    CYDEV_FLSHID_BASE + CapSense_DAC2_OFFSET
#endif

#if(CapSense_DAC_POS == 3)
    #define CapSense_DAC_TRIM_BASE    CYDEV_FLSHID_BASE + CapSense_DAC3_OFFSET
#endif

/* ISR Number and Priority to work with CyLib functions */
#define CapSense_ISR_NUMBER        CapSense_sbCSD_cISR__INTC_NUMBER
#define CapSense_ISR_PRIORITY      CapSense_sbCSD_cISR__INTC_PRIOR_NUM

#if(CYDEV_CHIP_DIE_EXPECT == CYDEV_CHIP_DIE_LEOPARD)
    #if((CYDEV_CHIP_REV_EXPECT <= CYDEV_CHIP_REV_LEOPARD_ES2) && (CapSense_sbCSD_cISR__ES2_PATCH))
        #include <intrins.h>
        #define CapSense_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif
#endif

/* Register to work with port */
#define CapSense_BASE_PRT_PC            ( (reg8 *) CYDEV_IO_PC_PRT0_BASE )
#if((CYDEV_CHIP_DIE_EXPECT == CYDEV_CHIP_DIE_LEOPARD) && (CYDEV_CHIP_REV_EXPECT == CYDEV_CHIP_REV_LEOPARD_ES1))
    #define CapSense_BASE_PRTDSI_CAPS   ( (reg8 *) CYREG_PRTDSI_PRT0_CAPS_SEL )
#else
    #define CapSense_BASE_PRTDSI_CAPS   ( (reg8 *) CYREG_PRT0_CAPS_SEL )
#endif


/***************************************
*       Register Constants
***************************************/

/* PC and CAPS_SEL Registers Offset */
#define CapSense_PRT_PC_OFFSET      CYDEV_IO_PC_PRT0_SIZE
#define CapSense_PRTDSI_OFFSET      (CYDEV_PRTDSI_PRT0_SIZE+1)

/* Masks of PTR PC Register */
#define CapSense_DR_MASK            0x01
#define CapSense_DM0_MASK           0x02
#define CapSense_DM1_MASK           0x04
#define CapSense_DM2_MASK           0x08
#define CapSense_BYP_MASK           0x80

#define CapSense_PRT_PC_GND         CapSense_DM2_MASK
#define CapSense_PRT_PC_HIGHZ       (CapSense_DM2_MASK |CapSense_DR_MASK)
#define CapSense_PRT_PC_SHIELD      (CapSense_DM2_MASK | CapSense_DM1_MASK | CapSense_BYP_MASK)

/* CR0 Idac Control Register 0 definitions */

/* Bit Field  DAC_MODE */
#define CapSense_IDAC_MODE_MASK         0x10u
#define CapSense_IDAC_MODE_V            0x00u
#define CapSense_IDAC_MODE_I            0x10u

/* CR1 Idac Control Register 1 definitions */

/* Bit Field  DAC_I_DIR */
/* Register control of current direction */
#define CapSense_IDAC_IDIR_MASK         0x04u
#define CapSense_IDAC_IDIR_SINK         0x04u
#define CapSense_IDAC_IDIR_SRC          0x00u

/* Bit Field  DAC_MX_IOFF_SRC */
/* Selects source of IOFF control, reg or UDB */
#define CapSense_IDAC_IDIR_CTL_MASK     0x02u
#define CapSense_IDAC_IDIR_CTL_REG      0x00u
#define CapSense_IDAC_IDIR_CTL_UDB      0x02u

#endif /* End CY_CAPSENSE_CapSense_H */


 /* [] END OF FILE */
