/*******************************************************************************
* File Name: CapSense_sbCSD_cAMux.c
* Version 1.30
*
*  Description:
*    This file contains all functions required for the analog multiplexer
*    AMux User Module.
*
*   Note:
*
*******************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/



#include "cytypes.h"
#include "CapSense_sbCSD_cAMux.h"
#include "cyfitter_cfg.h"

uint8 CapSense_sbCSD_cAMux_lastChannel = CapSense_sbCSD_cAMux_NULL_CHANNEL;

/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_Start
********************************************************************************
* Summary:
*  This function resets all connections, to disconnected.
*
* Parameters:
*  (void)
*
* Return:
*  (void)
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_Start(void)
{
   CapSense_sbCSD_cAMux_DisconnectAll();
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_Stop
********************************************************************************
* Summary:
*  This function disconnects all connections.
*
* Parameters:
*  (void)
*
* Return:
*  (void)
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_Stop(void)
{
   CapSense_sbCSD_cAMux_DisconnectAll();
}



/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_Select
********************************************************************************
* Summary:
*  This functions first disconnects all channels then connects the selected
*  channel "channel".
*
* Parameters:
*  channel:  (uint8) Selects the channel in which to perform the operation.
*
* Return:
*  (void) Description of return value, if there is a return value.
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_Select(uint8 channel)
{
   CapSense_sbCSD_cAMux_DisconnectAll();        /* Disconnect all previous connections */
   CapSense_sbCSD_cAMux_Connect(channel);       /* Make the given selection */
   CapSense_sbCSD_cAMux_lastChannel = channel;  /* Update last channel */
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_FastSelect
********************************************************************************
* Summary:
*  This functions first disconnects just the last channel then connects the
*  given channel.
*
* Parameters:
*  channel:  (uint8) Selects the channel in which to connect.
*
* Return:
*  None
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_FastSelect(uint8 channel)
{
   /* Disconnect the last valid channel */
   if( CapSense_sbCSD_cAMux_lastChannel != CapSense_sbCSD_cAMux_NULL_CHANNEL)   /* Update last channel */
   {
      CapSense_sbCSD_cAMux_Disconnect(CapSense_sbCSD_cAMux_lastChannel);
   }

   /* Make the new channel connection */
   CapSense_sbCSD_cAMux_Connect(channel);
   CapSense_sbCSD_cAMux_lastChannel = channel;   /* Update last channel */
}

#if(CapSense_sbCSD_cAMux_MUXTYPE == CapSense_sbCSD_cAMux_MUX_DIFF)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_Connect
********************************************************************************
* Summary:
*  This function connects the given channel, but does not affect any other
*  previous connection.
*
* Parameters:
*  channel:  (uint8) Selects the channel in which to connect.
*
* Return:
*  (void)
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_Connect(uint8 channel)
{
   CapSense_sbCSD_cAMux_CYAMUXSIDE_A_Set(channel);
   CapSense_sbCSD_cAMux_CYAMUXSIDE_B_Set(channel);
}
#endif

#if(CapSense_sbCSD_cAMux_MUXTYPE == CapSense_sbCSD_cAMux_MUX_DIFF)
/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_Disconnect
********************************************************************************
* Summary:
*  This function disconnects the given channel from the common or output.  It
*  does not affect any other connection.
*
* Parameters:
*  channel:  (uint8) Selects the channel in which to disconnect.
*
* Return:
*  (void)
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_Disconnect(uint8 channel)
{
   CapSense_sbCSD_cAMux_CYAMUXSIDE_A_Unset(channel);
   CapSense_sbCSD_cAMux_CYAMUXSIDE_B_Unset(channel);
}
#endif

/*******************************************************************************
* Function Name: CapSense_sbCSD_cAMux_DisconnectAll
********************************************************************************
* Summary:
*  This function disconnects all channels.
*
* Parameters:
*  (void)
*
* Return:
*  (void)
*
* Theory:
*
* Side Effects:
*
*******************************************************************************/
void CapSense_sbCSD_cAMux_DisconnectAll(void)
{
   uint8 chan;

   #if(CapSense_sbCSD_cAMux_MUXTYPE == CapSense_sbCSD_cAMux_MUX_SINGLE)
      for(chan = 0; chan < CapSense_sbCSD_cAMux_CHANNELS ; chan++)
      {
         CapSense_sbCSD_cAMux_Unset(chan);
      }
   #else
      for(chan = 0; chan < CapSense_sbCSD_cAMux_CHANNELS ; chan++)
      {
         CapSense_sbCSD_cAMux_CYAMUXSIDE_A_Unset(chan);
         CapSense_sbCSD_cAMux_CYAMUXSIDE_B_Unset(chan);
      }
   #endif
}


/* [] END OF FILE */
