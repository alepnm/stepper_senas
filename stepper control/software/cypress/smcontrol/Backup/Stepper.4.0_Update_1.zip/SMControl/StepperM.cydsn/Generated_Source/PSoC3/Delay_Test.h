/*******************************************************************************
* File Name: Delay_Test.h  
* Version 1.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright (2008), Cypress Semiconductor Corporation.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is 
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable 
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress Source Code and derivative works for the sole purpose of creating 
* custom software in support of licensee product to be used only in conjunction 
* with a Cypress integrated circuit as specified in the applicable agreement. 
* Any reproduction, modification, translation, compilation, or representation of 
* this software except as specified above is prohibited without the express 
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. Use may be 
* limited by and subject to the applicable Cypress software license agreement. 
*******************************************************************************/

#if !defined(CY_DIGITAL_PORT_Delay_Test_H) /* Digital Port Delay_Test_H */
#define CY_DIGITAL_PORT_Delay_Test_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Delay_Test_Write(uint8 prtValue);
void    Delay_Test_WriteDM(uint8 mode, uint8 mask);
uint8   Delay_Test_ReadDR(void);
uint8   Delay_Test_Read(void);
uint8   Delay_Test_ClearInterrupt(void);
uint8   Delay_Test_GetLastInterrupt(void);

/* 
 * Macros below provide access to write the DR and read the PS 
 * using the same nomenclature as above
 */
#define Delay_Test_WriteDR(prtValue)  Delay_Test_Write(prtValue) 
#define Delay_Test_ReadPS()           Delay_Test_Read()


/* Drive Mode Macros */
#define Delay_Test_0_ReadDM()         ((Delay_Test_PIN_0 & Delay_Test_PC_DM_MASK) >> Delay_Test_PC_DM_SHIFT)


/***************************************
*           API Constants        
***************************************/

/* Drive Mode Constants for WriteDM() */
#define Delay_Test_BIT_SET            0xFFu
#define Delay_Test_BIT_CLEAR          0x00u
#define Delay_Test_MODE_MASK          0x07u
#define Delay_Test_MODE_BIT_0         0x01u
#define Delay_Test_MODE_BIT_1         0x02u
#define Delay_Test_MODE_BIT_2         0x04u
#define Delay_Test_PC_DM_MASK         0x0Eu
#define Delay_Test_PC_DM_SHIFT        0x01u

/* Drive Modes */
#define Delay_Test_HI_Z               0x01u
#define Delay_Test_RES_PULL_UP        0x02u
#define Delay_Test_RES_PULL_DOWN      0x03u
#define Delay_Test_OPEN_DRAIN_LO      0x04u
#define Delay_Test_OPEN_DRAIN_HI      0x05u
#define Delay_Test_CMOS_OUT           0x06u
#define Delay_Test_RES_PULL_UPDOWN    0x07u

/* Digital Port Constants */
#define Delay_Test_MASK               Delay_Test__MASK
#define Delay_Test_SHIFT              Delay_Test__SHIFT
#define Delay_Test_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Delay_Test_PS                     (* (reg8 *) Delay_Test__PS)
/* Data Register */
#define Delay_Test_DR                     (* (reg8 *) Delay_Test__DR)
/* Port Number */
#define Delay_Test_PRT_NUM                (* (reg8 *) Delay_Test__PRT) 
/* Connect to Analog Globals */                                                  
#define Delay_Test_AG                     (* (reg8 *) Delay_Test__AG)                       
/* Analog MUX bux enable */
#define Delay_Test_AMUX                   (* (reg8 *) Delay_Test__AMUX) 
/* Bidirectional Enable */                                                        
#define Delay_Test_BIE                    (* (reg8 *) Delay_Test__BIE)
/* Bit-mask for Aliased Register Access */
#define Delay_Test_BIT_MASK               (* (reg8 *) Delay_Test__BIT_MASK)
/* Bypass Enable */
#define Delay_Test_BYP                    (* (reg8 *) Delay_Test__BYP)
/* Port wide control signals */                                                   
#define Delay_Test_CTL                    (* (reg8 *) Delay_Test__CTL)
/* Drive Modes */
#define Delay_Test_DM0                    (* (reg8 *) Delay_Test__DM0) 
#define Delay_Test_DM1                    (* (reg8 *) Delay_Test__DM1)
#define Delay_Test_DM2                    (* (reg8 *) Delay_Test__DM2) 
/* Input Buffer Disable Override */
#define Delay_Test_INP_DIS                (* (reg8 *) Delay_Test__INP_DIS)
/* LCD Common or Segment Drive */
#define Delay_Test_LCD_COM_SEG            (* (reg8 *) Delay_Test__LCD_COM_SEG)
/* Enable Segment LCD */
#define Delay_Test_LCD_EN                 (* (reg8 *) Delay_Test__LCD_EN)
/* Slew Rate Control */
#define Delay_Test_SLW                    (* (reg8 *) Delay_Test__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Delay_Test_PRTDSI__CAPS_SEL       (* (reg8 *) Delay_Test__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Delay_Test_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Delay_Test__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Delay_Test_PRTDSI__OE_SEL0        (* (reg8 *) Delay_Test__PRTDSI__OE_SEL0) 
#define Delay_Test_PRTDSI__OE_SEL1        (* (reg8 *) Delay_Test__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Delay_Test_PRTDSI__OUT_SEL0       (* (reg8 *) Delay_Test__PRTDSI__OUT_SEL0) 
#define Delay_Test_PRTDSI__OUT_SEL1       (* (reg8 *) Delay_Test__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Delay_Test_PRTDSI__SYNC_OUT       (* (reg8 *) Delay_Test__PRTDSI__SYNC_OUT) 


#if defined(Delay_Test__INTSTAT)  /* Interrupt Registers */

    #define Delay_Test_INTSTAT                (* (reg8 *) Delay_Test__INTSTAT)
    #define Delay_Test_SNAP                   (* (reg8 *) Delay_Test__SNAP)

#endif /* Interrupt Registers */

/* Pin Registers */
#define Delay_Test_PIN_0                       (* (reg8 *) Delay_Test__0__PC)


#endif /* End Digital Port Delay_Test_H */


/* [] END OF FILE */
