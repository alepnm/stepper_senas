/*******************************************************************************
* File Name: CapSense_sbCSD_cISR_intc.c  
* Version 1.0
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/


#include <CYDEVICE.H>
#include <CapSense_sbCSD_cISR.H>


/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START CapSense_sbCSD_cISR_intc` */

/* `#END` */


/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_Start
********************************************************************************
* Summary:
*  Set up the interrupt and enable it.
*
* Parameters:  
*   void.
*
*
* Return:
*   void.
*
*******************************************************************************/
void CapSense_sbCSD_cISR_Start(void)
{
    /* For all we know the interrupt is active. */
    CapSense_sbCSD_cISR_Disable();

    /* Set the ISR to point to the CapSense_sbCSD_cISR Interrupt. */
    CapSense_sbCSD_cISR_SetVector(CapSense_sbCSD_cISR_Interrupt);

    /* Set the priority. */
    CapSense_sbCSD_cISR_SetPriority(CapSense_sbCSD_cISR_INTC_PRIOR_NUMBER);

    /* Enable it. */
    CapSense_sbCSD_cISR_Enable();
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_Stop
********************************************************************************
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*
*
* Return:
*   void.
*
*******************************************************************************/
void CapSense_sbCSD_cISR_Stop(void)
{
    /* Disable this interrupt. */
    CapSense_sbCSD_cISR_Disable();

    /* Set the ISR to point to the passive one. */
//    CapSense_sbCSD_cISR_SetVector(CyDefaultInterrupt);
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_Interrupt
********************************************************************************
* Summary:
*   The default Interrupt Service Routine for CapSense_sbCSD_cISR.
*
*   Add custom code between the coments to keep the next version of this file
*   from over writting your code.
*
*
*
* Parameters:  
*
*
* Return:
*   void.
*
*******************************************************************************/
CY_ISR(CapSense_sbCSD_cISR_Interrupt)
{
    /*  Place your Interrupt code here. */
    /* `#START CapSense_sbCSD_cISR_Interrupt` */

    /* `#END` */
}


/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_SetVector
********************************************************************************
* Summary:
*   Change the ISR vector for the Interrupt.
*
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_SetVector(cyisraddress address)
{
    CY_SET_REG16(CapSense_sbCSD_cISR_INTC_VECTOR, (uint16) address);
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_GetVector
********************************************************************************
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*
*******************************************************************************/
cyisraddress CapSense_sbCSD_cISR_GetVector(void)
{
    return (cyisraddress) CY_GET_REG16(CapSense_sbCSD_cISR_INTC_VECTOR);
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_SetPriority
********************************************************************************
* Summary:
*   Sets the Priority of the Interrupt.
*
*
* Parameters:
*   priority: Priority of the interrupt. 0 - 7, 0 being the highest.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_SetPriority(uint8 priority)
{
    *CapSense_sbCSD_cISR_INTC_PRIOR = priority << 5;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_GetPriority
********************************************************************************
* Summary:
*   Gets the Priority of the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   Priority of the interrupt. 0 - 7, 0 being the highest.
*
*
*******************************************************************************/
uint8 CapSense_sbCSD_cISR_GetPriority(void)
{
    uint8 priority;


    priority = *CapSense_sbCSD_cISR_INTC_PRIOR >> 5;

    return priority;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_Enable
********************************************************************************
* Summary:
*   Enables the interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_Enable(void)
{
    /* Enable the general interrupt. */
    *CapSense_sbCSD_cISR_INTC_SET_EN = CapSense_sbCSD_cISR__INTC_MASK;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_GetState
********************************************************************************
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   1 if enabled, 0 if disabled.
*
*
*******************************************************************************/
uint8 CapSense_sbCSD_cISR_GetState(void)
{
    /* Get the state of the general interrupt. */
    return (*CapSense_sbCSD_cISR_INTC_SET_EN & CapSense_sbCSD_cISR__INTC_MASK) ? 1:0;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_Disable
********************************************************************************
* Summary:
*   Disables the Interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_Disable(void)
{
    /* Disable the general interrupt. */
    *CapSense_sbCSD_cISR_INTC_CLR_EN = CapSense_sbCSD_cISR__INTC_MASK;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_SetPending
********************************************************************************
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_SetPending(void)
{
    *CapSense_sbCSD_cISR_INTC_SET_PD = CapSense_sbCSD_cISR__INTC_MASK;
}

/*******************************************************************************
* Function Name: CapSense_sbCSD_cISR_ClearPending
********************************************************************************
* Summary:
*   Clears a pending interrupt.
*
* Parameters:
*   void.
*
*
* Return:
*   void.
*
*
*******************************************************************************/
void CapSense_sbCSD_cISR_ClearPending(void)
{
    *CapSense_sbCSD_cISR_INTC_CLR_PD = CapSense_sbCSD_cISR__INTC_MASK;
}


















































