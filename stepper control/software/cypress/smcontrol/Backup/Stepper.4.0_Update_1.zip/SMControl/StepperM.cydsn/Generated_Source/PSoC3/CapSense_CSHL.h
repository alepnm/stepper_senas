/*******************************************************************************
* File Name: CapSense_CSHL.h
* Version 1.30
*
* Description:
*  This file provides constants and parameter values for the High Level API
*  of CapSense Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2009, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSHL_CapSense_H)
#define CY_CAPSENSE_CSHL_CapSense_H

#include "CapSense.h"


/***************************************
*       Types definition
***************************************/

/*    Widget struct               */
typedef struct  _CapSense_Widget
{
    uint8 Type;             /* Type of widget element */
    uint8 RawOffset;        /* Offset in SlotResult array */
    uint8 ScanSlotCount;    /* Number of Slot elements */
    uint8 FingerThreshold;  /* FingerThreshold */
    uint8 NoiseThreshold;   /* NoiseThreshold */
    uint8 Debounce;         /* Debounce */
    uint8 Hysteresis;       /* Hysteresis */
    uint16 Filters;         /* Filters */
    void *AdvancedSettings; /* Filters data and addtional settings */
}  CapSense_Widget;

/*    Buttons Settings struct         */
typedef struct _CapSense_BtnSettings
{
    uint16 Raw1Median;
    uint16 Raw2Median;
    uint16 Raw1Averaging;
    uint16 Raw2Averaging;
    uint16 RawIIR;
    uint16 RawJitter;
}  CapSense_BtnSettings;

/*    Slider Settings struct          */
typedef struct _CapSense_SlSettings
{
    uint32 Resolution;
    uint8 *DiplexTable;
    uint16 *Raw1Median;
    uint16 *Raw2Median;
    uint16 *Raw1Averaging;
    uint16 *Raw2Averaging;
    uint16 *RawIIR;
    uint16 *RawJitter;
    uint8 FirstTime;
    uint16 Pos1Median;
    uint16 Pos2Median;
    uint16 Pos1Averaging;
    uint16 Pos2Averaging;
    uint16 PosIIR;
    uint16 PosJitter;
}  CapSense_SlSettings;

/*    TouchPad Settings struct        */
typedef struct _CapSense_TPSettings
{
    uint32 Resolution;
    uint16 *Raw1Median;
    uint16 *Raw2Median;
    uint16 *Raw1Averaging;
    uint16 *Raw2Averaging;
    uint16 *RawIIR;
    uint16 *RawJitter;
    uint8 FirstTime;
    uint16 *Pos1Median;
    uint16 *Pos2Median;
    uint16 *Pos1Averaging;
    uint16 *Pos2Averaging;
    uint16 *PosIIR;
    uint16 *PosJitter;
    uint16 *Position;
}  CapSense_TPSettings;

/*    Matrix Buttons Settings struct  */
typedef struct _CapSense_MBSettings
{
    uint16 *Raw1Median;
    uint16 *Raw2Median;
    uint16 *Raw1Averaging;
    uint16 *Raw2Averaging;
    uint16 *RawIIR;
    uint16 *RawJitter;
}  CapSense_MBSettings;


/***************************************
*        Function Prototypes
***************************************/

void CapSense_CSHL_InitializeSlotBaseline(uint8 slot);
void CapSense_CSHL_InitializeAllBaselines(void);
void CapSense_CSHL_UpdateSlotBaseline(uint8 slot);
void CapSense_CSHL_UpdateAllBaselines(void);
uint8 CapSense_CSHL_CheckIsSlotActive(uint8 slot);
uint8 CapSense_CSHL_CheckIsAnySlotActive(void);


uint16 CapSense_CSHL_GetCentroidPos(uint8 widget);


/***************************************
*           API Constants
***************************************/

/* Widgets constants definition */
#define CapSense_CSHL_LS_S1        0
#define CapSense_CSHL_BTN_B1        1
#define CapSense_CSHL_BTN_B2        2

#define CapSense_CSHL_TOTAL_WIDGET_COUNT          3
#define CapSense_CSHL_NUMBER_OF_DOUBLE_STRUCTS    0

/* Widget Types */
#define CapSense_CSHL_TYPE_BUTTON                   0u
#define CapSense_CSHL_TYPE_LINEAR_SLIDER            1u
#define CapSense_CSHL_TYPE_RADIAL_SLIDER            2u
#define CapSense_CSHL_TYPE_TOUCHPAD                 3u
#define CapSense_CSHL_TYPE_MATRIX_BUTTONS           4u
#define CapSense_CSHL_TYPE_PROXIMITY                5u
#define CapSense_CSHL_NO_WIDGET                     0xFFu

/* Mask for RAW and POS filters */
#define CapSense_CSHL_RAW_MEDIAN_FILTER             0x01u
#define CapSense_CSHL_RAW_AVERAGING_FILTER          0x02u
#define CapSense_CSHL_RAW_IIR_FILTER_0              0x04u
#define CapSense_CSHL_RAW_IIR_FILTER_1              0x08u
#define CapSense_CSHL_RAW_JITTER_FILTER             0x10u
#define CapSense_CSHL_POS_MEDIAN_FILTER             0x20u
#define CapSense_CSHL_POS_AVERAGING_FILTER          0x40u
#define CapSense_CSHL_POS_IIR_FILTER_0              0x80u
#define CapSense_CSHL_POS_IIR_FILTER_1              0x100u
#define CapSense_CSHL_POS_JITTER_FILTER             0x200u
#define CapSense_CSHL_X_TOUCH                       1u
#define CapSense_CSHL_Y_TOUCH                       2u
#define CapSense_CSHL_TRUE_TOUCH                    3u

/* Types of IIR filters */
#define CapSense_CSHL_IIR_FILTER_0                  0x00u
#define CapSense_CSHL_IIR_FILTER_1                  0x01u

/* Defines is slot active */
#define CapSense_CSHL_SLOT_ACTIVE                   0x01u

/* Defines diplex type of Slider */
#define CapSense_CSHL_IS_DIPLEX                     0x80u

/* Defines max fingers on TouchPad  */
#define  CapSense_CSHL_MAX_FINGERS                  1u

/* Radial Slider defines */
#define CapSense_CSHL_ROTARY_SLIDER_A360            (360u)
#define CapSense_CSHL_ROTARY_SLIDER_A270            (270u)
#define CapSense_CSHL_ROTARY_SLIDER_A180            (180u)
#define CapSense_CSHL_ROTARY_SLIDER_A90             (90u)

#endif /* End CY_CAPSENSE_CSHL_CapSense_H */


/* [] END OF FILE */
